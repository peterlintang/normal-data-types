This is the implementation of "Robust Ellipsoid-specific Fitting via Expectation Maximization", BMVC 2022. 


Run the "demo.m" to start fitting. 


If you have any question, please do not hesitate to contact me. My e-mail is myzhao@baai.ac.cn