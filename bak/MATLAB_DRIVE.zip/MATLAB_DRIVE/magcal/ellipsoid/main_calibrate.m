% Batch 3-axis compass calibration using least squares ellipsoid fitting
% 2020/06/03

clc
clear
close all

addpath('utils');

% Import raw magnetometer readings
%raw = importdata('raw_data.csv');
raw=load('../../mag_raw2.txt');
%raw=raw/1000;
x = raw(:,1);
y = raw(:,2);
z = raw(:,3);

% Ellipsoid fit calibration
[Ainv, b, r, rmse] = magcal(x, y, z);
m = [x, y, z]';
m_hat = Ainv * (m-b);
%m_hat = (m-b);

% we add
my_start = 1;
my_end = 2633;

mx = m_hat(1,:);
my = m_hat(2,:);
mz = m_hat(3,:);

%figure;
%plot3(x,y,z,'x')
%hold on
%plot3(mx,my,mz,'ro')
%hold on 

%[SX,SY,SZ] = sphere;
%SX = SX *1;
%SY = SY *1;
%SZ = SZ *1;
%lightGrey = 0.9*[1 1 1];
%surf(SX,SY,SZ,'FaceColor', 'none','EdgeColor',lightGrey)
%axis equal
% we add

% Plot uncalibrated data
subplot(1,2,1);
plot_sphere(b, r);
%plot_sphere([0 0 0], r);
scatter3(x(my_start : my_end), y(my_start : my_end), z(my_start : my_end),'fill','MarkerFaceColor','red');
title({'Before magnetometer calibration','(Ellipsoid fitted)'});
xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
axis equal;

% Plot calibrated data
subplot(1,2,2);
plot_sphere([0 0 0], r);
scatter3(mx(my_start : my_end), my(my_start : my_end), mz(my_start : my_end),'fill','MarkerFaceColor','blue');
title({'After magnetometer calibration'});
xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
axis equal;

% Print calibration matrices
%fprintf('3D magnetometer calibration based on ellipsoid fitting');
%fprintf('\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
%fprintf('\nThe calibration equation:')
%fprintf('\n      m_hat = Ainv * (m - b) \n\nwhere,')
%fprintf('\n m = Three-axis magnetometer measurement [3x1]');
%fprintf('\n m_hat = Calibrated magnetometer [3x1]');
fprintf('\n\nAinv =\n'); disp(Ainv);
fprintf('\nb =\n'); disp(b);
fprintf('\nr = '); disp(r);
%fprintf('\nrmse = '); disp(rmse);

pitch=rad2deg(atan2(mx, sqrt(my.^2+mz.^2)))';
raw_pitch=rad2deg(atan2(x, sqrt(y.^2+z.^2)));
roll=rad2deg(atan2(my,mz))';
raw_roll=rad2deg(atan2(y,z));
