# magcal

Implementation of different magnetometer calibration algorithms.

## Index

1. [ellipsoid](ellipsoid) - Ellipsoid fit based magnetometer calibration.

## Todos

1. Check the weirdness in plot_ellipsoid()
2. Add about five sets of real magnetometer data
3. Documentation of the calibration process
