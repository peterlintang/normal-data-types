# Mag-Cal
Matlab script for calibrating 3-axis magnetometers

