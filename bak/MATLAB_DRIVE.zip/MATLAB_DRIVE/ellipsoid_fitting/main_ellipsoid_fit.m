% Test of ellipsoid_fit.m function
clc
clear 
close all

% Noisy ellipsoid params %
% Semi principal axes
ax= 20;  
bx = 30; 
cx = 50;

% Centre  
xc = 10; 
yc = 100; 
zc = 10;

% Orientation (3-2-1 Euler)
yaw = 0;%pi/2; 
pitch = pi/2; 
roll = 0;%pi/7;

% Noise factor
noise_factor = 5;

% Generate test ellipoid %
% x	=	a*cosu*sinv 	
% y	=	b*sinu*sinv	
% z	=	c*cosv
% u in [0,2pi) and v in [0,pi]
[u, v] = meshgrid(0:0.3:pi*2, 0:0.3:pi);
x = ax*cos(u).*cos(v);
y = bx*cos(u).*sin(v);
z = cx*sin(u);

% Meshgrid to vector
x=x(:); y=y(:); z=z(:); 
xyz = [x y z];
Q = dcm_321_euler(yaw, pitch, roll);

% Rotate using DCM (321)
for i_iters = 1: length(x)
     new = Q*xyz(i_iters,:)';
     xyz(i_iters,:) = new'; 
end

% Move centre after rotation
x = xc + xyz(:,1);
y = yc + xyz(:,2);
z = zc + xyz(:,3);

% Add noise to generated points
x = x + noise_factor*rand(size(x));
y = y + noise_factor*rand(size(y));
z = z + noise_factor*rand(size(z));

% Ellipsoid fit algoritm
%v = ellipsoid_fit(x,y,z);
v = fit_ellipsoid10(x,y,z);
fprintf('\nv =\n'); disp(v);

% we add
my_start=20;
my_end=25;
% we add

% Plot result
subplot(1,2,1);
plot3(x(my_start:my_end),y(my_start:my_end),z(my_start:my_end),'.','MarkerSize',15); hold on; 
plot_ellipsoid(v);
xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
title('Ellipsoid fit');
grid on;

% we add
% Unpack ellipsoid coefficients
a = v(1); b = v(2); c = v(3);
f = v(4); g = v(5); h = v(6); 
p = v(7); q = v(8); r = v(9); 
d = v(10); 

% Coordinate frame transformation i.e diagonalize M 
M =[a, h, g; h, b, f; g, f, c]; % Original ellipsoid matrix 
u = [p, q, r]';
k = d;

[evec, eval]=eig(M); % Compute eigenvectors matrix
rotation = evec'; % DCM = eigenvectors matrix
eval = -eval;
M_ = evec'*M*evec; % Diagonalize M

% Coefficients of the ellipsoid in new frame
% Note the ellipsoid is not rotating in this new frame so f, g and h = 0 
pqr_ = [p,q,r]*evec;   
a_ = M_(1,1);
b_ = M_(2,2);
c_ = M_(3,3);
p_ = pqr_(1);
q_ = pqr_(2);
r_ = pqr_(3);
d_ = d;

% Semi principal axes (Still no rotation)
ax_ = sqrt(p_^2/a_^2 + q_^2/(a_*b_) + r_^2/(a_*c_) - d_/a_);
bx_ = sqrt(p_^2/(a_*b_) + q_^2/b_^2 + r_^2/(b_*c_) - d_/b_);
cx_ = sqrt(p_^2/(a_*c_) + q_^2/(b_*c_) + r_^2/c_^2 - d_/c_);

offset = - M \ u; % Eqn(21)
gain = [1/ax_, 0, 0; 0, 1/bx_, 0; 0,0,1/cx_];
matrix = gain*rotation;
%matrix = gain;

% Calibration %
% Memory to calibrated readings 
x_hat = zeros(length(x),1); 
y_hat = zeros(length(x),1); 
z_hat = zeros(length(x),1);
for i_iters = 1:length(x)
    % Sensor data
    h_hat = [x(i_iters); y(i_iters); z(i_iters)]; 
    
    % Calibration, Eqn(11)
    h = matrix*(h_hat - offset);
    
    % Calibrated values
    x_hat(i_iters) = h(1);
    y_hat(i_iters) = h(2);
    z_hat(i_iters) = h(3);
end

% Visualization %
% Sensor readings and ellipoid fit
%scatter3(x, y, z, 'fill', 'MarkerFaceColor', 'red'); hold on; 
%plot_ellipsoid(v); 
%title({'Before magnetometer calibration', '(Ellipsoid fit)'});
%xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
%axis equal;

% After calibrations
%figure;
subplot(1,2,2);
scatter3(x_hat(my_start:my_end), y_hat(my_start:my_end), z_hat(my_start:my_end), 'fill', 'MarkerFaceColor', 'blue'); hold on;
plot_sphere([0,0,0]', 1);
title({'After magnetometer calibration', '(Normalized to unit sphere)'});
xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
axis equal;

% Print calibration params
%fprintf('3D magnetometer calibration based on ellipsoid fitting');
%fprintf('\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
%fprintf('\nThe calibration equation to be implemented:') 
%fprintf('\n\t\t\t\th_hat = M*(h_m - b) \nWhere,')
%fprintf('\nh_m   = Measured sensor data vector');
%fprintf('\nh_hat = Calibrated sensor data vector');
%fprintf('\n\nM =\n'); disp(M);
%fprintf('\nb =\n'); disp(offset);
%fprintf('\nrotaion =\n'); disp(rotation);
%fprintf('\ngain =\n'); disp(gain);
% we add