clc
clear 
close all

% 假设椭球的一般方程为：Ax^2 + By^2 + Cz^2 + Dxy + Exz + Fyz + Gx + Hy + Iz + J = 0
% 提取系数
A = 0.9;
B = 0.4;
C = 0.1;
D = 0;
E = 0;
F = 0;
G = -8.7;
H = -41.5;
I = -1.6;
J = 3875.7;

v=[A B C D E F G H I J];
plot_ellipsoid(v);
% 构造对称矩阵
Q = [A D/2 E/2; D/2 B F/2; E/2 F/2 C];
L = [G/2; H/2; I/2];

% 计算特征值和特征向量
[V, D] = eig(Q);

% 提取特征值和特征向量
lambda1 = D(1,1);
lambda2 = D(2,2);
lambda3 = D(3,3);
v1 = V(:,1);
v2 = V(:,2);
v2 = V(:,3);

% 计算平移向量
T = -inv(Q) * L;

% 计算标准方程的参数
a = sqrt(-J/lambda1);
b = sqrt(-J/lambda2);
c = sqrt(-J/lambda3);

% 结果输出
disp(['标准方程：X^2/', num2str(a^2), ' + Y^2/', num2str(b^2), ' + Z^2/', num2str(c^2), ' = 1']);
disp(['平移向量：[', num2str(T(1)), ', ', num2str(T(2)), ', ', num2str(T(3)), ']']);
disp(['旋转矩阵：']);
disp(V);