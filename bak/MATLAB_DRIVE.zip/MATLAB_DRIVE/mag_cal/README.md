# mag_cal
Octave scripts to perform a IMU magnetic calibration process by ellipsoidal fit
