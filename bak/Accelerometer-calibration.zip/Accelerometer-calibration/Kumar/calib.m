clear;
clc;
a = load ('../../acc.txt');

a = a/1000;
[rotm,off] = calibaccel(a)
x = a(:,1);
y = a(:,2);
z = a(:,3);

[rows columns] = size(a);
A = zeros(rows,columns);
for i=1:rows
   v = rotm*(a(i,:)'-off);
   A(i,:) = [v(1) v(2) v(3)];
end
figure(1);
plot3(a(:,1),a(:,2),a(:,3),'+')
axis equal
hold on
plot3(A(:,1),A(:,2),A(:,3),'ro')
hold on

[SX,SY,SZ] = sphere;
lightGrey = 0.9*[1 1 1];
surf(SX,SY,SZ,'FaceColor', 'none','EdgeColor',lightGrey)
axis equal





