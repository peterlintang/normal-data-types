
#ifndef ECOMPASS_H__
#define ECOMPASS_H__

float ecompass_get_psi(void);
void ecompass_deinit(void);
int ecompass_init(void);

#endif // end of ECOMPASS_H__
