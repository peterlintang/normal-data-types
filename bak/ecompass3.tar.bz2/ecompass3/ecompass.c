

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#include <kernel.h>
#include "mmc5983ma.h"
#include "fw_version.h"
#include <fs/fs.h>
#include <fs/fs_sys.h>
#include <fs_manager.h>

#include <math.h>

#include <drivers/rtc.h> // for rtc

#define M_PI        3.14159265358979323846

#define MAG_DEBUG 1

#if MAG_DEBUG
static struct fs_file_t zfp;
#endif

static struct k_timer imu_timer;
static K_SEM_DEFINE(imu_sem, 0, 1);
static int quit_flag = 0;
static k_tid_t ecompass_tid = NULL;
static K_THREAD_STACK_DEFINE(ecompass_thread_stack, 4096);
static struct k_thread ecompass_thread_data;
static float quatern[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
static float B[3] = {
	0.0,
	0.0,
	0.0,
	/*
	-0.635895514503448 * 100,
	0.685133921818152 * 100,
	-1.043121733475208 * 100,
	*/
};
static float Tm2a[3][3] = {
	{1.0, 0.0, 0.0},
	{0.0, 1.0, 0.0},
	{0.0, 0.0, 1.0},
	/*
	{1.021347318750803,  0.006859672766488, -0.000902592112601},
	{0.006859672766488,  0.978990263908302,  0.010802040815977},
	{-0.000902592112601,  0.010802040815977,  1.000278124216977},
	*/
};



extern void lsm6dsv_init(void);
extern void mmc5983_init(void);
extern void lsm6dsv_read_gry_data(float *gry);
extern void lsm6dsv_read_acc_data(float *acc);
extern void quater2euler(float euler[3], float quater[4]);
extern void MahonyAHRSupdate(float q[4], float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz) ;


static void sensors_init(void)
{
	mmc5983_init();
	lsm6dsv_init();
}

static void get_acc_data(float outAcc[3])
{
	float acc[3];
	float inAcc[3];

	lsm6dsv_read_acc_data(acc);
	inAcc[0] = (acc[0] ) ;
	inAcc[1] = -(acc[1] );
	inAcc[2] = (acc[2] ) ;
	for (int i = 0; i < 3; i++)
	{
		outAcc[i] = inAcc[i] / 1000.0f * 9.8f;
	}
}

static void get_gry_data(float outGry[3])
{
	float gry[3];
	float inGry[3];

	lsm6dsv_read_gry_data(gry);
	inGry[0] = -gry[0];
	inGry[1] = gry[1] ;
	inGry[2] = -gry[2];
	for (int i = 0; i < 3; i++)
	{
		outGry[i] = inGry[i] / 1000.0f * M_PI / 180.0f;
	}
}

static void get_mag_data(float outMag[3])
{
	float inMag[3] = { 0.0f };
	float newMag[3];

	MMC5983_GetData(inMag);

	for (int i = 0; i < 3; i++)
	{
		newMag[i] = 1000 * inMag[i] - B[i];
	}

	for (int i = 0; i < 3; i++)
	{
		outMag[i] = Tm2a[i][0] * newMag[0] + Tm2a[i][1] * newMag[1] + Tm2a[i][2] * newMag[2];
	}

#if MAG_DEBUG
	char tx_buffer[128] = { 0 };
	static int skip_count = 0;
	int len = snprintf((char *)tx_buffer, sizeof(tx_buffer), 
			    "%8.8f %8.8f %8.8f\n",
			    1000 * inMag[0], 1000 * inMag[1], 1000 * inMag[2]
			    );
	skip_count++;
	if (skip_count > 200)
	{
		fs_write(&zfp, tx_buffer, len);
	}
#endif

}

static void imu_timer_handler(struct k_timer *timer)
{
	k_sem_give(&imu_sem);
}


static void ecompass_thread(void *p1,void *p2,void *p3)
{
	float acc[3] = { 0, 0 , 0 };
	float gry[3] = { 0, 0 , 0 };
    	float mag[3]={0};
	
	sensors_init();
	k_msleep(10);

	k_timer_init(&imu_timer,
			imu_timer_handler,
			 NULL);
	k_timer_start(&imu_timer,
			     K_MSEC(10), 
			     K_MSEC(10)
			     );

#if MAG_DEBUG
	struct fs_file_t zfp2;
	char file_name[64] = { 0 };
//	static int file_index = 0;
	struct rtc_time rtc_time;
	struct rtc_time *tm = &rtc_time;
	const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);
	rtc_get_time(rtc, &rtc_time);

	snprintf(file_name, 64, "/SD:/magdata_%04d%02d%02d_%02d%02d%02d.txt",
                        1900 + tm->tm_year, tm->tm_mon + 1, tm->tm_mday,
                        tm->tm_hour, tm->tm_min, tm->tm_sec);

//	snprintf(file_name, 64, "/SD:/mag_data_%d.txt", file_index++);

	memset(&zfp, 0, sizeof(zfp));
	if (fs_open(&zfp, file_name, FA_READ | FA_WRITE | FS_O_CREATE))
	{
		printf("%s create file failed\n", __func__);
		return ;
	}

	snprintf(file_name, 64, "/SD:/alldata_%04d%02d%02d_%02d%02d%02d.txt",
                        1900 + tm->tm_year, tm->tm_mon + 1, tm->tm_mday,
                        tm->tm_hour, tm->tm_min, tm->tm_sec);

	memset(&zfp2, 0, sizeof(zfp2));
	if (fs_open(&zfp2, file_name, FA_READ | FA_WRITE | FS_O_CREATE))
	{
		printf("%s create file failed\n", __func__);
		fs_close(&zfp);
		return ;
	}
#endif
	quatern[0] = 1.0f;
	quatern[1] = 0.0f;
	quatern[2] = 0.0f;
	quatern[3] = 0.0f;

	while (quit_flag != 1)
	{
		k_sem_take(&imu_sem, K_FOREVER);

		get_acc_data(acc);
		get_gry_data(gry);
		get_mag_data(mag);
#if MAG_DEBUG
#endif

		MahonyAHRSupdate(quatern, gry[0], gry[1], gry[2], acc[0], acc[1], acc[2], mag[1], mag[0], mag[2]);

#if MAG_DEBUG
	float euler[3] = { 0 };
	quater2euler(euler, quatern);
	static int count = 0;
	if (count++ % 200 == 0)
	{
		uint8_t to_send[64] = { 0 };
		uint16_t to_send_len = 0;
		printf("%4.2f %4.2f %4.2f\n",
				euler[0] * 180 / M_PI,
				euler[1] * 180 / M_PI,
				euler[2] * 180 / M_PI > 0 ? euler[2] * 180 / M_PI : 360 + euler[2] * 180 / M_PI);
		to_send_len = snprintf(to_send, 64, "%4.2f %4.2f %4.2f\n",
				euler[0] * 180 / M_PI,
				euler[1] * 180 / M_PI,
				euler[2] * 180 / M_PI > 0 ? euler[2] * 180 / M_PI : 360 + euler[2] * 180 / M_PI);
		extern int bt_hrs_notify(uint8_t *data, uint16_t len);
		bt_hrs_notify(to_send, to_send_len);
	}
	char tx_buffer[256] = { 0 };
	int32_t stamp = k_uptime_get_32();
	static int skip_count = 0;
	int len = snprintf((char *)tx_buffer, sizeof(tx_buffer), 
			    "%d %8.8f %8.8f %8.8f %8.8f %8.8f %8.8f %8.8f %8.8f %8.8f %.2f %.2f %.2f\n",
			    stamp,
			    gry[0], gry[1], gry[2],
			    acc[0], acc[1], acc[2],
			    mag[0], mag[1], mag[2],
			euler[0] * 180 / M_PI,
			euler[1] * 180 / M_PI,
			euler[2] * 180 / M_PI > 0 ? euler[2] * 180 / M_PI : 360 + euler[2] * 180 / M_PI
			    );
	skip_count++;
	if (skip_count > 200)
	{
		fs_write(&zfp2, tx_buffer, len);
	}
#endif

	}
	k_timer_stop(&imu_timer);
	ecompass_tid = NULL;
	quit_flag = 0;

#if MAG_DEBUG
	fs_close(&zfp2);
	fs_close(&zfp);
#endif
}

int ecompass_init(void)
{
	if (ecompass_tid == NULL)
	{
#define ECOMPASS_CA_FILE "/SD:/mag_ca.txt"
		int ret = 0;
		char str[160] = { 0 };
		struct fs_file_t cl_zfp;
		memset(&cl_zfp, 0, sizeof(cl_zfp));
		if (fs_open(&cl_zfp, ECOMPASS_CA_FILE, FA_READ))
		{
			printf("%s no file %s, use default\n", __func__, ECOMPASS_CA_FILE);
			goto next;
			return -1;
		}
		fs_read(&cl_zfp, str, 160);
		fs_close(&cl_zfp);

		ret = sscanf(str, "%f %f %f %f %f %f %f %f %f %f %f %f", &B[0], &B[1], &B[2], 
				&Tm2a[0][0], &Tm2a[0][1], &Tm2a[0][2], 
				&Tm2a[1][0], &Tm2a[1][1], &Tm2a[1][2], 
				&Tm2a[2][0], &Tm2a[2][1], &Tm2a[2][2]);
		printf("str: %s\nret: %d, error: %s\n", str, ret, strerror(errno));
		printf("%.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f\n", 
				B[0], B[1], B[2], 
				Tm2a[0][0], Tm2a[0][1], Tm2a[0][2], 
				Tm2a[1][0], Tm2a[1][1], Tm2a[1][2], 
				Tm2a[2][0], Tm2a[2][1], Tm2a[2][2]);

next:
		ecompass_tid = k_thread_create(&ecompass_thread_data, ecompass_thread_stack,
				K_THREAD_STACK_SIZEOF(ecompass_thread_stack),
				ecompass_thread, NULL, NULL, NULL,
				14, 0, K_NO_WAIT);
		k_thread_name_set(ecompass_tid, "ecompass");
	}
	else
	{
		printf("%s: ecompass thread already running", __func__);
		return -2;
	}
	return 0;
}

void ecompass_deinit(void)
{
	quit_flag = 1;
	while (quit_flag == 1)
		k_msleep(1);
}

float ecompass_get_psi(void)
{
	float euler[3] = { 0 };
	quater2euler(euler, quatern);
	return euler[2] * 180 / M_PI > 0 ? euler[2] * 180 / M_PI : 360 + euler[2] * 180 / M_PI;
}

