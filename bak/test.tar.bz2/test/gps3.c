// ref p4:gps_test_view.c
/*
 * Copyright (c) 2020 Actions Technology Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#include <assert.h>
#include <lvgl.h>
#include <lvgl/lvgl_res_loader.h>
#include <lvgl/lvgl_bitmap_font.h>

#include <ui_manager.h>
#include <view_manager.h>
#include "widgets/anim_img.h"
#include "widgets/img_number.h"

#include <res_manager_api.h>
#include "app_ui.h"
#include "app_defines.h"
#include "system_app.h"
#include <view_stack.h>


#include <sys_wakelock.h>


#ifndef CONFIG_SIMULATOR
#include <acts_bluetooth/host_interface.h>
#include <bt_manager.h>
#endif

#define SCENE_ID 	SCENE_GPS3_VIEW
#define VIEW_ID 	GPS3_VIEW

#define ITEM_NUM	8
typedef struct _gps3_data {

	lv_obj_t *obj;
	/*
	lv_obj_t *obj_line[ITEM_NUM];
	*/
	lv_obj_t *buttons[ITEM_NUM];
	lv_obj_t *labels[ITEM_NUM];
	lvgl_res_string_t strs[ITEM_NUM];
	lv_style_t strs_style[ITEM_NUM];

	lv_img_dsc_t	res_imgs[8];
	lv_point_t 	pt_imgs[8];
	lv_obj_t 	*switches[4];

	lv_style_t style;
	lv_style_t style3;

	lvgl_res_scene_t scene;
	lv_font_t font;

} gps3_data;

const static uint32_t _txt_ids[ITEM_NUM] = {
    STRING33399,
    STRING33400,
    STRING33401,
    STRING33402,
    STRING31759,
    STRING31760,
    STRING31769,
    STRING31770,
};

const static uint32_t _img_ids[] = {
	PICTURE31761,
	PICTURE31762,
	PICTURE31763,
	PICTURE31764,
	PICTURE31765,
	PICTURE31766,
	PICTURE31767,
	PICTURE31768,
};



static int gps_point_log = 0;
static int gps_log_flag = 0;
static struct fs_file_t zfp;
static int file_open_flag = 0;
static int switches_status[4] = { 0 };


int set_gps_save_flag(int value)
{
	return gps_log_flag = value;
}

int save_gps_log_deinit(void)
{
	switches_status[0] = 0;
	switches_status[1] = 0;
	switches_status[2] = 0;
	switches_status[3] = 0;
	gps_point_log = 0;
	gps_log_flag = 0;
	file_open_flag = 0;
	fs_close(&zfp);
	memset(&zfp, 0, sizeof(zfp));
	return 0;
}

#include <stdio.h>
#include <fs_manager.h>
#include <fs/fs.h>
#include <fs/fs.h>
#include <fs/fs_sys.h>
#include <drivers/rtc.h>
int save_gps_log(char *buf, int len)
{
//	char str[256] = { 0 };

	if (gps_log_flag == 0)
		return 0;
	if (file_open_flag == 0)
	{
		char file_name[128] = { 0 };
		struct rtc_time rtc_time;
		struct rtc_time *tm = &rtc_time;
		const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);

		printf("%s %d %d\n", __func__, gps_log_flag, file_open_flag);

		if (rtc) {
			rtc_get_time(rtc, &rtc_time);
			print_rtc_time(&rtc_time);
		}
		else
		{
			SYS_LOG_ERR("get rtc time failed\n");
			return -1;
		}

		snprintf(file_name, 128, "/NAND:/%04d-%02d-%02d_%02d-%02d-%02d",
			1900 + tm->tm_year, tm->tm_mon + 1, tm->tm_mday,
			tm->tm_hour, tm->tm_min, tm->tm_sec);


		if (fs_open(&zfp, file_name, FA_WRITE | FS_O_CREATE))
		{
			SYS_LOG_ERR("open file for log failed\n");
			return -1;
		}
		file_open_flag = 1;
	}

//	memcpy(str, buf, len);
	return fs_write(&zfp, buf, len);

}

static void init_txt_style(gps3_data *data, lv_style_t *sty, lvgl_res_string_t *txt, uint32_t num)
{
    for (int i = 0; i < num; i++) {
        lv_style_init(&sty[i]);
        lv_style_set_x(&sty[i], txt[i].x);
        lv_style_set_y(&sty[i], txt[i].y);
        lv_style_set_width(&sty[i], txt[i].width);
        lv_style_set_height(&sty[i], txt[i].height);
        lv_style_set_text_color(&sty[i], txt[i].color);
        lv_style_set_text_align(&sty[i], txt[i].align);
	lv_style_set_bg_color(&sty[i], txt[i].bgcolor);
//	lv_style_set_bg_color(&sty[i], lv_color_hex(0x0000ff));

        lv_style_set_text_font(&sty[i], &data->font);
         SYS_LOG_INF("%s: %d %d %d %d\n", __func__, txt[i].x, txt[i].y, txt[i].width, txt[i].height);
    }
}

#include "fw_version.h"
#include "drivers/uart.h"
#include "uart2_to_gps.h"
static view_data_t *pp = NULL;
static struct fs_file_t gps_zfp;
static int is_gps_points_file_open = 0;
static void setting_btn_event_handler(lv_event_t * e)
{
        lv_obj_t *btn = lv_event_get_current_target(e);
        int idx = (int)lv_obj_get_user_data(btn);
	printf("%s: idx: %d\n", __func__, idx);
	static int flag[4] = { 0 };
	static int choose = -1;
	int i = idx;
	gps3_data *data = pp->user_data;

	/*
	const struct device* gps_uart = NULL;
	gps_uart = device_get_binding(GPS_DEVICE);
	*/
	if (idx == 4)
	{
		set_gps_save_flag(1);
	}
	else if (idx == 6)
	{
#define GPS_DEVICE     		 	"UART_2"
		const struct device* gps_uart = NULL;
		gps_uart = device_get_binding(GPS_DEVICE);
//		unsigned char *str = "$PAIR490,1*2A\r\n";
		unsigned char *str = "$PAIR496,1*2C\r\n";
		printf("%s send: %s\n", __func__, str);
		for (int i = 0; i < strlen(str); i++)
		{
			uart_poll_out(gps_uart, str[i]);
		}
		unsigned char *str2 = "$PAIR510,1*23\r\n";
		printf("%s send: %s\n", __func__, str2);
		for (int i = 0; i < strlen(str2); i++)
		{
			uart_poll_out(gps_uart, str2[i]);
		}
		return 0;

	}
	else if (idx == 7)
	{
#define GPS_DEVICE     		 	"UART_2"
		const struct device* gps_uart = NULL;
		gps_uart = device_get_binding(GPS_DEVICE);
//		unsigned char *str = "$PAIR490,0*2B\r\n";
		unsigned char *str = "$PAIR496,0*2D\r\n";
		printf("%s send: %s\n", __func__, str);
		for (int i = 0; i < strlen(str); i++)
		{
			uart_poll_out(gps_uart, str[i]);
		}
		return 0;
	}
	else if (idx == 5)
	{
		extern GPS_INFO GPS;
	//	char file_name[] = "/NAND:/gps_points.txt";
		char file_name[64] = "";
		char str[128] = { 0 };
		struct rtc_time rtc_time;
		struct rtc_time *tm = &rtc_time;
		const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);

	if (GPS.gps_fixed == 3)
	{
		if (rtc) {
			rtc_get_time(rtc, &rtc_time);
		}
		else
		{
			SYS_LOG_ERR("get rtc time failed\n");
			return ;
		}

		if (is_gps_points_file_open == 0)
		{
			int ret = 0;
			memset(&gps_zfp, 0, sizeof(gps_zfp));
			memset(file_name, 0, 64);
			snprintf(file_name, 64, "/NAND:/%4d%02d%02d%02d%02d%02d_points.txt", 
					1900 + tm->tm_year, 
					tm->tm_mon + 1, 
					tm->tm_mday,
					tm->tm_hour, 
					tm->tm_min, 
					tm->tm_sec
					);
			if (ret = fs_open(&gps_zfp, file_name, FS_O_RDWR | FS_O_CREATE | FS_O_APPEND))
			{
				SYS_LOG_ERR("open file for log failed, ret: %d\n", ret);
				return ;
			}
			is_gps_points_file_open = 1;
		}
		int len = snprintf(str, 128, "%04d-%02d-%02d %02d-%02d-%02d %.8f %.8f\n", 
				1900 + tm->tm_year, 
				tm->tm_mon + 1, 
				tm->tm_mday,
				tm->tm_hour, 
				tm->tm_min, 
				tm->tm_sec,
				GPS.latitude,
				GPS.longitude
				);
		printf("%s: str: %s, len: %d\n", __func__, str, len);
		fs_write(&gps_zfp, str, len);
//		fs_close(&gps_zfp);
	}
	}

	lv_refr_now(pp->display);

}

static void open_switch_btn_event_handler(lv_event_t * e)
{
        lv_obj_t *btn = lv_event_get_current_target(e);
        int idx = (int)lv_obj_get_user_data(btn);
	gps3_data *data = pp->user_data;

	printf("%s: idx: %d\n", __func__, idx);

#define GPS_DEVICE     		 	"UART_2"
	const struct device* gps_uart = NULL;
	gps_uart = device_get_binding(GPS_DEVICE);

	unsigned char *str = NULL;

	str = "$PAIR732,0*20\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}

	str = "$PAIR066,1,1,1,1,1,0*3B\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}

	if (switches_status[idx] == 0)
	{
		lv_img_set_src(data->switches[idx], &data->res_imgs[idx * 2]);
		switches_status[idx] = 1;

		for (int i = 0; i < 4; i++)
		{
			if (i == idx) continue;
			lv_img_set_src(data->switches[i], &data->res_imgs[i * 2 + 1]);
			switches_status[i] = 0;
		}

		if (idx == 0)
		{
			unsigned char *str = "$PAIR066,1,0,0,0,0,0*3B\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
		}
		if (idx == 1)
		{
			unsigned char *str = NULL;
			str = "$PAIR066,1,0,0,0,0,0*3B\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
//			unsigned char *str = "$PAIR732,1*21\r\n";
			str = "$PAIR732,2*22\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
		}
		if (idx == 2)
		{
			unsigned char *str = NULL;
			str = "$PAIR066,1,1,1,1,1,0*3B\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
		}
		if (idx == 3)
		{
			unsigned char *str = NULL;
			str = "$PAIR066,1,1,1,1,1,0*3B\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}

			str = "$PAIR732,2*22\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
		}
	}
	else
	{
		lv_img_set_src(data->switches[idx], &data->res_imgs[idx * 2 + 1]);
		switches_status[idx] = 0;
		/*
		if (idx == 0)
		{
			unsigned char *str = "$PAIR066,1,1,1,1,1,0*3B\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
		}
		if (idx == 1)
		{
			unsigned char *str = "$PAIR732,0*20\r\n";
			for (int i = 0; i < strlen(str); i++)
			{
				uart_poll_out(gps_uart, str[i]);
			}
		}
		*/
	}
}

static int _view_create(view_data_t *view_data)
{
	lv_obj_t *scr = lv_disp_get_scr_act(view_data->display);
	gps3_data *data = view_data->user_data;
	pp = view_data;
	lv_obj_set_style_bg_color(scr, data->scene.background, LV_PART_MAIN);
	lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, LV_PART_MAIN);

	data->obj = lv_obj_create(scr);
	lv_obj_set_size(data->obj, 240, 320);
	lv_obj_set_pos(data->obj, 0, 0);

	lv_style_init(&data->style);
	lv_style_set_bg_opa(&data->style, LV_OPA_0);
    	lv_style_set_bg_color(&data->style, /*lv_palette_main(LV_PALETTE_BLUE)*/lv_color_hex(0x000000));
	lv_style_set_border_width(&data->style, 2); // 边框宽度
	lv_style_set_border_color(&data->style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&data->style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&data->style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向

	lv_style_init(&data->style3);
	lv_style_set_bg_opa(&data->style3, LV_OPA_50);
    	lv_style_set_bg_color(&data->style3, lv_palette_main(LV_PALETTE_BLUE)/*lv_color_hex(0x3c3c3c)*/);
	lv_style_set_border_width(&data->style3, 2); // 边框宽度
	lv_style_set_border_color(&data->style3, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&data->style3, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&data->style3, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	// 应用样式到标签

	for (int i = 0; i < ITEM_NUM; i++) 
	{
		data->labels[i] = lv_label_create(data->obj);
		lv_obj_add_style(data->labels[i], &data->strs_style[i], LV_PART_MAIN);
		
//		if (i != 3)
		{
		lv_obj_add_style(data->labels[i], &data->style, LV_PART_MAIN /*LV_STATE_DEFAULT*/);
//		lv_obj_add_style(data->labels[i], &data->style3, LV_STATE_PRESSED);
		}

		data->buttons[i] = lv_btn_create(data->obj);
		lv_obj_add_style(data->buttons[i], &data->strs_style[i], LV_PART_MAIN);
		{
		lv_obj_add_style(data->buttons[i], &data->style, LV_PART_MAIN /*LV_STATE_DEFAULT*/);
		if (i == 4 || i == 5 || i == 6 || i == 7)
		lv_obj_add_style(data->buttons[i], &data->style3, LV_STATE_PRESSED);
		}
		lv_obj_add_event_cb(data->buttons[i], setting_btn_event_handler, LV_EVENT_SHORT_CLICKED,view_data);
		lv_obj_set_user_data(data->buttons[i], (void *)i);
         	SYS_LOG_INF("%s: %d %d %d %d\n", __func__, 132, i * 80 + 20, data->strs[i].width, data->strs[i].height);
	}
	for (int i = 0; i < ITEM_NUM; i++)
	{
		lv_label_set_text(data->labels[i], data->strs[i].txt);
         	SYS_LOG_INF("%s: %s\n", __func__, data->strs[i].txt);
		char *strs[] = {
			"gps",
			"gps_alp2",
			"g3b",
			"g3b_alp2",
			"save log",
			"save point",
			"epoc enable",
			"epoc disable ",
		};
		lv_label_set_text(data->labels[i], strs[i]);
	}

	for (int i = 0; i < 4; i++)
	{
		data->switches[i] = lv_img_create(data->obj);
		lv_img_set_src(data->switches[i], &data->res_imgs[i * 2 + 1]);
		lv_obj_set_pos(data->switches[i], data->pt_imgs[i * 2 + 1].x, data->pt_imgs[i * 2 + 1].y);
		lv_obj_add_flag(data->switches[i], LV_OBJ_FLAG_CLICKABLE);
		lv_obj_set_user_data(data->switches[i], (void *)i);
		lv_obj_add_event_cb(data->switches[i], open_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);
	}


return 0;

}

static int _load_resource(gps3_data *data)
{
    int ret;

    /* load scene */
    ret = lvgl_res_load_scene(SCENE_ID, &data->scene, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
    if (ret < 0) {
        SYS_LOG_ERR("SCENE_ID not found");
        return -ENOENT;
    }

	if (lvgl_bitmap_font_open(&data->font, DEF_FONT22_FILE) < 0)
	{
		SYS_LOG_ERR("font not found");
		return -ENOENT;
	}

#if 1 
    /* load pic resource */
    ret = lvgl_res_load_pictures_from_scene(&data->scene, _img_ids, data->res_imgs, data->pt_imgs, 8);
    if (ret < 0) {
        goto out_exit;
    }
#endif

    /* load string */
    ret = lvgl_res_load_strings_from_scene(&data->scene, _txt_ids, data->strs, ITEM_NUM);
    if (ret < 0) {
        goto out_exit;
    }
    init_txt_style(data, data->strs_style, data->strs, ITEM_NUM);

out_exit:
    if (ret < 0) {
    }

    SYS_LOG_INF("load resource succeed");
    return 0;
	return 0;
}

static int _unload_resource(gps3_data *data)
{

	printf("%s unload\n", __func__);
	if (data)
	{
		printf("%s unload 222\n", __func__);
		lvgl_bitmap_font_close(&data->font);
		lvgl_res_unload_strings(data->strs, ITEM_NUM);
		lvgl_res_unload_pictures(data->res_imgs, 8);
		lvgl_res_unload_scene(&data->scene);
	}

	return 0;
}

static int _gps3_view_preload(view_data_t *view_data)
{
    static int resource_preload = 0;

    if (resource_preload == 0) {
        lvgl_res_preload_scene_compact_default_init(SCENE_ID, NULL, 0, NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
        resource_preload = 1;
    }

    return lvgl_res_preload_scene_compact_default(SCENE_ID, VIEW_ID, 0, 0);
}

static int _gps3_view_layout(view_data_t *view_data)
{
	gps3_data *data = view_data->user_data;

	if (data == NULL)
	{
		data = app_mem_malloc(sizeof(*data));
		if (!data) 
		{
			return -ENOMEM;
		}
		memset(data, 0, sizeof(*data));
		view_data->user_data = data;
	}

	_load_resource(data);
	_view_create(view_data);
	lv_refr_now(view_data->display);
	return 0;
}

static int _gps3_view_delete(view_data_t *view_data)
{
	gps3_data *data = view_data->user_data;

	if (is_gps_points_file_open == 1)
	{
		is_gps_points_file_open = 0;
		fs_close(&gps_zfp);
	}
	printf("%s: delete resource\n", __func__);
	if (data)
	{
		for (int i = 0; i < ITEM_NUM; i++)
		{
			lv_style_reset(&data->strs_style[i]);
		}
		lv_style_reset(&data->style);
		lv_style_reset(&data->style3);

		for (int i = 0; i < ITEM_NUM; i++)
		{
			lv_obj_del(data->labels[i]);
			lv_obj_del(data->buttons[i]);
		}
		lv_obj_del(data->obj);
		_unload_resource(data);
		app_mem_free(data);
	}
	else
	{
		lvgl_res_preload_cancel_scene(SCENE_ID);
	}
	lvgl_res_unload_scene_compact(SCENE_ID);


	return 0;
}

static int _gps3_view_handler(uint16_t view_id, uint8_t msg_id, void *msg_data)
{
        view_data_t *view_data = msg_data;

        assert(view_id == VIEW_ID);

        switch (msg_id) {
        case MSG_VIEW_PRELOAD:
                return _gps3_view_preload(view_data);
        case MSG_VIEW_LAYOUT:
                return _gps3_view_layout(view_data);
        case MSG_VIEW_DELETE:
		save_gps_log_deinit();
                return _gps3_view_delete(view_data);
	case MSG_VIEW_FOCUS:
		return 0;
	case MSG_VIEW_DEFOCUS:
		return 0;
        default:
                return 0;
        }
}


VIEW_DEFINE(gps3_view, _gps3_view_handler, NULL, NULL, VIEW_ID, NORMAL_ORDER, UI_VIEW_LVGL,
            DEF_UI_VIEW_WIDTH, DEF_UI_VIEW_HEIGHT);

