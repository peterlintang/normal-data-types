
/*
 * Copyright (c) 2020 Actions Technology Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#include <assert.h>
#include <lvgl.h>
#include <lvgl/lvgl_res_loader.h>
#include <lvgl/lvgl_bitmap_font.h>

#include <ui_manager.h>
#include <view_manager.h>
#include "widgets/anim_img.h"
#include "widgets/img_number.h"



#include <res_manager_api.h>
#include "app_ui.h"
#include "app_defines.h"
#include "system_app.h"
#include <view_stack.h>
#include <acts_bluetooth/host_interface.h>

#include <bt_manager.h>
#include <sys_wakelock.h>


struct test_mode_private {
	lv_obj_t *gps_test_button;
	lv_obj_t *gps_test_label;
	lv_style_t gps_test_button_style;
	lvgl_res_string_t gps_test_str;
	lv_style_t gps_test_str_style;

	lv_obj_t *power_test_button;
	lv_obj_t *power_test_label;
	lv_style_t power_test_button_style;
	lvgl_res_string_t power_test_str;
	lv_style_t power_test_str_style;

	lv_obj_t *sensor_test_button;
	lv_obj_t *sensor_test_label;
	lv_style_t sensor_test_button_style;
	lvgl_res_string_t sensor_test_str;
	lv_style_t sensor_test_str_style;

	lv_obj_t *usb_test_button;
	lv_obj_t *usb_test_label;
	lv_style_t usb_test_button_style;
	lvgl_res_string_t usb_test_str;
	lv_style_t usb_test_str_style;

	lv_obj_t *lcd_test_button;
	lv_obj_t *lcd_test_label;
	lv_style_t lcd_test_button_style;
	lvgl_res_string_t lcd_test_str;
	lv_style_t lcd_test_str_style;

	lv_style_t style3;

	lvgl_res_scene_t scene;
	lv_font_t font;
};

static uint32_t gps_test_str_id[] = {
	GPS_TEST,
};
static uint32_t power_test_str_id[] = {
	POWER_TEST,
};
static uint32_t sensor_test_str_id[] = {
	SENSOR_TEST,
};
static uint32_t usb_test_str_id[] = {
	USB_TEST,
};
static uint32_t lcd_test_str_id[] = {
	LCD_TEST,
};

static int test_mode_preload_inited = 0;
static struct test_mode_private *private_data = NULL;

static void init_txt_style(struct test_mode_private *data, lv_style_t *sty, lvgl_res_string_t *txt, uint32_t num)
{
	for (int i = 0; i < num; i++)
	{
		lv_style_init(&sty[i]);
		lv_style_set_x(&sty[i], txt[i].x);
		lv_style_set_y(&sty[i], txt[i].y);
		lv_style_set_width(&sty[i], txt[i].width);
		lv_style_set_height(&sty[i], txt[i].height);
		lv_style_set_text_color(&sty[i], txt[i].color);
		lv_style_set_text_align(&sty[i], txt[i].align);
		lv_style_set_text_font(&sty[i], &data->font);
		SYS_LOG_INF("%s: %d %d %d %d\n", __func__, txt[i].x, txt[i].y, txt[i].width, txt[i].height);
	}
}


static void usb_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: event\n", __func__);
	sys_pm_reboot(0);
}


void gps_test_btn_event_handler(lv_event_t * e)
{
extern void gps_view_init(void);
	SYS_LOG_INF("%s: event\n", __func__);
	gps_view_init();
//	view_stack_push_view(GPS_BT_TEST_VIEW, NULL);
}
#include <fs_manager.h>
#include <fs/fs.h>
#include <fs/fs.h>
#include <fs/fs_sys.h>
//#include "cJSON.h"
static void power_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: event\n", __func__);
	view_stack_push_view(POWER_TEST_VIEW, NULL);

#if 0
	struct fs_file_t zfp;
	memset(&zfp, 0, sizeof(zfp));
	if (fs_open(&zfp, "/NAND:/hello.dat", FA_READ))
	{
		printf("open hello.dat failed\n");
		return ;
	}
	fs_seek(&zfp, 0, FS_SEEK_END);
	uint32_t file_length = fs_tell(&zfp);
	printf("hello.dat length: %u\n", file_length);
	char *test_map = (char*)app_mem_malloc(file_length + 1);
	if (test_map == NULL)
	{
		printf("malloc %u bytes failed\n", file_length);
		fs_close(&zfp);
		return ;
	}
	memset(test_map, 0, file_length + 1);
	fs_seek(&zfp, 0, FS_SEEK_SET);
	printf("fs_read: %d\n", fs_read(&zfp, test_map, file_length));
//	printf("hello.dat: %s\n", test_map);
	cJSON *root = NULL;
	root = cJSON_Parse(test_map);
	printf("json: %p\n", (root));
	printf("json: %s\n", cJSON_Print(root));
	printf("error:%s\n", cJSON_GetErrorPtr());


	app_mem_free(test_map);
	fs_close(&zfp);
#endif
}
#if 0
static void sensor_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: event\n", __func__);
	view_stack_push_view(SENSOR_TEST_VIEW, NULL);
}
#endif

static void com_test_btn_long_event_handler(lv_event_t *e)
{
	extern void com_test_btn_event_handler(lv_event_t * e);
	fs_unlink("/NAND:/calibration.txt");
	k_msleep(3);
	com_test_btn_event_handler(NULL);
}

static void lcd_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: state: %d\n", __func__, 1);
//	mag_calibration_thread_init();
	view_stack_push_view(LCD_TEST_VIEW, NULL);
	/*
	extern void com_test_btn_event_handler(lv_event_t * e);
	fs_unlink("/NAND:/calibration.txt");
	k_msleep(3);
	com_test_btn_event_handler(NULL);
	*/
}


static int test_mode_view_layout(view_data_t *view_data)
{
	int ret = 0;
	lv_obj_t *src = NULL;

	private_data = app_mem_malloc(sizeof(*private_data));
	if (private_data == NULL) return -1;

	memset(private_data, 0, sizeof(*private_data));

	view_data->user_data = private_data;

	ret = lvgl_res_load_scene(SCENE_TEST_MODE_VIEW, &private_data->scene, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
	if (ret != 0)
	{
		goto out;
	}

	if (lvgl_bitmap_font_open(&private_data->font, DEF_FONT24_FILE) < 0)
	{
		goto out;
	}

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			gps_test_str_id, 
			&private_data->gps_test_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->gps_test_str_style, &private_data->gps_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			power_test_str_id, 
			&private_data->power_test_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->power_test_str_style, &private_data->power_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			sensor_test_str_id, 
			&private_data->sensor_test_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->sensor_test_str_style, &private_data->sensor_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			usb_test_str_id, 
			&private_data->usb_test_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->usb_test_str_style, &private_data->usb_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			lcd_test_str_id, 
			&private_data->lcd_test_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->lcd_test_str_style, &private_data->lcd_test_str, 1);

	src = lv_disp_get_scr_act(view_data->display);
	if (src == NULL)
		return -1;

	lv_obj_set_style_bg_color(src, private_data->scene.background, LV_PART_MAIN);
	lv_obj_set_style_bg_opa(src, LV_OPA_COVER, LV_PART_MAIN);

	lv_style_init(&private_data->style3);
	lv_style_set_bg_opa(&private_data->style3, LV_OPA_100);
    	lv_style_set_bg_color(&private_data->style3, /*lv_palette_main(LV_PALETTE_BLUE)*/lv_color_hex(0x0000ff));
	lv_style_set_border_width(&private_data->style3, 2); // 边框宽度
	lv_style_set_border_color(&private_data->style3, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&private_data->style3, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&private_data->style3, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向

	private_data->gps_test_button = lv_btn_create(src);
	lv_style_init(&private_data->gps_test_button_style);
	lv_style_set_bg_color(&private_data->gps_test_button_style, lv_color_hex(0xFF0000));
	lv_obj_add_style(private_data->gps_test_button, &private_data->gps_test_button_style, LV_PART_MAIN);
//	lv_obj_add_style(private_data->gps_test_button, &private_data->gps_test_button_style, LV_STATE_PRESSED);
	lv_obj_add_style(private_data->gps_test_button, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->gps_test_button, private_data->gps_test_str.x, private_data->gps_test_str.y);
	lv_obj_set_size(private_data->gps_test_button, private_data->gps_test_str.width, private_data->gps_test_str.height);
	lv_obj_add_event_cb(private_data->gps_test_button, gps_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->gps_test_label = lv_label_create(private_data->gps_test_button);
//	lv_label_set_text(private_data->gps_test_label, private_data->gps_test_str.txt);
	lv_label_set_text(private_data->gps_test_label, "GPS TEST");
	lv_style_set_border_width(&private_data->gps_test_str_style, 2); // 边框宽度
	lv_style_set_border_color(&private_data->gps_test_str_style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&private_data->gps_test_str_style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&private_data->gps_test_str_style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	lv_obj_add_style(private_data->gps_test_label, &private_data->gps_test_str_style, LV_PART_MAIN);
	lv_obj_add_style(private_data->gps_test_label, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_center(private_data->gps_test_label);

	private_data->power_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->power_test_button, &private_data->power_test_button_style, 0);
//	lv_obj_add_style(private_data->power_test_button, &private_data->power_test_button_style, LV_STATE_PRESSED);
	lv_obj_add_style(private_data->power_test_button, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->power_test_button, private_data->power_test_str.x, private_data->power_test_str.y);
	lv_obj_set_size(private_data->power_test_button, private_data->power_test_str.width, private_data->power_test_str.height);
	lv_obj_add_event_cb(private_data->power_test_button, power_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->power_test_label = lv_label_create(private_data->power_test_button);
//	lv_label_set_text(private_data->power_test_label, private_data->power_test_str.txt);
	lv_label_set_text(private_data->power_test_label, "POWER TEST");
	lv_style_set_border_width(&private_data->power_test_str_style, 2); // 边框宽度
	lv_style_set_border_color(&private_data->power_test_str_style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&private_data->power_test_str_style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&private_data->power_test_str_style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	lv_obj_add_style(private_data->power_test_label, &private_data->power_test_str_style, LV_PART_MAIN);
	lv_obj_add_style(private_data->power_test_label, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_center(private_data->power_test_label);

	extern void com_test_btn_event_handler(lv_event_t * e);
	private_data->sensor_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->sensor_test_button, &private_data->sensor_test_button_style, 0);
//	lv_obj_add_style(private_data->sensor_test_button, &private_data->sensor_test_button_style, LV_STATE_PRESSED);
	lv_obj_add_style(private_data->sensor_test_button, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->sensor_test_button, private_data->sensor_test_str.x, private_data->sensor_test_str.y);
	lv_obj_set_size(private_data->sensor_test_button, private_data->sensor_test_str.width, private_data->sensor_test_str.height);
	lv_obj_add_event_cb(private_data->sensor_test_button, com_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);
	lv_obj_add_event_cb(private_data->sensor_test_button, com_test_btn_long_event_handler, LV_EVENT_LONG_PRESSED, view_data);

	private_data->sensor_test_label = lv_label_create(private_data->sensor_test_button);
//	lv_label_set_text(private_data->sensor_test_label, private_data->sensor_test_str.txt);
	lv_label_set_text(private_data->sensor_test_label, "SENSOR TEST");
	lv_style_set_border_width(&private_data->sensor_test_str_style, 2); // 边框宽度
	lv_style_set_border_color(&private_data->sensor_test_str_style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&private_data->sensor_test_str_style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&private_data->sensor_test_str_style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	lv_obj_add_style(private_data->sensor_test_label, &private_data->sensor_test_str_style, LV_PART_MAIN);
	lv_obj_add_style(private_data->sensor_test_label, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_center(private_data->sensor_test_label);

	private_data->usb_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->usb_test_button, &private_data->usb_test_button_style, 0);
//	lv_obj_add_style(private_data->usb_test_button, &private_data->usb_test_button_style, LV_STATE_PRESSED);
	lv_obj_add_style(private_data->usb_test_button, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->usb_test_button, private_data->usb_test_str.x, private_data->usb_test_str.y);
	lv_obj_set_size(private_data->usb_test_button, private_data->usb_test_str.width, private_data->usb_test_str.height);
	lv_obj_add_event_cb(private_data->usb_test_button, usb_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->usb_test_label = lv_label_create(private_data->usb_test_button);
//	lv_label_set_text(private_data->usb_test_label, private_data->usb_test_str.txt);
	lv_label_set_text(private_data->usb_test_label, "USB TEST");
	lv_style_set_border_width(&private_data->usb_test_str_style, 2); // 边框宽度
	lv_style_set_border_color(&private_data->usb_test_str_style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&private_data->usb_test_str_style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&private_data->usb_test_str_style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	lv_obj_add_style(private_data->usb_test_label, &private_data->usb_test_str_style, LV_PART_MAIN);
	lv_obj_add_style(private_data->usb_test_label, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_center(private_data->usb_test_label);

	private_data->lcd_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->lcd_test_button, &private_data->lcd_test_button_style, 0);
//	lv_obj_add_style(private_data->lcd_test_button, &private_data->lcd_test_button_style, LV_STATE_PRESSED);
	lv_obj_add_style(private_data->lcd_test_button, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->lcd_test_button, private_data->lcd_test_str.x, private_data->lcd_test_str.y);
	lv_obj_set_size(private_data->lcd_test_button, private_data->lcd_test_str.width, private_data->lcd_test_str.height);
	lv_obj_add_event_cb(private_data->lcd_test_button, lcd_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->lcd_test_label = lv_label_create(private_data->lcd_test_button);
//	lv_label_set_text(private_data->lcd_test_label, private_data->lcd_test_str.txt);
	lv_label_set_text(private_data->lcd_test_label, "LCD TEST");
	lv_style_set_border_width(&private_data->lcd_test_str_style, 2); // 边框宽度
	lv_style_set_border_color(&private_data->lcd_test_str_style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&private_data->lcd_test_str_style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&private_data->lcd_test_str_style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	lv_obj_add_style(private_data->lcd_test_label, &private_data->lcd_test_str_style, LV_PART_MAIN);
	lv_obj_add_style(private_data->lcd_test_label, &private_data->style3, LV_STATE_PRESSED);
	lv_obj_center(private_data->lcd_test_label);


	lv_refr_now(view_data->display);

error2:
out:
	return 0;
}

static int test_mode_view_preload(view_data_t *view_data)
{
	if (test_mode_preload_inited == 0) {
		lvgl_res_preload_scene_compact_default_init(SCENE_TEST_MODE_VIEW, NULL, 0,
			NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
		test_mode_preload_inited = 1;
	}

	return lvgl_res_preload_scene_compact_default(SCENE_TEST_MODE_VIEW, TEST_MODE_VIEW, 0, 0);
}

static int test_mode_view_delete(view_data_t *view_data)
{



	lvgl_bitmap_font_close(&private_data->font);
	
	lvgl_res_unload_strings(&private_data->gps_test_str, 1);
	lvgl_res_unload_strings(&private_data->power_test_str, 1);
	lvgl_res_unload_strings(&private_data->sensor_test_str, 1);
	lvgl_res_unload_strings(&private_data->usb_test_str, 1);
	lvgl_res_unload_strings(&private_data->lcd_test_str, 1);

	lv_style_reset(&private_data->gps_test_str_style);
	lv_style_reset(&private_data->power_test_str_style);
	lv_style_reset(&private_data->sensor_test_str_style);
	lv_style_reset(&private_data->usb_test_str_style);
	lv_style_reset(&private_data->lcd_test_str_style);
	lv_style_reset(&private_data->style3);

	
	
	lvgl_res_unload_scene(&private_data->scene);

	app_mem_free(private_data);
	private_data = NULL;


	lvgl_res_preload_cancel_scene(SCENE_TEST_MODE_VIEW);

	lvgl_res_unload_scene_compact(SCENE_TEST_MODE_VIEW);
	return 0;
}


int _test_mode_view_handler(uint16_t view_id, uint8_t msg_id, void *msg_data)
{
	view_data_t *view_data = msg_data;

	assert(view_id == TEST_MODE_VIEW);

	switch (msg_id) {
	case MSG_VIEW_PRELOAD:
		return test_mode_view_preload(view_data);
	case MSG_VIEW_LAYOUT:
		return test_mode_view_layout(view_data);
	case MSG_VIEW_DELETE:
		return test_mode_view_delete(view_data);
	default:
		return 0;
	}
}

VIEW_DEFINE(test_mode_view, _test_mode_view_handler, NULL,
		NULL, TEST_MODE_VIEW, NORMAL_ORDER, UI_VIEW_LVGL, DEF_UI_VIEW_WIDTH, DEF_UI_VIEW_HEIGHT);


