/*
 * Copyright (c) 2019 Actions Semiconductor Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @file system shell
 */

#define SYS_LOG_NO_NEWLINE
#ifdef SYS_LOG_DOMAIN
#undef SYS_LOG_DOMAIN
#endif
#define SYS_LOG_DOMAIN "system_shell"

#include <os_common_api.h>
#include <mem_manager.h>
#include <stdio.h>
#include <string.h>
#include <shell/shell.h>
#include <stdlib.h>
#include <limits.h>
#include <property_manager.h>
#include <sys_wakelock.h>
#ifdef CONFIG_MEDIA_PLAYER
#include <media_player.h>
#endif



#if 1

#include <math.h>
#include "EKF.h"
void EKF_init(ekf_t* ekf, float ref_mx, float ref_my, float ref_mz, float N_Q, float N_P, float N_R) 
{
	// Initialization:
	// Prediction error covariance matrix
	float sum = 0;
	float M = 0;
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			if (i == j) {
				ekf->P[i][j] = N_P;
			}
			else {
				ekf->P[i][j] = 0.0f;
			}
		}
	}

	// Process noise covariance matrix
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			if (i == j) {
				ekf->Q[i][j] = N_Q;
			}
			else {
				ekf->Q[i][j] = 0.0f;
			}
		}
	}

	// Measurement noise covariance matrix
	for (uint8_t i = 0; i < 6; i++) {
		for (uint8_t j = 0; j < 6; j++) {
			if (i == j) {
				ekf->R[i][j] = N_R;
			}
			else {
				ekf->R[i][j] = 0.0f;
			}
		}
	}

	ekf->x[0] = 1;
	ekf->x[1] = 0;
	ekf->x[2] = 0;
	ekf->x[3] = 0;


	// Normalize Reference Magnetic Vector
	sum =  ref_mx * ref_mx + ref_my * ref_my + ref_mz * ref_mz;
	printf("sum: %f\n", sum);
//	M = sqrt(ref_mx * ref_mx + ref_my * ref_my + ref_mz * ref_mz);
	M = sqrt(sum);
	printf("M: %f\n", M);
	ekf->ref_mx = ref_mx / M;
	ekf->ref_my = ref_my / M;
	ekf->ref_mz = ref_mz / M;
	printf("%s: before normalize %f %f %f, after %f %f %f, M %f\n", __func__, ref_mx, ref_my, ref_mz, ekf->ref_mx, ekf->ref_my, ekf->ref_mz, M);
}


void EKF_update(ekf_t* ekf, float euler[3], float ax, float ay, float az, float p, float q, float r, float mx, float my, float mz, float dt) {
	// Variable Definitions
	float F[4][4];	// Jacobian matrix of F
	float H[6][4];	// Jacobian matrix of H
	float FP[4][4];
	float FPFt[4][4];
	float HPp[6][4];
	float HPpHt[6][6];
	float PpHt[4][6];
	float S_inv[6][6];
	float Hxp[6];
	float z[6];
	float zmHxp[6];
	float KzmHxp[4];
	float KH[4][4];
	float KHPp[4][4];
	float G;
	float M;
	uint8_t mat_error;


	// Normalization
	G = sqrt(ax * ax + ay * ay + az * az);
	M = sqrt(powf(mx, 2.0) + powf(my, 2.0) + powf(mz, 2.0));
	ax = ax / G;
	ay = ay / G;
	az = az / G;
	mx = mx / M;
	my = my / M;
	mz = mz / M;


	// Calculate the Jacobian matrix of F
	F[0][0] = 1;
	F[0][1] = -p * dt / 2;
	F[0][2] = -q * dt / 2;
	F[0][3] = -r * dt / 2;

	F[1][0] = p * dt / 2;
	F[1][1] = 1;
	F[1][2] = r * dt / 2;
	F[1][3] = -q * dt / 2;

	F[2][0] = q * dt / 2;
	F[2][1] = -r * dt / 2;
	F[2][2] = 1;
	F[2][3] = p * dt / 2;

	F[3][0] = r * dt / 2;
	F[3][1] = q * dt / 2;
	F[3][2] = -p * dt / 2;
	F[3][3] = 1;


	// Prediction of x
	ekf->xp[0] = F[0][0] * ekf->x[0] + F[0][1] * ekf->x[1] + F[0][2] * ekf->x[2] + F[0][3] * ekf->x[3];
	ekf->xp[1] = F[1][0] * ekf->x[0] + F[1][1] * ekf->x[1] + F[1][2] * ekf->x[2] + F[1][3] * ekf->x[3];
	ekf->xp[2] = F[2][0] * ekf->x[0] + F[2][1] * ekf->x[1] + F[2][2] * ekf->x[2] + F[2][3] * ekf->x[3];
	ekf->xp[3] = F[3][0] * ekf->x[0] + F[3][1] * ekf->x[1] + F[3][2] * ekf->x[2] + F[3][3] * ekf->x[3];


	// Prediction of P
	/* Pp = F*P*F' + Q; */
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			FP[i][j] = F[i][0] * ekf->P[0][j] + F[i][1] * ekf->P[1][j] + F[i][2] * ekf->P[2][j] + F[i][3] * ekf->P[3][j];
		}
	}

	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			FPFt[i][j] = FP[i][0] * F[j][0] + FP[i][1] * F[j][1] + FP[i][2] * F[j][2] + FP[i][3] * F[j][3];
		}
	}

	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			ekf->Pp[i][j] = FPFt[i][j] + ekf->Q[i][j];
		}
	}


	// Calculate the Jacobian matrix of h
	H[0][0] = -ekf->x[2];
	H[0][1] = ekf->x[3];
	H[0][2] = -ekf->x[0];
	H[0][3] = ekf->x[1];

	H[1][0] = ekf->x[1];
	H[1][1] = ekf->x[0];
	H[1][2] = ekf->x[3];
	H[1][3] = ekf->x[2];

	H[2][0] = ekf->x[0];
	H[2][1] = -ekf->x[1];
	H[2][2] = -ekf->x[2];
	H[2][3] = ekf->x[3];

	H[3][0] = ekf->x[0] * ekf->ref_mx + ekf->x[3] * ekf->ref_my - ekf->x[2] * ekf->ref_mz;
	H[3][1] = ekf->x[1] * ekf->ref_mx + ekf->x[2] * ekf->ref_my + ekf->x[3] * ekf->ref_mz;
	H[3][2] = -ekf->x[2] * ekf->ref_mx + ekf->x[1] * ekf->ref_my - ekf->x[0] * ekf->ref_mz;
	H[3][3] = -ekf->x[3] * ekf->ref_mx + ekf->x[0] * ekf->ref_my + ekf->x[1] * ekf->ref_mz;

	H[4][0] = -ekf->x[3] * ekf->ref_mx + ekf->x[0] * ekf->ref_my + ekf->x[1] * ekf->ref_mz;
	H[4][1] = ekf->x[2] * ekf->ref_mx - ekf->x[1] * ekf->ref_my + ekf->x[0] * ekf->ref_mz;
	H[4][2] = ekf->x[1] * ekf->ref_mx + ekf->x[2] * ekf->ref_my + ekf->x[3] * ekf->ref_mz;
	H[4][3] = -ekf->x[0] * ekf->ref_mx - ekf->x[3] * ekf->ref_my + ekf->x[2] * ekf->ref_mz;

	H[5][0] = ekf->x[2] * ekf->ref_mx - ekf->x[1] * ekf->ref_my + ekf->x[0] * ekf->ref_mz;
	H[5][1] = ekf->x[3] * ekf->ref_mx - ekf->x[0] * ekf->ref_my - ekf->x[1] * ekf->ref_mz;
	H[5][2] = ekf->x[0] * ekf->ref_mx + ekf->x[3] * ekf->ref_my - ekf->x[2] * ekf->ref_mz;
	H[5][3] = ekf->x[1] * ekf->ref_mx + ekf->x[2] * ekf->ref_my + ekf->x[3] * ekf->ref_mz;


	// S = (H*Pp*H' + R);
	// H*Pp
	for (uint8_t i = 0; i < 6; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			HPp[i][j] = H[i][0] * ekf->Pp[0][j] + H[i][1] * ekf->Pp[1][j] + H[i][2] * ekf->Pp[2][j] + H[i][3] * ekf->Pp[3][j];
		}
	}

	// H*Pp*H'
	for (uint8_t i = 0; i < 6; i++) {
		for (uint8_t j = 0; j < 6; j++) {
			HPpHt[i][j] = HPp[i][0] * H[j][0] + HPp[i][1] * H[j][1] + HPp[i][2] * H[j][2] + HPp[i][3] * H[j][3];
		}
	}

	// H*Pp*H' + R
	for (uint8_t i = 0; i < 6; i++) {
		for (uint8_t j = 0; j < 6; j++) {
			HPpHt[i][j] = HPpHt[i][j] + ekf->R[i][j]; // S
		}
	}


	// K = Pp*H'*(S.inverse);
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 6; j++) {
			PpHt[i][j] = ekf->Pp[i][0] * H[j][0] + ekf->Pp[i][1] * H[j][1] + ekf->Pp[i][2] * H[j][2] + ekf->Pp[i][3] * H[j][3];
		}
	}

	mat_error = inverse_matrix(HPpHt, S_inv);
	if (!mat_error) {
		return;
	}

	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 6; j++) {
			ekf->K[i][j] = PpHt[i][0] * S_inv[0][j] + PpHt[i][1] * S_inv[1][j] + PpHt[i][2] * S_inv[2][j] + PpHt[i][3] * S_inv[3][j] + PpHt[i][4] * S_inv[4][j] + PpHt[i][5] * S_inv[5][j];
		}
	}


	// x = xp + K*(z - H*xp);
	// H*xp
	for (uint8_t i = 0; i < 6; i++) {
		Hxp[i] = ekf->xp[0] * H[i][0] + ekf->xp[1] * H[i][1] + ekf->xp[2] * H[i][2] + ekf->xp[3] * H[i][3];
	}

	z[0] = ax;
	z[1] = ay;
	z[2] = az;
	z[3] = mx;
	z[4] = my;
	z[5] = mz;

	// (z - H*xp)
	for (uint8_t i = 0; i < 6; i++) {
		zmHxp[i] = (z[i] - Hxp[i]);
	}

	// K*(z - H*xp)
	for (uint8_t i = 0; i < 4; i++) {
		KzmHxp[i] = 0;
		for (uint8_t j = 0; j < 6; j++) {
			KzmHxp[i] += ekf->K[i][j] * zmHxp[j];
		}
	}

	// xp + K*(z - H*xp)
	for (uint8_t i = 0; i < 4; i++) {
		ekf->x[i] = ekf->xp[i] + KzmHxp[i];
	}


	// P = Pp - K*H*Pp;
	// K*H
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			KH[i][j] = ekf->K[i][0] * H[0][j] + ekf->K[i][1] * H[1][j] + ekf->K[i][2] * H[2][j] + ekf->K[i][3] * H[3][j] + ekf->K[i][4] * H[4][j] + ekf->K[i][5] * H[5][j];
		}
	}

	// K*H*Pp
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			KHPp[i][j] = KH[i][0] * ekf->Pp[0][j] + KH[i][1] * ekf->Pp[1][j] + KH[i][2] * ekf->Pp[2][j] + KH[i][3] * ekf->Pp[3][j];
		}
	}

	// P = Pp - K*H*Pp
	for (uint8_t i = 0; i < 4; i++) {
		for (uint8_t j = 0; j < 4; j++) {
			ekf->P[i][j] = ekf->Pp[i][j] - KHPp[i][j];
		}
	}


	EKFquaternionToEuler(ekf->x, euler);

}

uint8_t inverse_matrix(float a[6][6], float a_inv[6][6]) {
	// Initialize matrix
	for (uint8_t i = 0; i < 6; i++) {
		for (uint8_t j = 0; j < 6; j++) {
			if (i != j)
				a_inv[i][j] = 0;
			else
				a_inv[i][j] = 1;
		}
	}

	// Applying Gauss Jordan Elimination
	float ratio = 1.0;
	for (uint8_t i = 0; i < 6; i++)
	{
		if (a[i][i] == 0.0)
		{
			return 0;
		}
		for (uint8_t j = 0; j < 6; j++)
		{
			if (i != j)
			{
				ratio = a[j][i] / a[i][i];
				for (uint8_t k = 0; k < 6; k++)
				{
					a[j][k] = a[j][k] - ratio * a[i][k];
					a_inv[j][k] = a_inv[j][k] - ratio * a_inv[i][k];
				}
			}
		}
	}
	// Row Operation to Make Principal Diagonal to 1
	for (uint8_t i = 0; i < 6; i++)
	{
		for (uint8_t j = 0; j < 6; j++)
		{
			a_inv[i][j] = a_inv[i][j] / a[i][i];
		}
	}
	return 1;
}

void EKFquaternionToEuler(float q[4], float euler[3]) {
	float phi = atan2f(2 * (q[2] * q[3] + q[0] * q[1]), 1 - 2 * (q[1] * q[1] + q[2] * q[2]));

	float sinp = 2 * (q[1] * q[3] - q[0] * q[2]);
	float theta = 0.0;

	if (fabsf(sinp) >= 1) {
		theta = (sinp >= 0) ? M_PI / 2 : -M_PI / 2;
	}
	else {
		theta = -asinf(sinp);
	}

	float psi = atan2f(2 * (q[1] * q[2] + q[0] * q[3]), 1 - 2 * (q[2] * q[2] + q[3] * q[3]));

	euler[0] = phi;
	euler[1] = theta;
	euler[2] = psi;
}



#endif

extern void mem_manager_dump_ext(int dump_detail, const char* match_value);

static int shell_set_config(const struct shell *shell,
					size_t argc, char **argv)
{
	int ret = 0;

	if (argc < 2) {
		SYS_LOG_INF("argc <\n");
		return 0;
	}

#ifdef CONFIG_PROPERTY
	if (argc < 3) {
		ret = property_set(argv[1], argv[1], 0);
	} else {
		ret = property_set(argv[1], argv[2], strlen(argv[2]));
	}
#endif
	if (ret < 0) {
		SYS_LOG_INF("%s failed %d\n", argv[1], ret);
		return -1;
	}
#ifdef CONFIG_PROPERTY
	property_flush(NULL);
#endif
	SYS_LOG_INF("%s : %s ok\n", argv[1], argv[2]);
	return 0;
}

#ifdef CONFIG_MEDIA_PLAYER
static int shell_set_effect_config(const struct shell *shell,
					size_t argc, char **argv)
{
	if (argc < 2) {
		printk("argc %d < 2\n",argc);
		return 0;
	}

    media_player_set_effect_bypass(atoi(argv[1]));

	SYS_LOG_INF("set_music_effect %s ok\n", argv[1]);
	return 0;
}

static int shell_set_voice_effect_config(const struct shell *shell,
					size_t argc, char **argv)
{
	if (argc < 2) {
		SYS_LOG_INF("argc %d < 2\n",argc);
		return 0;
	}

	media_player_set_voice_effect_bypass(atoi(argv[1]), atoi(argv[2]));

	SYS_LOG_INF("set_voice %s : %s ok\n", argv[1], argv[2]);
	return 0;
}
#endif /* CONFIG_MEDIA_PLAYER */

static int shell_dump_meminfo(const struct shell *shell,
					size_t argc, char **argv)
{
	if (argc == 1) {
		mem_manager_dump();
	} else if (argc == 2) {
		SYS_LOG_INF("argv[1] %s \n",argv[1]);
		mem_manager_dump_ext(atoi(argv[1]), NULL);
	} else if (argc == 3) {
		SYS_LOG_INF("argv[1] %s  argv[2] %s \n",argv[1], argv[2]);
		mem_manager_dump_ext(atoi(argv[1]), argv[2]);
	}

	return 0;
}

#ifdef CONFIG_SYS_WAKELOCK
static int shell_wake_lock(const struct shell *shell, size_t argc, char **argv)
{
	if (argc == 2) {
		if (!strcmp(argv[1], "lock")) {
			shell_print(shell, "wake dbg use lock\n");
			sys_wake_lock_ext(FULL_WAKE_LOCK,SYS_WAKE_LOCK_USER);
		} else if (!strcmp(argv[1], "unlock")) {
			shell_print(shell, "wake dbg use unlock\n");
			sys_wake_unlock_ext(FULL_WAKE_LOCK,SYS_WAKE_LOCK_USER);
		} else if (!strcmp(argv[1], "dump")) {
			sys_wakelocks_dump();
		} 
	}
	return 0;
}
#endif

#include "drivers/uart.h"
extern void uart2_tx_data(unsigned char buf );
static int shell_show_gps(const struct shell *shell, size_t argc, char **argv)
{
	extern void gps_view_init(void);

	gps_view_init();
	return 0;
}
static int shell_test_gps(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);


	unsigned char *str = "$PAIR067*3B\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}

	return 0;

}

static int shell_get_alp_status(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);


	unsigned char *str = "$PAIR733*3D\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
	return 0;

}

static int shell_set_alp2(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);


	unsigned char *str = "$PAIR732,2*22\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
	return 0;

}

static int shell_set_aic(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);


if (!strcmp(argv[1], "1"))
{
	unsigned char *str = "$PAIR074,1*24\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
}
else
{
	unsigned char *str = "$PAIR074,0*25\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
}
	return 0;

}

static int shell_set_lcd(const struct shell *shell, size_t argc, char **argv)
{
	/*
	extern int test_io(char* argv);
	test_io(argv[1]);
	*/
	return 0;

}

static int shell_set_gps_epoc(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
	unsigned char *str = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);

	str = "$PAIR496,1*2C\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart2_tx_data(str[i]);
	}
	k_sleep(K_MSEC(100));

	str = "$PAIR498,5*26\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart2_tx_data(str[i]);
	}
	k_sleep(K_MSEC(100));

	return 0;

}

static int shell_get_gps_epoc(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
	unsigned char *str2 = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);


	str2 = "$PAIR508*37\r\n";
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
	k_sleep(K_MSEC(100));

	str2 = "$PAIR509,1*2B\r\n";
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
	k_sleep(K_MSEC(100));

	str2 = "$PAIR509,2*28\r\n";
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
	k_sleep(K_MSEC(100));

	str2 = "$PAIR509,4*2E\r\n";
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
	k_sleep(K_MSEC(100));

	str2 = "$PAIR067*3B\r\n";
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
	k_sleep(K_MSEC(100));

	return 0;

}

static int shell_save_gps_epoc(const struct shell *shell, size_t argc, char **argv)
{
	#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
	unsigned char *str = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);

	str = "$PAIR511*3F\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
	k_sleep(K_MSEC(100));

	str = "$PAIR513*3D\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
	k_sleep(K_MSEC(100));

	return 0;

}

#include "lps22df_reg.h"
#include "spl06001.h"
       extern uint8_t spl06_init(void);
        extern void SPL06_Init(T_SPL06_calibPara *ptSPL06_calibPara);
        extern T_SPL06_calibPara t_SPL06_calibPara;
        extern float ReadSPL06_Pressure(T_SPL06_calibPara *ptSPL06_calibPara);
        extern void spl06_start(uint8_t mode);
        extern uint8_t spl06_update(float *Temp,float *Press);
        extern float Caculate_Altitude(float GasPress);
        extern float mts4b_read_temp(void);
        extern int mts4b_start(void);
        extern void lsm6dsl_read_data_polling(float *acc_mg, float *ang_mdps);
        extern void lsm6dsv16x_read_data_polling(float *acc_mg, float *ang_mdps, uint32_t *timestamp);
	extern void pressure_lps22df_id_get(uint8_t *chip_id);
	extern void lsm6dsv16x_read_data_polling(float *acc, float *ang, uint32_t *timestamp);
	extern void lsm6dsv16x_init(void);
	extern uint8_t VCM119xL_ReadData(float *mag);

static int shell_read_temp(const struct shell *shell, size_t argc, char **argv)
{
	extern float mts4b_read_temp(void);
	float temp =0;
	temp = mts4b_read_temp();
	printf("temp: %.2f\n", temp);
	mts4b_start();
	return 0;
}

#include "SPA06_003.h"
static int shell_read_pres(const struct shell *shell, size_t argc, char **argv)
{
	float pa =0;
	extern void lps22df_init(void);
	extern void lps22df_read_data_polling(float *hpa, float *deg_c);

	uint8_t chip_id = 0x00;
        float deg_c = 0.0;
        float hight = 0.0;
        float temp = 0.0;
	/*
	lps22df_init();
	k_msleep(200);
	lps22df_read_data_polling(&pa, &deg_c);
	printf("pa:%.2f   deg: %.2f, \n",pa, deg_c);
	*/


        pressure_lps22df_id_get(&chip_id);
        printf("%s: pressure chip id: %x, %x\n", __func__, chip_id, LPS22DF_ID);
        if (chip_id == LPS22DF_ID)
        {
                lps22df_init();
        }
        else
        {
                spl07_003_init();
                spl07_003_start_continuous(CONTINUOUS_P_AND_T);
        }

	k_msleep(200);


        if (chip_id == LPS22DF_ID)
        {
                extern void lps22df_read_data_polling(float *hpa, float *deg_c);

                lps22df_read_data_polling(&pa, &deg_c);
                hight = Caculate_Altitude(pa * 100);
        }
        else
        {
                spl07_003_get_raw_temp();
                spl07_003_get_raw_pressure();
                spl07_003_get_temperature();
                pa = spl07_003_get_pressure();
                pa = pa / 100.0;
                hight = Caculate_Altitude(pa * 100);
                printf("spl003 tmp: %.2f\n", spl07_003_get_temperature());
        }

         printf("pa:%.2f   gao:%.2fm, deg: %.2f, temp: %.2f\n",pa,hight, deg_c, temp);


	return 0;
}

#include <soc_regs.h>
static int shell_test_power(const struct shell *shell, size_t argc, char **argv)
{
        sys_write32(sys_read32(PWRGATE_DIG)
                         & ~(1 << 20)
                         & ~(1 << 28)
                         & ~(1 << 26), PWRGATE_DIG);

	k_sleep(K_MSEC(100 * 10));
	printk("PWRGATE_DIG_ACK=0x%x\n", sys_read32(PWRGATE_DIG_ACK));
	return 0;
}

#if 1
#include <drivers/i2c.h>
static void VCM1195L_init(void)
{
	const struct device *dev;

	dev = device_get_binding("I2C_0");

	if (i2c_reg_write_byte(dev, 0x0c, 0x0a, 0x49) < 0) {
		printf( "Failed to write to device: %s %d\n", __func__, __LINE__);
		return ;
	}
	printf("%s: init vcm1195l\n", __func__);
}

#define Kp 10.0f                  // 这里的KpKi是用于调整加速度计修正陀螺仪的速度
#define Ki 0.008f

//#define halfT 0.01f             // 采样周期的一半，用于求解四元数微分方程时计算角增量
				
static float halfT = 0.01f;             // 采样周期的一半，用于求解四元数微分方程时计算角增量

static float q0 = 1, q1 = 0, q2 = 0, q3 = 0;    // 初始位置姿态角为：0、0、0，对应四元数为：1、0、0、0

static float exInt = 0, eyInt = 0, ezInt = 0;    
//重力加速度在三轴上的分量与用当前姿态计算得来的重力在三轴上的分量的误差的积分

static float  Q_ANGLE_X= 0, Q_ANGLE_Y = 0, Q_ANGLE_Z = 0;   


static void AHRSupdate(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz) 
{  
						float q0temp,q1temp,q2temp,q3temp;//四元数暂存变量，求解微分方程时要用
            float norm;               
            float hx, hy, hz, bx, bz;
            float vx, vy, vz, wx, wy, wz; 
            float ex, ey, ez;  
#if 0
	    printf("%s:11111 q0: %.3f, q1: %.3f, q2: %.3f, q3: %.3f\n", __func__, q0, q1, q2, q3);
	    printf("%s: gx: %.3f gy: %.3f gz: %.3f ax: %.3f ay: %.3f az: %.3f mx: %.3f my: %.3f mz: %.3f\n", 
			    __func__,
			    gx,
			    gy,
			    gz,
			    ax,
			    ay,
			    az,
			    mx,
			    my,
			    mz);
#endif
  
            // 定义一些辅助变量用于转换矩阵
            float q0q0 = q0*q0;  
            float q0q1 = q0*q1;  
            float q0q2 = q0*q2;  
            float q0q3 = q0*q3;  
            float q1q1 = q1*q1;  
            float q1q2 = q1*q2;  
            float q1q3 = q1*q3;  
            float q2q2 = q2*q2;  
            float q2q3 = q2*q3;  
            float q3q3 = q3*q3;  
             
            // 归一化加速度计和地磁计的度数 
            norm = sqrt(ax*ax + ay*ay + az*az);   
            ax = ax / norm;  
            ay = ay / norm;  
            az = az / norm;  
            norm = sqrt(mx*mx + my*my + mz*mz);   
            mx = mx / norm;  
            my = my / norm;  
            mz = mz / norm;  
#if 0
	    printf("%s: mx: %.3f, my: %.3f, mz: %.3f\n", __func__, mx, my, mz);
#endif
             
			
            //将b系中的地磁计分量[mx,my,mz]转换到n系,得到[hx,hy,hz]  
            hx = 2*mx*(0.5 - q2q2 - q3q3) + 2*my*(q1q2 - q0q3) + 2*mz*(q1q3 + q0q2);  
            hy = 2*mx*(q1q2 + q0q3) + 2*my*(0.5 - q1q1 - q3q3) + 2*mz*(q2q3 - q0q1);  
            hz = 2*mx*(q1q3 - q0q2) + 2*my*(q2q3 + q0q1) + 2*mz*(0.5 - q1q1 - q2q2);  
			//n系x轴指北，则在n系中hy应该为0，但是经过加计修正的旋转矩阵有偏航角误差，
			//所以这里算出的hy不为0，包含了偏航角误差
#if 0
	    printf("%s: hx: %.3f, hy: %.3f, hz: %.3f\n", __func__, hx, hy, hz);
#endif
			
			//因为转换后的n系和实际的n系只差偏航角，所以z方向一样，磁力相等
            //得到实际n系中的地磁向量的真实值[bx,bz,by],其中by=0   
            bx = sqrt((hx*hx) + (hy*hy));  
            bz = hz;     
 
            //再将n系中的地磁向量[bx，by,bz]转换到b系中，得到[wx,wy,wz]
            wx = 2*bx*(0.5 - q2q2 - q3q3) + 2*bz*(q1q3 - q0q2);  
            wy = 2*bx*(q1q2 - q0q3) + 2*bz*(q0q1 + q2q3);  
            wz = 2*bx*(q0q2 + q1q3) + 2*bz*(0.5 - q1q1 - q2q2);  
			//再转回到b系时，[wx,wy,wz]包含了偏航角误差
#if 0
	    printf("%s: wx: %.3f, wy: %.3f, wz: %.3f\n", __func__, wx, wy, wz);
#endif
 
            //n系中重力加速度[0,0,1]转换到b系中得到三个分量[vx,vy,vz]        
            vx = 2*(q1q3 - q0q2);  
            vy = 2*(q0q1 + q2q3);  
            vz = q0q0 - q1q1 - q2q2 + q3q3;    
             
            //计算[wx,wy,wz] X [mx,my,mz],[ax,at,az] X [vx,vy,vz]，得到两个误差后求和
            ex = (ay*vz - az*vy) + (my*wz - mz*wy);  
            ey = (az*vx - ax*vz) + (mz*wx - mx*wz);  
            ez = (ax*vy - ay*vx) + (mx*wy - my*wx);  
#if 0
	    printf("%s: q0: %.3f, q1: %.3f, q2: %.3f, q3: %.3f\n", __func__, q0, q1, q2, q3);
	    printf("%s: vx: %.3f, vy: %.3f, vz: %.3f\n", __func__, vx, vy, vz);
	    printf("%s: ay*vz - az*vy: %.3f, my*wz - mz*wy: %.3f\n", __func__, ay*vz - az*vy, my*wz - mz*wy);
#endif
             
            //PI控制器中的积分部分
            exInt = exInt + ex*Ki * halfT * 2;//* (1.0f / sampleFreq);  
            eyInt = eyInt + ey*Ki * halfT * 2;//* (1.0f / sampleFreq);  
            ezInt = ezInt + ez*Ki * halfT * 2;//* (1.0f / sampleFreq);  
            
            //误差经过PI控制器后输出,然后补偿到角速度的三个分量，Kp、Ki是需要调节的参数
            gx = gx + Kp*ex + exInt;  
            gy = gy + Kp*ey + eyInt;  
            gz = gz + Kp*ez + ezInt;               
            
            //一阶龙格库塔法更新四元数  
            //q0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;  
            //q1 = q1 + (q0*gx + q2*gz - q3*gy)*halfT;  
            //q2 = q2 + (q0*gy - q1*gz + q3*gx)*halfT;  
            //q3 = q3 + (q0*gz + q1*gy - q2*gx)*halfT; 
	//下面进行姿态的更新，也就是四元数微分方程的求解
	q0temp=q0;
	q1temp=q1;
	q2temp=q2;
	q3temp=q3;
	//采用一阶解法更新四元数
	q0 = q0temp + (-q1temp*gx - q2temp*gy -q3temp*gz)*halfT;
	q1 = q1temp + (q0temp*gx + q2temp*gz -q3temp*gy)*halfT;
	q2 = q2temp + (q0temp*gy - q1temp*gz +q3temp*gx)*halfT;
	q3 = q3temp + (q0temp*gz + q1temp*gy -q2temp*gx)*halfT;						
             
            // 归一化四元数
            norm = sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);  
            q0 = q0 / norm;  
            q1 = q1 / norm;  
            q2 = q2 / norm;  
            q3 = q3 / norm;  
#if 0
	    printf("%s:2222 norm: %.3f q0: %.3f, q1: %.3f, q2: %.3f, q3: %.3f\n", __func__, norm, q0, q1, q2, q3);
#endif
						
							//四元数到欧拉角的转换
	//其中YAW航向角由于加速度计对其没有修正作用，因此也可以直接用陀螺仪积分代替
	//Q_ANGLE_Z = Q_ANGLE_Z + gz*halfT*2*57.3; // yaw
	Q_ANGLE_Z = atan2(2*(q1*q2 + q0*q3),q0*q0+q1*q1-q2*q2-q3*q3) * 57.3;
	Q_ANGLE_Y = asin(-2 * q1 * q3 + 2 * q0* q2)*57.3; 
	Q_ANGLE_X = atan2(2 * q2 * q3 + 2 * q0 * q1,-2 * q1 * q1 - 2 * q2* q2 + 1)* 57.3; 
}




#define sampleFreq	1000.0f			// sample frequency in Hz
#define twoKpDef	(2.0f * 0.5f * 10)	// 2 * proportional gain
#define twoKiDef	(2.0f * 0.004f)	// 2 * integral gain

//---------------------------------------------------------------------------------------------------
// Variable definitions

volatile float twoKp = twoKpDef;											// 2 * proportional gain (Kp)
volatile float twoKi = twoKiDef;											// 2 * integral gain (Ki)
//volatile float q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;					// quaternion of sensor frame relative to auxiliary frame
volatile float integralFBx = 0.0f,  integralFBy = 0.0f, integralFBz = 0.0f;	// integral error terms scaled by Ki


static float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}

static void MahonyAHRSupdate(float q[4], float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz) 
{
	float recipNorm;
    float q0q0, q0q1, q0q2, q0q3, q1q1, q1q2, q1q3, q2q2, q2q3, q3q3;  
	float hx, hy, bx, bz;
	float halfvx, halfvy, halfvz, halfwx, halfwy, halfwz;
	float halfex, halfey, halfez;
	float qa, qb, qc;

	/*
	// Use IMU algorithm if magnetometer measurement invalid (avoids NaN in magnetometer normalisation)
	if((mx == 0.0f) && (my == 0.0f) && (mz == 0.0f)) {
		MahonyAHRSupdateIMU(q, gx, gy, gz, ax, ay, az);
		return;
	}
	*/

	// Compute feedback only if accelerometer measurement valid (avoids NaN in accelerometer normalisation)
	if(!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f))) {

		// Normalise accelerometer measurement
		recipNorm = invSqrt(ax * ax + ay * ay + az * az);
		ax *= recipNorm;
		ay *= recipNorm;
		az *= recipNorm;     

		// Normalise magnetometer measurement
		recipNorm = invSqrt(mx * mx + my * my + mz * mz);
		mx *= recipNorm;
		my *= recipNorm;
		mz *= recipNorm;   

        // Auxiliary variables to avoid repeated arithmetic
        q0q0 = q[0] * q[0];
        q0q1 = q[0] * q[1];
        q0q2 = q[0] * q[2];
        q0q3 = q[0] * q[3];
        q1q1 = q[1] * q[1];
        q1q2 = q[1] * q[2];
        q1q3 = q[1] * q[3];
        q2q2 = q[2] * q[2];
        q2q3 = q[2] * q[3];
        q3q3 = q[3] * q[3];   

        // Reference direction of Earth's magnetic field
        hx = 2.0f * (mx * (0.5f - q2q2 - q3q3) + my * (q1q2 - q0q3) + mz * (q1q3 + q0q2));
        hy = 2.0f * (mx * (q1q2 + q0q3) + my * (0.5f - q1q1 - q3q3) + mz * (q2q3 - q0q1));
        bx = sqrt(hx * hx + hy * hy);
        bz = 2.0f * (mx * (q1q3 - q0q2) + my * (q2q3 + q0q1) + mz * (0.5f - q1q1 - q2q2));

		// Estimated direction of gravity and magnetic field
		halfvx = q1q3 - q0q2;
		halfvy = q0q1 + q2q3;
		halfvz = q0q0 - 0.5f + q3q3;
        halfwx = bx * (0.5f - q2q2 - q3q3) + bz * (q1q3 - q0q2);
        halfwy = bx * (q1q2 - q0q3) + bz * (q0q1 + q2q3);
        halfwz = bx * (q0q2 + q1q3) + bz * (0.5f - q1q1 - q2q2);  
	
		// Error is sum of cross product between estimated direction and measured direction of field vectors
		halfex = (ay * halfvz - az * halfvy) + (my * halfwz - mz * halfwy);
		halfey = (az * halfvx - ax * halfvz) + (mz * halfwx - mx * halfwz);
		halfez = (ax * halfvy - ay * halfvx) + (mx * halfwy - my * halfwx);

		// Compute and apply integral feedback if enabled
		if(twoKi > 0.0f) {
			/*
			integralFBx += twoKi * halfex * (1.0f / sampleFreq);	// integral error scaled by Ki
			integralFBy += twoKi * halfey * (1.0f / sampleFreq);
			integralFBz += twoKi * halfez * (1.0f / sampleFreq);
			*/
			integralFBx += twoKi * halfex * halfT * 2;//(1.0f / sampleFreq);	// integral error scaled by Ki
			integralFBy += twoKi * halfey * halfT * 2;//(1.0f / sampleFreq);
			integralFBz += twoKi * halfez * halfT * 2;//(1.0f / sampleFreq);
			gx += integralFBx;	// apply integral feedback
			gy += integralFBy;
			gz += integralFBz;
		}
		else {
			integralFBx = 0.0f;	// prevent integral windup
			integralFBy = 0.0f;
			integralFBz = 0.0f;
		}

		// Apply proportional feedback
		gx += twoKp * halfex;
		gy += twoKp * halfey;
		gz += twoKp * halfez;
	}
	
	// Integrate rate of change of quaternion
	/*
	gx *= (0.5f * (1.0f / sampleFreq));		// pre-multiply common factors
	gy *= (0.5f * (1.0f / sampleFreq));
	gz *= (0.5f * (1.0f / sampleFreq));
	*/
	gx *= (0.5f * halfT * 2);//(1.0f / sampleFreq));		// pre-multiply common factors
	gy *= (0.5f * halfT * 2);//(1.0f / sampleFreq));
	gz *= (0.5f * halfT * 2);//(1.0f / sampleFreq));
	qa = q[0];
	qb = q[1];
	qc = q[2];
	q[0] += (-qb * gx - qc * gy - q[3] * gz);
	q[1] += (qa * gx + qc * gz - q[3] * gy);
	q[2] += (qa * gy - qb * gz + q[3] * gx);
	q[3] += (qa * gz + qb * gy - qc * gx); 
	
	// Normalise quaternion
	recipNorm = invSqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
	q[0] *= recipNorm;
	q[1] *= recipNorm;
	q[2] *= recipNorm;
	q[3] *= recipNorm;
}


static float to_mag_data[3]={0};//存储磁数据
static float _my_ang[3];
static float _my_acc[3];
static float _my_mag[3];
extern void get_ahrs(float *oo, float *my_acc, float *my_ang, float *my_mag)
{
	oo[0] = atan2(2 * (q0 * q1 + q2 * q3), 1 - 2 * (q1 * q1 + q2 * q2));
	oo[1] = asin(2 * (q0 * q2 - q3 * q1));
	oo[2] = atan2(2 * (q0 * q3 + q1 * q2),  1 - 2 * (q2 * q2 + q3 * q3));

	my_ang[0] = _my_ang[0];
	my_ang[1] = _my_ang[1];
	my_ang[2] = _my_ang[2];

	my_acc[0] = _my_acc[0];
	my_acc[1] = _my_acc[1];
	my_acc[2] = _my_acc[2];

	my_mag[0] = _my_mag[0];
	my_mag[1] = _my_mag[1];
	my_mag[2] = _my_mag[2];

	/*
	my_mag[0] = to_mag_data[0]  ;
	my_mag[1] = to_mag_data[1]  ;
	my_mag[2] = to_mag_data[2]  ;
	*/
}


#include <drivers/hrtimer.h>
static struct hrtimer imu_timer;
K_SEM_DEFINE(imu_sem, 0, 1);
void imu_timer_handler(struct k_timer *timer)
{
	k_sem_give(&imu_sem);
}


#include "app_ui.h"
#include "EKF.h"
static int quit_flag = 0;
static int32_t time_get_2 = 0;
static int32_t time_get_1 = 0;
static void aa_calibration_thread(void *p1,void *p2,void *p3)
{
        float axsum = 0;
        float aysum = 0;
        float azsum = 0;
        float gxsum = 0;
        float gysum = 0;
        float gzsum = 0;
        float axoff = 0;
        float ayoff = 0;
        float azoff = 0;
        float gxoff = 0;
        float gyoff = 0;
        float gzoff = 0;
	float ang_mdps[3] = { 0 };
	float acc_mg[3] = { 0 };
    	float mag_data[3]={0};//存储磁数据
	float acc[3] = { 0, 0 , 0 };
	float to_acc[3] = { 0, 0 , 0 };
	float ang[3] = { 0, 0, 0 };
	uint32_t timestamp = 0;

	
	
/*
    	VCM1195L_init();
	k_msleep(10);
void lsm6dsv16x_fifo(void);
lsm6dsv16x_fifo();
return;
*/


    	VCM1195L_init();
	lsm6dsv16x_init();

	k_msleep(10);

	k_timer_init(&imu_timer,
			imu_timer_handler,
			 NULL);
	k_timer_start(&imu_timer,
			     K_MSEC(10), 
			     K_MSEC(10)
			     );

	time_get_1 = k_uptime_get_32();

	while (quit_flag != 1)
	{
		/*
		k_msleep(10);
		*/
again:
		k_sem_take(&imu_sem, K_FOREVER);
#if 1
		acc[0] = 0.0f;
		acc[1] = 0.0f;
		acc[2] = 0.0f;
		ang[0] = 0.0f;
		ang[1] = 0.0f;
		ang[2] = 0.0f;
		mag_data[0] = 0.0f;
		mag_data[1] = 0.0f;
		mag_data[2] = 0.0f;
		lsm6dsv16x_read_data_polling(acc, ang, &timestamp);
		if ((acc[0] == 0.0f && acc[1] == 0.0f && acc[2] == 0.0f)
			|| (ang[0] == 0.0f && ang[1] == 0.0f && ang[2] == 0.0f)
			)
		{
			printf("emtpy imu data\n");
			goto again;
		}
		VCM119xL_ReadData(mag_data);
		_my_ang[0] = ang[0] / 70.0f;
		_my_ang[1] = ang[1] / 70.0f;
		_my_ang[2] = ang[2] / 70.0f;
		_my_acc[0] = -(acc[0] ) / 0.061f;
		_my_acc[1] = -(acc[1] ) / 0.061f;
		_my_acc[2] = -(acc[2] ) / 0.061f;
		_my_mag[0] = mag_data[0] * 30.0f;
		_my_mag[1] = mag_data[1] * 30.0f;
		_my_mag[2] = mag_data[2] * 30.0f;
		/*
		printf("get acc: %f %f %f, ang: %f %f %f, timestamp: %u\n", 
				acc[0], acc[1], acc[2], ang[0], ang[1], ang[2], timestamp);
				*/

		time_get_2 = k_uptime_get_32();
		halfT = (float)(time_get_2 - time_get_1) * 0.001f * 0.5f;
		
extern void gry_cal(float *inGry, float *outGry);
extern void acc_cal(float *inAcc, float *outAcc);
extern void mag_cal(float *inMag, float *outMag);

	float inAcc[3];
	float outAcc[3];
	for (int i = 0; i < 3; i++)
		inAcc[i] = _my_acc[i];
	acc_cal(inAcc, outAcc);
	for (int i = 0; i < 3; i++)
		to_acc[i] = outAcc[i];

	float inGry[3];
	float outGry[3];
	for (int i = 0; i < 3; i++)
		inGry[i] = _my_ang[i];
	gry_cal(inGry, outGry);
	for (int i = 0; i < 3; i++)
		ang[i] = outGry[i];

	float inMag[3];
	float outMag[3];
	for (int i = 0; i < 3; i++)
		inMag[i] = _my_mag[i];
	mag_cal(inMag, outMag);
	for (int i = 0; i < 3; i++)
		to_mag_data[i] = outMag[i];


		/*
		AHRSupdate(
				(ang[0]) , 
				(ang[1]) , 
				(ang[2]) ,
				to_acc[0], 
				to_acc[1], 
				to_acc[2],
				to_mag_data[0],
				to_mag_data[1],
				to_mag_data[2]
		  );
		  */
		  
extern void imu_get_gry_sum(float *ang, float dt);
	imu_get_gry_sum(ang, halfT * 2);
	/*
		printf("ang: %f %f %f, timestamp: %f\n", 
				ang[0], ang[1], ang[2], halfT * 2);
				*/

		static float my_q[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
		MahonyAHRSupdate(
				my_q, 
				(ang[0]) , 
				(ang[1]) , 
				(ang[2]) ,
				to_acc[0], 
				to_acc[1], 
				to_acc[2],
				-to_mag_data[0],
				-to_mag_data[1],
				-to_mag_data[2]
				);
		q0 = my_q[0];
		q1 = my_q[1];
		q2 = my_q[2];
		q3 = my_q[3];

extern void iecompass(int16_t iBpx, int16_t iBpy, int16_t iBpz,
			int16_t iGpx, int16_t iGpy, int16_t iGpz);
extern int32_t low_pass_filter(void);
	iecompass((int16_t)-to_mag_data[0], (int16_t)-to_mag_data[1], (int16_t)-to_mag_data[2],
			(int16_t)to_acc[0], (int16_t)to_acc[1], (int16_t)to_acc[2]);
	low_pass_filter();

		time_get_1 = time_get_2;


extern void test_save_data(float *acc, float *ang, float *mag, uint32_t timestamp);
	test_save_data(_my_acc, _my_ang, _my_mag, timestamp);

	static int ahrs_count = 0;
	if (ahrs_count++ == 100)
	{
		ahrs_count = 0;
		ui_view_paint(GPS4_VIEW);
	}
#endif
	}
	k_timer_stop(&imu_timer);
}

static k_tid_t m_tid = NULL;
K_THREAD_STACK_DEFINE(aa_stack_area, 4096);
static struct k_thread thread_data;
void aa_thread_init(void)
{
	if (m_tid == NULL)
	{
		//extern void lsm6dsv16x_init(void);
		//lsm6dsv16x_init();
		m_tid = k_thread_create(&thread_data, aa_stack_area,
				K_THREAD_STACK_SIZEOF(aa_stack_area),
				aa_calibration_thread, NULL, NULL, NULL,
				15, 0, K_NO_WAIT);
		k_thread_name_set(m_tid, "aa_thread");
	}
	else
	{
		SYS_LOG_INF("%s: already started", __func__);
	}
}
#endif

int shell_test_ahrs(const struct shell *shell, size_t argc, char **argv)
{
	aa_thread_init();
	return 0;
}

int shell_test_ahrs_quit(const struct shell *shell, size_t argc, char **argv)
{
	quit_flag = 1;
	return 0;
}

int test_ahrs_get_quit_status(void)
{
	return quit_flag;
}

SHELL_STATIC_SUBCMD_SET_CREATE(sub_system,
	SHELL_CMD(dumpmem, NULL, "dump mem info.", shell_dump_meminfo),
	SHELL_CMD(set_config, NULL, "set system config ", shell_set_config),
#ifdef CONFIG_MEDIA_PLAYER
	SHELL_CMD(set_voice_effect, NULL, "set voice effect bypass ", shell_set_voice_effect_config),
	SHELL_CMD(set_music_effect, NULL, "set music effect bypass ", shell_set_effect_config),
#endif
#ifdef CONFIG_SYS_WAKELOCK
	SHELL_CMD(wlock, NULL, "wlock lock[unlock] ", shell_wake_lock),
#endif
	SHELL_CMD(gps_test, NULL, "wlock lock[unlock] ", shell_test_gps),
	SHELL_CMD(gps_show, NULL, "wlock lock[unlock] ", shell_show_gps),
	SHELL_CMD(get_gps_alp, NULL, "wlock lock[unlock] ", shell_get_alp_status),
	SHELL_CMD(set_gps_alp2, NULL, "wlock lock[unlock] ", shell_set_alp2),
	SHELL_CMD(set_gps_epoc, NULL, "wlock lock[unlock] ", shell_set_gps_epoc),
	SHELL_CMD(get_gps_epoc, NULL, "wlock lock[unlock] ", shell_get_gps_epoc),
	SHELL_CMD(save_gps_epoc, NULL, "wlock lock[unlock] ", shell_save_gps_epoc),
	SHELL_CMD(set_gps_aic, NULL, "wlock lock[unlock] ", shell_set_aic),
	SHELL_CMD(read_temp, NULL, "wlock lock[unlock] ", shell_read_temp),
	SHELL_CMD(read_pres, NULL, "wlock lock[unlock] ", shell_read_pres),
	SHELL_CMD(set_lcd, NULL, "wlock lock[unlock] ", shell_set_lcd),
	SHELL_CMD(set_power, NULL, "wlock lock[unlock] ", shell_test_power),
	SHELL_CMD(test_ahrs, NULL, "wlock lock[unlock] ", shell_test_ahrs),
	SHELL_CMD(ahrs_quit, NULL, "wlock lock[unlock] ", shell_test_ahrs_quit),
	SHELL_SUBCMD_SET_END /* Array terminated. */
);

SHELL_CMD_REGISTER(system, &sub_system, "system commands", NULL);
