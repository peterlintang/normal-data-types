/*
 * Copyright (c) 2020 Actions Technology Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#include <assert.h>
#include <lvgl.h>
#include <lvgl/lvgl_res_loader.h>
#include <lvgl/lvgl_bitmap_font.h>

#include <ui_manager.h>
#include <view_manager.h>
#include "widgets/anim_img.h"
#include "widgets/img_number.h"


#include <res_manager_api.h>
#include "app_ui.h"
#include "app_defines.h"
#include "system_app.h"
#include <view_stack.h>
#include <acts_bluetooth/host_interface.h>

#include <bt_manager.h>
#include "uart2_to_gps.h"
#include <sys_wakelock.h>

#include "golf/golf_presenter.h"
#include "other/golf_config.h"

/*
const static uint32_t power_test_resource_id[] = {
	GPS_POWER_SWITCH,
	BT_POWER_SWITCH,
	LCD_POWER_SWITCH,
	TP_POWER_SWITCH,
	GPS_POWER_ON,
	GPS_POWER_OFF,
	BT_POWER_ON,
	BT_POWER_OFF,
	LCD_POWER_ON,
	LCD_POWER_OFF,
	TP_POWER_ON,
	TP_POWER_OFF,
};
*/

static int power_test_preload_inited = 0;

static uint32_t gps_power_img_id[] = {
	GPS_POWER_ON,
	GPS_POWER_OFF,
};
static uint32_t gps_power_str_id[] = {
	GPS_POWER_SWITCH,
};

static uint32_t bt_power_img_id[] = {
	BT_POWER_ON,
	BT_POWER_OFF,
};
static uint32_t bt_power_str_id[] = {
	BT_POWER_SWITCH,
};

static uint32_t lcd_power_img_id[] = {
	LCD_POWER_ON,
	LCD_POWER_OFF,
};
static uint32_t lcd_power_str_id[] = {
	LCD_POWER_SWITCH,
};

static uint32_t tp_power_img_id[] = {
	TP_POWER_ON,
	TP_POWER_OFF,
};

static uint32_t tp_power_str_id[] = {
	TP_POWER_SWITCH,
};

static uint32_t lcd_test_str_id[] = {
	LCD_TEST,
};

static uint32_t tmp_test_str_id[] = {
	TMP_SENSOR_TEST,
};

static uint32_t pre_test_str_id[] = {
	PRESSURE_SENSOR_TEST,
};

static uint32_t com_test_str_id[] = {
	COMPASS_TEST,
};

struct gps_power_data {
	lv_obj_t *gps_power_label;
	lv_obj_t *gps_power_img;
	lv_img_dsc_t gps_power_imgs[2];
	lv_point_t gps_power_img_point[2];
	lvgl_res_string_t gps_power_str;
	lv_style_t gps_power_str_style;
	int gps_state;

	lv_obj_t *bt_power_label;
	lv_obj_t *bt_power_img;
	lv_img_dsc_t bt_power_imgs[2];
	lv_point_t bt_power_img_point[2];
	lvgl_res_string_t bt_power_str;
	lv_style_t bt_power_str_style;
	int bt_state;

	lv_obj_t *lcd_power_label;
	lv_obj_t *lcd_power_img;
	lv_img_dsc_t lcd_power_imgs[2];
	lv_point_t lcd_power_img_point[2];
	lvgl_res_string_t lcd_power_str;
	lv_style_t lcd_power_str_style;
	int lcd_state;

	lv_obj_t *tp_power_label;
	lv_obj_t *tp_power_img;
	lv_img_dsc_t tp_power_imgs[2];
	lv_point_t tp_power_img_point[2];
	lvgl_res_string_t tp_power_str;
	lv_style_t tp_power_str_style;
	int tp_state;

	lv_obj_t *lcd_test_button;
	lv_obj_t *lcd_test_label;
	lv_style_t lcd_test_button_style;
	lvgl_res_string_t lcd_test_str;
	lv_style_t lcd_test_str_style;

	lv_obj_t *tmp_test_button;
	lv_obj_t *tmp_test_label;
	lv_style_t tmp_test_button_style;
	lvgl_res_string_t tmp_test_str;
	lv_style_t tmp_test_str_style;

	lv_obj_t *pre_test_button;
	lv_obj_t *pre_test_label;
	lv_style_t pre_test_button_style;
	lvgl_res_string_t pre_test_str;
	lv_style_t pre_test_str_style;

	lv_obj_t *com_test_button;
	lv_obj_t *com_test_label;
	lv_style_t com_test_button_style;
	lvgl_res_string_t com_test_str;
	lv_style_t com_test_str_style;


	lv_obj_t *lcd_slider;
	lv_obj_t *lcd_slider_label;
	lv_style_t style_slider_bg;
	lv_style_t style_slider_indic;
	lv_style_t style_slider_knob;

	lvgl_res_scene_t scene;
	lv_font_t font;
};

static struct gps_power_data *private_data = NULL;

static void init_txt_style(struct gps_power_data *data, lv_style_t *sty, lvgl_res_string_t *txt, uint32_t num)
{
	for (int i = 0; i < num; i++)
	{
		lv_style_init(&sty[i]);
		lv_style_set_x(&sty[i], txt[i].x);
		lv_style_set_y(&sty[i], txt[i].y);
		lv_style_set_width(&sty[i], txt[i].width);
		lv_style_set_height(&sty[i], txt[i].height);
		lv_style_set_text_color(&sty[i], txt[i].color);
		lv_style_set_text_align(&sty[i], txt[i].align);
		lv_style_set_text_font(&sty[i], &data->font);
		SYS_LOG_INF("%s: %d %d %d %d\n", __func__, txt[i].x, txt[i].y, txt[i].width, txt[i].height);
	}
}

static int load_resource(view_data_t *view_data)
{
	int ret = 0;

	ret = lvgl_res_load_scene(SCENE_POWER_TEST_VIEW, &private_data->scene, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
	if (ret != 0)
	{
		goto out;
	}

	if (lvgl_bitmap_font_open(&private_data->font, DEF_FONT24_FILE) < 0)
	{
		goto out;
	}


	ret = lvgl_res_load_pictures_from_scene(&private_data->scene, 
			gps_power_img_id, 
			private_data->gps_power_imgs, 
			private_data->gps_power_img_point, 
			2);
	if (ret != 0)
	{
		goto error1;
	}

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			gps_power_str_id, 
			&private_data->gps_power_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->gps_power_str_style, &private_data->gps_power_str, 1);


	ret = lvgl_res_load_pictures_from_scene(&private_data->scene, 
			gps_power_img_id, 
			private_data->gps_power_imgs, 
			private_data->gps_power_img_point, 
			2);
	if (ret != 0)
	{
		goto error1;
	}

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			gps_power_str_id, 
			&private_data->gps_power_str, 
			1);
	if (ret != 0)
	{
		goto error2;
	}

	init_txt_style(private_data, &private_data->gps_power_str_style, &private_data->gps_power_str, 1);

	ret = lvgl_res_load_pictures_from_scene(&private_data->scene, 
			bt_power_img_id, 
			private_data->bt_power_imgs, 
			private_data->bt_power_img_point, 
			2);
	if (ret != 0)
	{
		goto error3;
	}

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			bt_power_str_id, 
			&private_data->bt_power_str, 
			1);
	if (ret != 0)
	{
		goto error4;
	}

	init_txt_style(private_data, &private_data->bt_power_str_style, &private_data->bt_power_str, 1);

	ret = lvgl_res_load_pictures_from_scene(&private_data->scene, 
			lcd_power_img_id, 
			private_data->lcd_power_imgs, 
			private_data->lcd_power_img_point, 
			2);
	if (ret != 0)
	{
		goto error3;
	}

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			lcd_power_str_id, 
			&private_data->lcd_power_str, 
			1);
	if (ret != 0)
	{
		goto error4;
	}

	init_txt_style(private_data, &private_data->lcd_power_str_style, &private_data->lcd_power_str, 1);

	ret = lvgl_res_load_pictures_from_scene(&private_data->scene, 
			tp_power_img_id, 
			private_data->tp_power_imgs, 
			private_data->tp_power_img_point, 
			2);
	if (ret != 0)
	{
		goto error3;
	}

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			tp_power_str_id, 
			&private_data->tp_power_str, 
			1);
	if (ret != 0)
	{
		goto error4;
	}

	init_txt_style(private_data, &private_data->tp_power_str_style, &private_data->tp_power_str, 1);


	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			lcd_test_str_id, 
			&private_data->lcd_test_str, 
			1);
	init_txt_style(private_data, &private_data->lcd_test_str_style, &private_data->lcd_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			tmp_test_str_id, 
			&private_data->tmp_test_str, 
			1);
	init_txt_style(private_data, &private_data->tmp_test_str_style, &private_data->tmp_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			pre_test_str_id, 
			&private_data->pre_test_str, 
			1);
	init_txt_style(private_data, &private_data->pre_test_str_style, &private_data->pre_test_str, 1);

	ret = lvgl_res_load_strings_from_scene(&private_data->scene, 
			com_test_str_id, 
			&private_data->com_test_str, 
			1);
	init_txt_style(private_data, &private_data->com_test_str_style, &private_data->com_test_str, 1);

	return 0;

error4:
	lvgl_res_unload_pictures(private_data->bt_power_imgs, 2);

error3:

error2:
	SYS_LOG_ERR("%s: failed to load resource\n", __func__);
	lvgl_res_unload_pictures(private_data->gps_power_imgs, 2);

error1:
	lvgl_res_unload_scene(&private_data->scene);

out:
	return ret;
}

static int unload_resource(view_data_t *view_data)
{
	lvgl_res_unload_strings(&private_data->tp_power_str, 1);
	lvgl_res_unload_pictures(private_data->tp_power_imgs, 2);
	lvgl_res_unload_strings(&private_data->lcd_power_str, 1);
	lvgl_res_unload_pictures(private_data->lcd_power_imgs, 2);
	lvgl_res_unload_strings(&private_data->bt_power_str, 1);
	lvgl_res_unload_pictures(private_data->bt_power_imgs, 2);
	lvgl_res_unload_strings(&private_data->gps_power_str, 1);
	lvgl_res_unload_pictures(private_data->gps_power_imgs, 2);

	lvgl_res_unload_strings(&private_data->lcd_test_str, 1);
	lvgl_res_unload_strings(&private_data->tmp_test_str, 1);
	lvgl_res_unload_strings(&private_data->pre_test_str, 1);

	lvgl_res_unload_scene(&private_data->scene);
	return 0;
}

static void gps_switch_btn_event_handler(lv_event_t * e)
{
	if(private_data->gps_state == 1)
	{
		Golf_Info.gps_switch_flag = 0;
		private_data->gps_state = 0;
		gps_close();
		
		extern GPS_INFO GPS;
		memset(&GPS,0,sizeof(GPS));
		lv_img_set_src(private_data->gps_power_img, &private_data->gps_power_imgs[1]);
	}
	else if (private_data->gps_state == 0)
	{
		Golf_Info.gps_switch_flag = 1;
		private_data->gps_state = 1;
		gps_open();
		lv_img_set_src(private_data->gps_power_img, &private_data->gps_power_imgs[0]);
	}

	golf_config_set(&Golf_Info);

	SYS_LOG_INF("%s: state: %d\n", __func__, private_data->gps_state);
}

static void bt_switch_btn_event_handler(lv_event_t * e)
{
	if(private_data->bt_state == 1)
	{
		Golf_Info.bt_switch_flag = 0;
		private_data->bt_state = 0;
		bt_manager_ble_adv_stop();
		bt_manager_set_visible(false);
		bt_manager_set_connectable(false);
		lv_img_set_src(private_data->bt_power_img, &private_data->bt_power_imgs[1]);
	}
	else if (private_data->bt_state == 0)
	{
		Golf_Info.bt_switch_flag = 1;
		private_data->bt_state = 1;
		bt_manager_ble_adv_start();
		bt_manager_set_visible(true);
		bt_manager_set_connectable(true);
		lv_img_set_src(private_data->bt_power_img, &private_data->bt_power_imgs[0]);
	}

	golf_config_set(&Golf_Info);

	SYS_LOG_INF("%s: state: %d\n", __func__, private_data->bt_state);
}

#if 1
#include <soc_regs.h>
#include <drivers/gpio.h>
#include <soc_pinmux.h>
#include <soc_gpio.h>
#include <drivers/display/display_controller.h>
static int test_io(char* argv)
{
	struct device *lcdc_dev = NULL;
	lcdc_dev = (struct device *)device_get_binding(CONFIG_LCDC_DEV_NAME);
	if (strcmp(argv, "1") == 0)
	{
		display_controller_write_config(lcdc_dev, 0x11, NULL, 0);
		k_msleep(120);
		display_controller_write_config(lcdc_dev, 0x29, NULL, 0);
		/*
       		acts_pinmux_set(GPIO_33, GPIO_CTL_GPIO_OUTEN);
       		soc_gpio_output(GPIO_33, 1);
		*/
	}
	else
	{
		display_controller_write_config(lcdc_dev, 0x28, NULL, 0);
		k_msleep(10);
		display_controller_write_config(lcdc_dev, 0x10, NULL, 0);
		/*
       		acts_pinmux_set(GPIO_15, GPIO_CTL_GPIO_OUTEN);
       		soc_gpio_output(GPIO_15, 0);
		k_msleep(10);
       		acts_pinmux_set(GPIO_33, GPIO_CTL_GPIO_OUTEN);
       		soc_gpio_output(GPIO_33, 0);
		*/
	}

       return 0;
}

static void lcd_switch_btn_event_handler(lv_event_t * e)
{
	if(private_data->lcd_state == 1)
	{
	//	Golf_Info.lcd_switch_flag = 0;
		private_data->lcd_state = 0;
		test_io("0");
		lv_img_set_src(private_data->lcd_power_img, &private_data->lcd_power_imgs[1]);
	}
	else if (private_data->lcd_state == 0)
	{
	//	Golf_Info.lcd_switch_flag = 1;
		private_data->lcd_state = 1;
		test_io("1");
		lv_img_set_src(private_data->lcd_power_img, &private_data->lcd_power_imgs[0]);
	}

//	golf_config_set(&Golf_Info);

	SYS_LOG_INF("%s: state: %d\n", __func__, private_data->lcd_state);
}
#endif

#if 1
#include <drivers/i2c.h>
static int _tp_set(char *argv)
{
#define tp_slaver_addr      0x24 //(0x24 >> 1)// (0x2A >> 1) // 0x15  7bit
	const struct device* tp = NULL;
	uint8_t cmd[6] = {0};

	tp = device_get_binding("I2C_1");
	if (tp == NULL)
	{
		SYS_LOG_ERR("get %s failed\n", "I2C_1");
		return 0;
	}

	cmd[0] = 0x05;
	cmd[1] = 0x00;
	cmd[3] = 0x08;
	if (strcmp(argv, "1") == 0)
	{
		cmd[2] = 0x01;
        } 
	else 
	{
                cmd[2] = 0x00;
        }

	SYS_LOG_INF("%s set tp\n", __func__);
        i2c_write(tp, cmd, 4, tp_slaver_addr);
	return 0;
}

static void tp_switch_btn_event_handler(lv_event_t * e)
{
	if(private_data->tp_state == 1)
	{
//		Golf_Info.tp_switch_flag = 0;
		private_data->tp_state = 0;
		_tp_set("0");
		lv_img_set_src(private_data->tp_power_img, &private_data->tp_power_imgs[1]);
	}
	else if (private_data->tp_state == 0)
	{
//		Golf_Info.tp_switch_flag = 1;
		private_data->tp_state = 1;
		_tp_set("1");
		lv_img_set_src(private_data->tp_power_img, &private_data->tp_power_imgs[0]);
	}

//	golf_config_set(&Golf_Info);

	SYS_LOG_INF("%s: state: %d\n", __func__, private_data->tp_state);
}
#endif

#if 0
static void lcd_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: state: %d\n", __func__, 1);
//	mag_calibration_thread_init();
	view_stack_push_view(LCD_TEST_VIEW, NULL);
}

static void tmp_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: state: %d\n", __func__, 1);
}

static void pre_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: state: %d\n", __func__, 1);
}

static void com_test_btn_event_handler(lv_event_t * e)
{
	SYS_LOG_INF("%s: state: %d\n", __func__, 1);
}

#endif

#include <display/display_composer.h>
static void lcd_slider_event_handle(lv_event_t * e)
{
	lv_event_code_t event = lv_event_get_code(e);
	lv_obj_t * slider = lv_event_get_target(e);
	char buf[8];

	lv_snprintf(buf, sizeof(buf), "%d", (int)lv_slider_get_value(slider));
	lv_label_set_text(private_data->lcd_slider_label, buf);
	lv_obj_align_to(private_data->lcd_slider_label, private_data->lcd_slider, LV_ALIGN_OUT_BOTTOM_MID, 0, 10);
	display_composer_set_brightness(lv_slider_get_value(slider));
	SYS_LOG_INF("slider_event_cb %p event %d, value %d\n", slider, event, lv_slider_get_value(slider));

	Golf_Info.backlight_value = lv_slider_get_value(slider) / 8;
	golf_config_set(&Golf_Info);
}



static int create_view(view_data_t *view_data)
{
	lv_obj_t *src = NULL;
	
	extern k_tid_t uart_tid ;
	k_thread_resume(uart_tid);
	sys_wake_lock(FULL_WAKE_LOCK);

	/*
	SYS_LOG_INF("%s: start init mag calibration\n", __func__);
	k_msleep(100);
//	mag_calibration_init();
	SYS_LOG_INF("%s: end init mag calibration\n", __func__);
	*/

	src = lv_disp_get_scr_act(view_data->display);
	if (src == NULL)
		return -1;

	lv_obj_set_style_bg_color(src, private_data->scene.background, LV_PART_MAIN);
	lv_obj_set_style_bg_opa(src, LV_OPA_COVER, LV_PART_MAIN);

	private_data->gps_power_label = lv_label_create(src);
	if (private_data->gps_power_label == NULL)
	{
		SYS_LOG_INF("create error\n");
		return -1;
	}
	lv_label_set_text(private_data->gps_power_label, private_data->gps_power_str.txt);
	lv_obj_add_style(private_data->gps_power_label, &private_data->gps_power_str_style, LV_PART_MAIN);

	private_data->gps_power_img = lv_img_create(src);
	lv_img_set_src(private_data->gps_power_img, &private_data->gps_power_imgs[0]);
	lv_obj_set_pos(private_data->gps_power_img,
			private_data->gps_power_img_point[0].x, 
			private_data->gps_power_img_point[0].y); 
	lv_obj_add_flag(private_data->gps_power_img, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(private_data->gps_power_img, gps_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);
	if (Golf_Info.gps_switch_flag == 1)
	{
		private_data->gps_state = 1;
		gps_open();
		lv_img_set_src(private_data->gps_power_img, &private_data->gps_power_imgs[0]);
	}
	else if (Golf_Info.gps_switch_flag == 0)
	{
		private_data->gps_state = 0;
		gps_close();
		
		extern GPS_INFO GPS;
		memset(&GPS,0,sizeof(GPS));
		lv_img_set_src(private_data->gps_power_img, &private_data->gps_power_imgs[1]);
	}

	private_data->bt_power_label = lv_label_create(src);
	if (private_data->bt_power_label == NULL)
	{
		SYS_LOG_INF("create error\n");
		return -1;
	}
	lv_label_set_text(private_data->bt_power_label, private_data->bt_power_str.txt);
	lv_obj_add_style(private_data->bt_power_label, &private_data->bt_power_str_style, LV_PART_MAIN);

	private_data->bt_power_img = lv_img_create(src);
	lv_img_set_src(private_data->bt_power_img, &private_data->bt_power_imgs[0]);
	lv_obj_set_pos(private_data->bt_power_img,
			private_data->bt_power_img_point[0].x, 
			private_data->bt_power_img_point[0].y); 
	lv_obj_add_flag(private_data->bt_power_img, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(private_data->bt_power_img, bt_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);

	if (Golf_Info.bt_switch_flag == 1)
	{
		private_data->bt_state = 1;
		bt_manager_ble_adv_start();
		bt_manager_set_visible(true);
		bt_manager_set_connectable(true);
		lv_img_set_src(private_data->bt_power_img, &private_data->bt_power_imgs[0]);
	}
	else if (Golf_Info.bt_switch_flag == 0)
	{
		private_data->bt_state = 0;
		bt_manager_ble_adv_stop();
		bt_manager_set_visible(false);
		bt_manager_set_connectable(false);
		lv_img_set_src(private_data->bt_power_img, &private_data->bt_power_imgs[1]);
	}

#if 1
	private_data->lcd_power_label = lv_label_create(src);
	if (private_data->lcd_power_label == NULL)
	{
		SYS_LOG_INF("create error\n");
		return -1;
	}
	lv_label_set_text(private_data->lcd_power_label, /*private_data->lcd_power_str.txt*/"Lcd test");
	lv_obj_add_style(private_data->lcd_power_label, &private_data->lcd_power_str_style, LV_PART_MAIN);

	private_data->lcd_power_img = lv_img_create(src);
	lv_img_set_src(private_data->lcd_power_img, &private_data->lcd_power_imgs[0]);
	lv_obj_set_pos(private_data->lcd_power_img,
			private_data->lcd_power_img_point[0].x, 
			private_data->lcd_power_img_point[0].y); 
	lv_obj_add_flag(private_data->lcd_power_img, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(private_data->lcd_power_img, lcd_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);

	/*
	if (Golf_Info.lcd_switch_flag == 1)
	{
		private_data->lcd_state = 1;
		test_io("1");
		lv_img_set_src(private_data->lcd_power_img, &private_data->lcd_power_imgs[0]);
	}
	else if (Golf_Info.lcd_switch_flag == 0)
	{
		private_data->lcd_state = 0;
		test_io("0");
		lv_img_set_src(private_data->lcd_power_img, &private_data->lcd_power_imgs[1]);
	}
	*/


	private_data->tp_power_label = lv_label_create(src);
	if (private_data->tp_power_label == NULL)
	{
		SYS_LOG_INF("create error\n");
		return -1;
	}
	lv_label_set_text(private_data->tp_power_label, /*private_data->tp_power_str.txt*/"Tp test");
	lv_obj_add_style(private_data->tp_power_label, &private_data->tp_power_str_style, LV_PART_MAIN);

	private_data->tp_power_img = lv_img_create(src);
	lv_img_set_src(private_data->tp_power_img, &private_data->tp_power_imgs[0]);
	lv_obj_set_pos(private_data->tp_power_img,
			private_data->tp_power_img_point[0].x, 
			private_data->tp_power_img_point[0].y); 
	lv_obj_add_flag(private_data->tp_power_img, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(private_data->tp_power_img, tp_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);

/*
	if (Golf_Info.tp_switch_flag == 1)
	{
		private_data->tp_state = 1;
		_tp_set("1");
		lv_img_set_src(private_data->tp_power_img, &private_data->tp_power_imgs[0]);
	}
	else if (Golf_Info.tp_switch_flag == 0)
	{
		private_data->tp_state = 0;
		_tp_set("0");
		lv_img_set_src(private_data->tp_power_img, &private_data->tp_power_imgs[1]);
	}
*/

#endif




#if 0
	private_data->lcd_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->lcd_test_button, &private_data->lcd_test_button_style, 0);
	lv_obj_add_style(private_data->lcd_test_button, &private_data->lcd_test_button_style, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->lcd_test_button, private_data->lcd_test_str.x, private_data->lcd_test_str.y);
	lv_obj_set_size(private_data->lcd_test_button, private_data->lcd_test_str.width, private_data->lcd_test_str.height);
	lv_obj_add_event_cb(private_data->lcd_test_button, lcd_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->lcd_test_label = lv_label_create(private_data->lcd_test_button);
	lv_label_set_text(private_data->lcd_test_label, private_data->lcd_test_str.txt);
	lv_obj_add_style(private_data->lcd_test_label, &private_data->lcd_test_str_style, LV_PART_MAIN);
	lv_obj_center(private_data->lcd_test_label);

	private_data->tmp_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->tmp_test_button, &private_data->tmp_test_button_style, 0);
	lv_obj_add_style(private_data->tmp_test_button, &private_data->tmp_test_button_style, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->tmp_test_button, private_data->tmp_test_str.x, private_data->tmp_test_str.y);
	lv_obj_set_size(private_data->tmp_test_button, private_data->tmp_test_str.width, private_data->tmp_test_str.height);
	lv_obj_add_event_cb(private_data->tmp_test_button, tmp_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->tmp_test_label = lv_label_create(private_data->tmp_test_button);
	lv_label_set_text(private_data->tmp_test_label, private_data->tmp_test_str.txt);
	lv_obj_add_style(private_data->tmp_test_label, &private_data->tmp_test_str_style, LV_PART_MAIN);
	lv_obj_center(private_data->tmp_test_label);

	private_data->pre_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->pre_test_button, &private_data->pre_test_button_style, 0);
	lv_obj_add_style(private_data->pre_test_button, &private_data->pre_test_button_style, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->pre_test_button, private_data->pre_test_str.x, private_data->pre_test_str.y);
	lv_obj_set_size(private_data->pre_test_button, private_data->pre_test_str.width, private_data->pre_test_str.height);
	lv_obj_add_event_cb(private_data->pre_test_button, pre_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->pre_test_label = lv_label_create(private_data->pre_test_button);
	lv_label_set_text(private_data->pre_test_label, private_data->pre_test_str.txt);
	lv_obj_add_style(private_data->pre_test_label, &private_data->pre_test_str_style, LV_PART_MAIN);
	lv_obj_center(private_data->pre_test_label);

	private_data->com_test_button = lv_btn_create(src);
	lv_obj_add_style(private_data->com_test_button, &private_data->com_test_button_style, 0);
	lv_obj_add_style(private_data->com_test_button, &private_data->com_test_button_style, LV_STATE_PRESSED);
	lv_obj_set_pos(private_data->com_test_button, private_data->com_test_str.x, private_data->com_test_str.y);
	lv_obj_set_size(private_data->com_test_button, private_data->com_test_str.width, private_data->com_test_str.height);
	lv_obj_add_event_cb(private_data->com_test_button, com_test_btn_event_handler, LV_EVENT_SHORT_CLICKED, view_data);

	private_data->com_test_label = lv_label_create(private_data->com_test_button);
	lv_label_set_text(private_data->com_test_label, private_data->com_test_str.txt);
	lv_obj_add_style(private_data->com_test_label, &private_data->com_test_str_style, LV_PART_MAIN);
	lv_obj_center(private_data->com_test_label);
#endif



	lv_style_init(&private_data->style_slider_bg);
	lv_style_set_bg_color(&private_data->style_slider_bg, lv_color_make(0xC0, 0xC0, 0xC0));
	lv_style_set_bg_opa(&private_data->style_slider_bg, LV_OPA_COVER);
	lv_style_set_radius(&private_data->style_slider_bg, LV_RADIUS_CIRCLE);

	lv_style_init(&private_data->style_slider_indic);
	lv_style_set_bg_color(&private_data->style_slider_indic, lv_color_make(0, 0, 255));
	lv_style_set_bg_opa(&private_data->style_slider_indic, LV_OPA_COVER);

	lv_style_init(&private_data->style_slider_knob);
	lv_style_set_bg_opa(&private_data->style_slider_knob, LV_OPA_COVER);
	lv_style_set_bg_color(&private_data->style_slider_knob, lv_color_make(0, 0, 255));
	lv_style_set_radius(&private_data->style_slider_knob, LV_RADIUS_CIRCLE);
	lv_style_set_pad_left(&private_data->style_slider_knob, 6);
	lv_style_set_pad_right(&private_data->style_slider_knob, 6);
	lv_style_set_pad_top(&private_data->style_slider_knob, 6);
	lv_style_set_pad_bottom(&private_data->style_slider_knob, 6);


	private_data->lcd_slider = lv_slider_create(src);
//	lv_obj_center(private_data->lcd_slider);
	lv_obj_set_pos(private_data->lcd_slider, 10, 250); 
	lv_obj_set_size(private_data->lcd_slider, 210, 20); 
	lv_obj_add_style(private_data->lcd_slider, &private_data->style_slider_bg, LV_PART_MAIN);
	lv_obj_add_style(private_data->lcd_slider, &private_data->style_slider_indic, LV_PART_INDICATOR);
	lv_obj_add_style(private_data->lcd_slider, &private_data->style_slider_knob, LV_PART_KNOB);
	lv_obj_add_event_cb(private_data->lcd_slider, lcd_slider_event_handle, LV_EVENT_VALUE_CHANGED, NULL);
	lv_slider_set_range(private_data->lcd_slider, 0, 255);
	lv_slider_set_value(private_data->lcd_slider, Golf_Info.backlight_value * 8, LV_ANIM_OFF);
	display_composer_set_brightness(Golf_Info.backlight_value * 8);
	private_data->lcd_slider_label = lv_label_create(src);
	char backlight_str[32] = { 0 };
	snprintf(backlight_str, 32, "%d", Golf_Info.backlight_value * 8);
	lv_label_set_text(private_data->lcd_slider_label, backlight_str);
	lv_obj_align_to(private_data->lcd_slider_label, private_data->lcd_slider, LV_ALIGN_OUT_BOTTOM_MID, 0, 0);
	lv_obj_add_style(private_data->lcd_slider_label, &private_data->style_slider_bg, LV_PART_MAIN);


	return 0;
}

static int destroy_view(view_data_t *view_data)
{
	return 0;
}

static int _power_test_view_preload(view_data_t *view_data)
{

	if (power_test_preload_inited == 0) {
		/*
		lvgl_res_preload_scene_compact_default_init(SCENE_POWER_TEST_VIEW, power_test_resource_id, ARRAY_SIZE(power_test_resource_id),
			NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
		*/
		lvgl_res_preload_scene_compact_default_init(SCENE_POWER_TEST_VIEW, NULL, 0,
			NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
		power_test_preload_inited = 1;
	}

	return lvgl_res_preload_scene_compact_default(SCENE_POWER_TEST_VIEW, POWER_TEST_VIEW, 0, 0);
}

static int _power_test_view_layout(view_data_t *view_data)
{
	private_data = app_mem_malloc(sizeof(*private_data));
	if (private_data == NULL) return -1;

	memset(private_data, 0, sizeof(*private_data));

	view_data->user_data = private_data;
	load_resource(view_data);
	create_view(view_data);
	lv_refr_now(view_data->display);
	return 0;
}

static int _power_test_view_delete(view_data_t *view_data)
{
//	lvgl_res_preload_cancel_scene(SCENE_POWER_TEST_VIEW);
	unload_resource(view_data);
	destroy_view(view_data);
	lvgl_bitmap_font_close(&private_data->font);

	app_mem_free(private_data);
	private_data = NULL;

	lvgl_res_unload_scene_compact(SCENE_POWER_TEST_VIEW);
	return 0;
}

int power_test_view_handler(uint16_t view_id, uint8_t msg_id, void *msg_data)
{
	int ret = 0;
	view_data_t *view_data = msg_data;

	SYS_LOG_INF("%s: %d %d\n", __func__, view_id, POWER_TEST_VIEW);
	assert(view_id == POWER_TEST_VIEW);

	switch (msg_id) {
	case MSG_VIEW_PRELOAD:
		ret = _power_test_view_preload(view_data);
		break;
	case MSG_VIEW_LAYOUT:
		ret = _power_test_view_layout(view_data);
		break;
	case MSG_VIEW_DELETE:
		ret = _power_test_view_delete(view_data);
		break;
//	case MSG_VIEW_UPDATE:
		break;
	default:
		break;
	}
	return ret;
}

VIEW_DEFINE(power_test_view, power_test_view_handler, NULL,
		NULL, POWER_TEST_VIEW, NORMAL_ORDER, UI_VIEW_LVGL, DEF_UI_VIEW_WIDTH, DEF_UI_VIEW_HEIGHT);


