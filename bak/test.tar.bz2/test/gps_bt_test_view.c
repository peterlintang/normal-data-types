/*
 * Copyright (c) 2020 Actions Technology Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#include <assert.h>
#include <lvgl.h>
#include <lvgl/lvgl_res_loader.h>
#include <lvgl/lvgl_bitmap_font.h>

#include <ui_manager.h>
#include <view_manager.h>
#include "widgets/anim_img.h"
#include "widgets/img_number.h"





#include <res_manager_api.h>
#include "app_ui.h"
#include "app_defines.h"
#include "system_app.h"
#include <view_stack.h>
#include <acts_bluetooth/host_interface.h>

#include <bt_manager.h>
#include "uart2_to_gps.h"
#include <sys_wakelock.h>

#include <stdio.h>
#include <fs_manager.h>
#include <fs/fs.h>
#include <fs/fs.h>
#include <fs/fs_sys.h>
#include <drivers/rtc.h>
#include <drivers/uart.h>

#define SCENE_ID SCENE_GPS_BT_TEST_VIEW
#define VIEW_ID  GPS_BT_TEST_VIEW  
#define SETTING_ITEM_RADIUS_VAL  12
#define SETTING_ITEM_BG_COLOR_VAL  lv_color_hex(0x1a1a1a)

#define GPS_ON 	0
#define GPS_OFF 1


#define GPS_HOT_ON 	2
#define GPS_HOT_OFF 3

/*
 *
 *
 */

static const uint16_t gps_view_id_list[] = {
	GPS_BT_TEST_VIEW,
/*	GPS3_VIEW,*/
};
static const void *gps_view_presenter_list[] = {
	NULL,
	NULL,
};

static const view_cache_dsc_t view_cache_dsc = {
        .type = PORTRAIT,
        .rotate = 1,
        .serial_load = 1,
        .num = ARRAY_SIZE(gps_view_id_list),
        .vlist = gps_view_id_list,
        .plist = gps_view_presenter_list,
        .cross_attached_view = VIEW_INVALID_ID,/* GPS2_VIEW,*/
        .cross_vlist = { VIEW_INVALID_ID , VIEW_INVALID_ID ,  },
        .cross_plist = { NULL, NULL, },

};

void gps_view_init(void)
{
//	extern k_tid_t uart_tid ;
//	k_thread_start(uart_tid);
//        view_stack_clean();
        view_stack_push_cache(&view_cache_dsc, GPS_BT_TEST_VIEW);
}

void gps_view_deinit(void)
{
}


/*********
 *
 *
 *************/


static u8_t gps_state=GPS_ON;
//static u8_t bt_state=BT_ON;
static u8_t gps_hot_state=GPS_HOT_ON;

const static uint32_t _img_ids[] = {
  PIC_GPS_ON,
  PIC_GPS_OFF,
  PIC_HOT_ON,
  PIC_HOT_OFF,

};

const static uint32_t _txt_ids[] = {
	STR_GPS_SWITCH,
	STR_GPS_DATA,
	STR_GPS_WARM_BOOT,
	STRING31771,

};


typedef struct gps_bt_test_view_data {
	lv_obj_t *obj;
    lv_obj_t *obj_switch[2];
	lv_obj_t *set_time_block;

	lvgl_res_scene_t  res_scene;
//	lv_img_dsc_t	  res_imgs[4];
	lvgl_res_string_t res_txts[4];

	/* lvgl property resource */
	lv_point_t pt_imgs[4];

	lv_coord_t lim_pad_top;
	lv_coord_t lim_pad_bottom;
	lv_coord_t lim_pad_left;
	lv_coord_t lim_pad_row;

    lv_style_t sty_btn_1line;
	lv_style_t sty_btn_2line;
	lv_style_t style_txts[4];

	lv_font_t font_def;
	lv_font_t font_14;
//	lv_obj_t *obj_swtich;
	lv_obj_t *label_time;
	
	lv_obj_t *obj_swtich_bt;
	lv_timer_t *timer;
	lv_obj_t *cold_start_btn;
	lv_obj_t *hot_start_btn;
	lv_obj_t *save_log_btn;
	lv_obj_t *label_gps_data;
//	lv_obj_t *obj_swtich_gps_hot;

	lv_style_t style;
	lv_style_t style3;
	
} gps_bt_test_view_data_t;

static gps_bt_test_view_data_t *gps_bt_test_view_data = NULL;

static int save_log_gps_point(struct rtc_time *tm);

static void init_txt_style(gps_bt_test_view_data_t *data, lv_style_t *sty, lvgl_res_string_t *txt, uint32_t num)
{
	for (int i = 0; i < num; i++)
	{
		lv_style_init(&sty[i]);
		lv_style_set_x(&sty[i], txt[i].x);
		lv_style_set_y(&sty[i], txt[i].y);
		lv_style_set_width(&sty[i], txt[i].width);
		lv_style_set_height(&sty[i], txt[i].height);
		lv_style_set_text_color(&sty[i], txt[i].color);
		lv_style_set_text_align(&sty[i], txt[i].align);
		lv_style_set_text_font(&sty[i], &data->font_def);
		SYS_LOG_INF("%s: %d %d %d %d\n", __func__, txt[i].x, txt[i].y, txt[i].width, txt[i].height);
	}
}

static void gps_bt_test_view_unload_resource(gps_bt_test_view_data_t *data)
{
	lvgl_res_preload_cancel_scene(SCENE_ID);
	lvgl_res_unload_scene_compact(SCENE_ID);

	if (data)
	{
		lvgl_bitmap_font_close(&data->font_def);

		lvgl_res_unload_strings(data->res_txts, 4);
//		lvgl_res_unload_pictures(data->res_imgs, 4);

		lvgl_res_unload_scene(&data->res_scene);
	}
}


static int gps_bt_test_view_load_resource(gps_bt_test_view_data_t *data)
{
    int ret;
//	uint32_t grp_id;
 //   lvgl_res_group_t res_grp;

	/* load scene */
	ret = lvgl_res_load_scene(SCENE_ID, &data->res_scene, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
	if (ret < 0)
	{
		SYS_LOG_ERR("SCENE_ID not found");
		return -ENOENT;
	}

#if 1
	/* open font */
	if (lvgl_bitmap_font_open(&data->font_def, DEF_FONT16_FILE) < 0)
	{
		SYS_LOG_ERR("font not found");
		return -ENOENT;
	}

	
#if 0

	lv_style_init(&data->sty_btn_1line);
	grp_id = RES_SETTIME_1LINE_BTN_STY;  
	ret = lvgl_res_load_group_from_scene(&data->res_scene, grp_id, &res_grp);
	if (ret < 0)
	{
		goto out_exit;
	}
	else
	{

		lv_style_set_x(&data->sty_btn_1line, 2);
		lv_style_set_y(&data->sty_btn_1line, 78);
		lv_style_set_width(&data->sty_btn_1line, 316);
		lv_style_set_height(&data->sty_btn_1line, 78);
		lv_style_set_bg_opa(&data->sty_btn_1line, LV_OPA_COVER);
		lv_style_set_bg_color(&data->sty_btn_1line, SETTING_ITEM_BG_COLOR_VAL);
		lv_style_set_radius(&data->sty_btn_1line, SETTING_ITEM_RADIUS_VAL);

		
	}

	lv_style_init(&data->sty_btn_2line);
	grp_id = RES_SETTIME_1LINE_BTN_STY2;
	ret = lvgl_res_load_group_from_scene(&data->res_scene, grp_id, &res_grp);
	if (ret < 0)
	{
		goto out_exit;
	}
	else
	{

		lv_style_set_x(&data->sty_btn_2line, 2);
		lv_style_set_y(&data->sty_btn_2line, 168);
		lv_style_set_width(&data->sty_btn_2line, 316);
		lv_style_set_height(&data->sty_btn_2line, 78);
		lv_style_set_bg_opa(&data->sty_btn_2line, LV_OPA_COVER);
		lv_style_set_bg_color(&data->sty_btn_2line, SETTING_ITEM_BG_COLOR_VAL);
		lv_style_set_radius(&data->sty_btn_2line, SETTING_ITEM_RADIUS_VAL);

	}

#endif

	/* load pic resource */
	/*
	ret = lvgl_res_load_pictures_from_scene(&data->res_scene, _img_ids, data->res_imgs, data->pt_imgs, 4);
	if (ret < 0)
	{
		goto out_exit;
	}
	*/

	/* load string */
	ret = lvgl_res_load_strings_from_scene(&data->res_scene, _txt_ids, data->res_txts, 4);
	if (ret < 0)
	{
		goto out_exit;
	}
	init_txt_style(data, data->style_txts, data->res_txts, 4);




#endif
out_exit:
	if (ret < 0)
	{
		gps_bt_test_view_unload_resource(data);
	}

	SYS_LOG_INF("load resource succeed");
	return 0;
}

#include <drivers/uart.h>
static void _set_epoc(void)
{
#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);

        unsigned char *cmd = NULL;

	unsigned char *str = NULL;
	/*
	str = "$PAIR066,1,0,1,0,1,0*3B\r\n";
//	str = "$PAIR066,1,1,1,1,0,0*3A\r\n";
	for (int i = 0; i < strlen(str); i++)
	{
		uart_poll_out(gps_uart, str[i]);
	}
	*/
//      unsigned char *str = "$PAIR732,1*21\r\n";

        cmd = "$PAIR496,1*2C\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));

	/*
        cmd = "$PAIR497,1*2D\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));
	*/

//        cmd = "$PAIR498,5*26\r\n";
        cmd = "$PAIR498,1*22\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));

        cmd = "$PAIR510,0*22\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));

        cmd = "$PAIR513*3D\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));

}

static void _save_epoc(void)
{
#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        gps_uart = device_get_binding(GPS_DEVICE);

        unsigned char *cmd = NULL;

#if 0
        cmd = "$PAIR007*3D\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20 * 5));
#endif
#if 0
        cmd = "$PAIR507*38\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20 * 5));

        cmd = "$PAIR496,0*2D\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20 * 5));

        cmd = "$PAIR513*3D\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));

	return ;
#endif

	/*

        cmd = "$PAIR511*3F\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));

        cmd = "$PAIR513*3D\r\n";
        printf("cmd: %s\n", cmd);
        for (int i = 0; i < (int)strlen(cmd); i++)
        {
                uart_poll_out(gps_uart, cmd[i]);
        }
        k_sleep(K_MSEC(20));
	*/

}

static unsigned char Ql_Check_XOR(const unsigned char *pData, unsigned int Length)
{
        unsigned char result = 0;
        unsigned int i = 0;
        if((NULL == pData) || (Length < 1))
        {
                return 0;
        }

        for(i = 0; i < Length; i++)
        {
                result ^= *(pData + i);
        }
        return result;
}

void _send_utc_ref(void)
{
#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        struct rtc_time rtc_time;
        struct rtc_time *tm = &rtc_time;

        const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);

        gps_uart = device_get_binding(GPS_DEVICE);
        rtc_get_time(rtc, &rtc_time);

        uint8_t temp_buffer[128 + 64] = { 0 };
        uint8_t cmd[128] = { 0 };
        unsigned char checksum = 0;
        snprintf(cmd, 128, "PAIR590,%d,%d,%d,%d,%d,%d", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
                tm->tm_hour, tm->tm_min, tm->tm_sec);

	if (tm->tm_year + 1900 < 2025)
		return ;

        checksum = Ql_Check_XOR(cmd, strlen(cmd));
        snprintf(temp_buffer, 190, "$%s*%02X\r\n", cmd, checksum);
        printf("%s send: %s\n", __func__, temp_buffer);
        for (int i = 0; i < strlen(temp_buffer); i++)
        {
                uart_poll_out(gps_uart, temp_buffer[i]);
        }
        k_sleep(K_MSEC(5));



}

void _send_loc_ref(void)
{
#define GPS_DEVICE                      "UART_2"
        const struct device* gps_uart = NULL;
        struct rtc_time rtc_time;
        struct rtc_time *tm = &rtc_time;
        uint8_t temp_buffer[128 + 64] = { 0 };
        uint8_t cmd[128] = { 0 };
        unsigned char checksum = 0;

        const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);

        gps_uart = device_get_binding(GPS_DEVICE);

        char pos[128] = { 0 };
        struct fs_file_t zfp;
        memset(&zfp, 0, sizeof(zfp));
        if (fs_open(&zfp, "/NAND:/pos.txt", FA_READ))
        {
                printf("cant open file %s\n", "/NAND:/pos.txt");
        }
        else
        {
                double lat;
                double ati;
                char *start = NULL;
                char *p = NULL;
                printf("open file %s success\n", "/NAND:/pos.txt");
                int ret = fs_read(&zfp, pos, 128);
                fs_close(&zfp);

                start = pos;
                p = strchr(start, ',');
                *p = '\0';
                lat = atof(start);

                start = p + 1;
                ati = atof(start);

                memset(cmd, 0, 128);
                snprintf(cmd, 128, "PAIR600,%.6f,%.6f,%.1f,%.1f,%.1f,%d,%.1f",
                                                     lat, ati, 0.0, 0.0, 0.0, 0, 0.0);
                checksum = Ql_Check_XOR(cmd, strlen(cmd));
                memset(temp_buffer, 0, 190);
                snprintf(temp_buffer, 190, "$%s*%02X\r\n", cmd, checksum);
                printf("%s send: %s\n", __func__, temp_buffer);
                for (int i = 0; i < strlen(temp_buffer); i++)
                {
                        uart_poll_out(gps_uart, temp_buffer[i]);
                }

//              k_sleep(K_MSEC(5));
        }
}






static int fix_flag = 0;
static int show_flag = 0;
static int fix_timeout = 0;
static int gps_hot_flag = 0;
static int gps_hot_duration_time = 0;
static void open_gps_switch_btn_event_handler(lv_event_t * e)
{
	gps_bt_test_view_data_t *data = gps_bt_test_view_data;

	printf("%s: call\n", __func__);

	_save_epoc();

	gps_state = GPS_OFF;
	gps_close();
	extern GPS_INFO GPS;
	memset(&GPS,0,sizeof(GPS));
		
	k_sleep(K_MSEC(300));
	gps_state = GPS_ON;
	gps_open();

	gps_hot_duration_time = 0;
	gps_hot_flag = 1;
	fix_flag = 0;
	fix_timeout = 0;
	show_flag = 0;
	printf("%s: %d %d\n", __func__, gps_hot_duration_time, gps_hot_flag );

}

/*
static void open_bt_switch_btn_event_handler(lv_event_t * e)
{
	gps_bt_test_view_data_t *data = gps_bt_test_view_data;

	if(bt_state == BT_ON)
	{
		bt_state = BT_OFF;
		//off
	 hostif_bt_le_adv_stop();
	 bt_manager_set_visible(false);
	 bt_manager_set_connectable(false);

	}	
	else
	{	
		bt_state = BT_ON;
		//open
		bt_le_adv_reset();
		
	bt_manager_set_visible(true);
	bt_manager_set_connectable(true);
	}
	lv_img_set_src(data->obj_swtich_bt, &data->res_imgs[bt_state]);
	lv_obj_set_pos(data->obj_swtich_bt, data->pt_imgs[2].x, data->pt_imgs[2].y);

}
*/

static int is_gps_points_file_open = 0;
static struct fs_file_t gps_zfp;
static void gps_save_log_btn_event_handler(lv_event_t * e)
{
	extern GPS_INFO GPS;
//	char file_name[] = "/NAND:/gps_points.txt";
	char file_name[64] = "";
	char str[128] = { 0 };
	uint32_t hour,minute,second,day,month,year; 
	struct rtc_time rtc_time;
	struct rtc_time *tm = &rtc_time;

	_set_epoc();
	extern int set_gps_save_flag(int value);
	set_gps_save_flag(1);

	sscanf(GPS.time,"%2d%2d%2d",&hour,&minute,&second);
	sscanf(GPS.date,"%2d%2d%2d",&day,&month,&year);
	tm->tm_hour = hour;
	tm->tm_min = minute;
	tm->tm_sec = second;
	tm->tm_year = year + 2000 - 1900;
	tm->tm_mon = month - 1;
	tm->tm_mday = day;

	printf("%s: gps_points_file_open: %d\n", __func__, is_gps_points_file_open );
	if (is_gps_points_file_open == 0)
	{
		int ret = 0;
		memset(&gps_zfp, 0, sizeof(gps_zfp));
		memset(file_name, 0, 64);
		snprintf(file_name, 64, "/NAND:/%4d%02d%02d%02d%02d%02d_points.txt", 
				1900 + tm->tm_year, 
				tm->tm_mon + 1, 
				tm->tm_mday,
				tm->tm_hour, 
				tm->tm_min, 
				tm->tm_sec
				);
		if (ret = fs_open(&gps_zfp, file_name, FS_O_RDWR | FS_O_CREATE | FS_O_APPEND))
		{
			SYS_LOG_ERR("open file for log failed, ret: %d\n", ret);
			return ;
		}
		is_gps_points_file_open = 1;
	}
	else
	{
		is_gps_points_file_open = 0;
		fs_close(&gps_zfp);
	}
}
static int save_log_gps_point(struct rtc_time *tm)
{
	char str[128] = { 0 };
	extern GPS_INFO GPS;

	if (is_gps_points_file_open == 0) return -1;


	int len = snprintf(str, 128, "%04d-%02d-%02d %02d-%02d-%02d %.8f %.8f\n", 
			1900 + tm->tm_year, 
			tm->tm_mon + 1, 
			tm->tm_mday,
			tm->tm_hour, 
			tm->tm_min, 
			tm->tm_sec,
			GPS.latitude,
			GPS.longitude
			);
	printf("%s: str: %s, len: %d\n", __func__, str, len);
	fs_write(&gps_zfp, str, len);

	return 0;
}

#if 1
static void open_gps_hot_switch_btn_event_handler(lv_event_t * e)
{
	gps_bt_test_view_data_t *data = gps_bt_test_view_data;

	printf("%s: call\n", __func__);
#if 1
//	if(gps_hot_state == GPS_HOT_ON)
	{
		gps_hot_state = GPS_HOT_OFF;
		backup_entry();
	}
	k_sleep(K_MSEC(500));
//	else
	{
	extern GPS_INFO GPS;
	memset(&GPS,0,sizeof(GPS));
	gps_hot_duration_time = 0;
	gps_hot_flag = 1;
	fix_flag = 0;
	show_flag = 0;
	fix_timeout = 0;
		gps_hot_state = GPS_HOT_ON;
	backup_quit();
	}

	
#endif

}

#endif

/*
struct s {
        int sn;
        int id;
};

static int cmp(const void *arg1, const void *arg2)
{
        struct s *s1 = (struct s*)arg1;
        struct s *s2 = (struct s*)arg2;

        if (s1->sn > s2->sn)
                return -1;
        else if (s1->sn < s2->sn)
                return 1;
        else
                return 0;
}
*/

/*
int has_send_496 = 0;
int has_send_511 = 0;
*/
#include "math.h"

static void timer_ing_update(lv_timer_t *timer)
{
	return ;
}

static int gps_bt_test_updated(view_data_t *view_data)
{
//	view_data_t *view_data = timer->user_data;
	gps_bt_test_view_data_t* data = view_data->user_data;

	char text[680] = {0};
	extern GPS_INFO GPS;

	static float s_acc_mg[3];
	static float s_ang_mdps[3];
	static float acc_mg[3];
	static float ang_mdps[3];
	extern void lsm6dsv16x_read_data_polling(float *acc_mg, float *ang_mdps);
	s_acc_mg[0] = acc_mg[0];
	s_acc_mg[1] = acc_mg[1];
	s_acc_mg[2] = acc_mg[2];
	lsm6dsv16x_read_data_polling(acc_mg, ang_mdps);


	printf("%s: time: %d, flag: %d, valid: %d,  %d %d %d, %d %d %d\n", 
			__func__, gps_hot_duration_time, gps_hot_flag, GPS.valid, 
			(fix_flag), (GPS.gps_fixed), (gps_hot_flag),
			(fix_timeout), (show_flag), (0)
			);

	if (gps_hot_flag)
	{
		if (fix_flag == 0)
			gps_hot_duration_time++;
	}

	if (GPS.gps_fixed == 3 || GPS.gps_fixed == 2)
	{
	if (fix_flag == 0)
	{
		struct rtc_time tm;
		const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);
		uint32_t hour,minute,second,day,month,year; 

		sscanf(GPS.time,"%2d%2d%2d",&hour,&minute,&second);
		sscanf(GPS.date,"%2d%2d%2d",&day,&month,&year);

                tm.tm_hour = hour;
                tm.tm_min = minute;
                tm.tm_sec = second;
		tm.tm_ms = 0;
                tm.tm_year = year + 2000 - 1900;
                tm.tm_mon = month - 1;
                tm.tm_mday = day;
                rtc_set_time(rtc,&tm);
	}

		fix_flag = 1;
		gps_hot_flag = 0;
	}

	/*
	if (GPS.valid)
	{
		gps_hot_flag = 0;
	}
	*/

	if (gps_hot_duration_time - 1 > 180)
		fix_timeout = 1;

	char status[32] = { 0 };
	if (fix_timeout == 1)
		snprintf(status, 32, " %s", "failed");
	else
		snprintf(status, 32, " %ds", gps_hot_duration_time - 1);

	int ret = 0;
	char *pp = NULL;
	if (GPS.gps_fixed == 3)
		pp = "3d fixed";
	else if (GPS.gps_fixed == 2)
		pp = "2d fixed";
	else
		pp = "can't fixed";

	char *s_snr = NULL;
	char *s_id = NULL;
	if (GPS.snr[0] == '\0')
		s_snr = " ";
	else
		s_snr = GPS.snr;
	if (GPS.id[0] == '\0')
		s_id = " ";
	else
		s_id = GPS.id;

	uint32_t hour,minute,second,day,month,year; 
	struct rtc_time rtc_time;
	struct rtc_time *tm = &rtc_time;
	sscanf(GPS.time,"%2d%2d%2d",&hour,&minute,&second);
	sscanf(GPS.date,"%2d%2d%2d",&day,&month,&year);
	tm->tm_hour = hour;
	tm->tm_min = minute;
	tm->tm_sec = second;
	tm->tm_year = year + 2000 - 1900;
	tm->tm_mon = month - 1;
	tm->tm_mday = day;
	if (GPS.gps_fixed == 3 || GPS.gps_fixed == 2)
	{
		
#if 0
if (fabsf(acc_mg[0] - s_acc_mg[0]) < 20.0 && show_flag
		&& fabsf(acc_mg[1] - s_acc_mg[1]) < 20.0 
		&& fabsf(acc_mg[2] - s_acc_mg[2]) < 20.0)
{
	printf("%s: no move\n", __func__);
	return ;
}
	show_flag = 1;
#endif
	
		
        	ret = snprintf(text, 680, "\n  %04d/%02d/%02d                  %s\n  num: %d                    %s\n\n  %c %.8f     sp: %.8f\n  %c %.8f  alt: %.8f\n                              %s\n  sat:%s\n  snr:%s",
                        tm->tm_year + 1900,
                        tm->tm_mon + 1,
                        tm->tm_mday,
                        status,
                        GPS.numSat,
                        pp,
			GPS.NS == '\0' ? ' ' : GPS.NS, 
			GPS.latitude, 
			0.0001,
			GPS.EW == '\0' ? ' ' : GPS.EW, 
			GPS.longitude, 
			GPS.height,
			is_gps_points_file_open == 1 ?	"logging" : "",
                        s_id,
                        s_snr);
	}
	else
	{
	show_flag = 0;
        	ret = snprintf(text, 680, "\n  %04d/%02d/%02d                 %s\n  num: %d                      %s\n\n\n  sat:%s\n  snr:%s\n",
                        tm->tm_year + 1900,
                        tm->tm_mon + 1,
                        tm->tm_mday,
                        status,
                        GPS.numSat,
                        pp,
                        s_id,
                        s_snr);
	}
	text[ret] = '\0';

	lv_label_set_text(data->label_gps_data, text);
	save_log_gps_point(tm);

	/*
	struct device* gps_uart = NULL;
	gps_uart = device_get_binding("UART_2");
	unsigned char *str2 = NULL;
if (has_send_496 == 0)
{
	str2 = "$PAIR508*37\r\n";
	printf("%s send: %s\n", __func__, str2);
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
}

	k_sleep(K_MSEC(20));
	*/

	/*
if (has_send_511 == 0)
{
	str2 = "$PAIR509,1*2B\r\n";
	printf("%s send: %s\n", __func__, str2);
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
}
if (has_send_511 == 0)
{
	struct device* gps_uart = NULL;
	gps_uart = device_get_binding("UART_2");
	unsigned char *str2 = NULL;
	str2 = "$PAIR498,5*26\r\n";
	printf("%s send: %s\n", __func__, str2);
	for (int i = 0; i < strlen(str2); i++)
	{
		uart_poll_out(gps_uart, str2[i]);
	}
}
*/
}


static int gps_bt_test_view_create(view_data_t *view_data)
{
	SYS_LOG_INF("gps_bt_test_view_create !!!");

	/*
	has_send_511 = 0;
	has_send_496 = 0;
	*/
	
	extern k_tid_t uart_tid ;
	k_thread_resume(uart_tid);
//	display_composer_set_brightness(0);
	
	sys_wake_lock(FULL_WAKE_LOCK);
	
	lv_obj_t *scr = lv_disp_get_scr_act(view_data->display);
	gps_bt_test_view_data_t *data = view_data->user_data;

	lv_obj_set_style_bg_color(scr, data->res_scene.background, LV_PART_MAIN);
	lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, LV_PART_MAIN);

	data->obj = lv_obj_create(scr);
	lv_obj_set_size(data->obj, DEF_UI_WIDTH, DEF_UI_HEIGHT);

	if (data->obj == NULL)
	{
		gps_bt_test_view_unload_resource(data);
		return -ENOMEM;
	}

	/*
	lv_obj_t *label_time_setting_title = lv_label_create(data->obj);
	lv_label_set_text(label_time_setting_title, data->res_txts[0].txt);
	lv_obj_add_style(label_time_setting_title, &data->style_txts[0], LV_PART_MAIN);
	*/


//  lv_obj_t *obj_main_btn_1line = lv_obj_create(data->obj);
//  lv_obj_add_style(obj_main_btn_1line, &data->sty_btn_1line, LV_PART_MAIN);


	lv_obj_t *label_gps_switch = lv_label_create(data->obj);
//	lv_label_set_text(label_gps_switch, data->res_txts[0].txt);
	lv_label_set_text(label_gps_switch, "cold start");
	lv_obj_add_style(label_gps_switch, &data->style_txts[0], LV_PART_MAIN);
	//lv_obj_set_style_text_align(label_gps_switch, LV_TEXT_ALIGN_LEFT, 0);
//	lv_obj_set_width(label_gps_switch,300);

lv_obj_t *label_gps_hot_switch = lv_label_create(data->obj);
//lv_label_set_text(label_gps_hot_switch, data->res_txts[2].txt);
lv_label_set_text(label_gps_hot_switch, "hot start");
lv_obj_add_style(label_gps_hot_switch, &data->style_txts[2], LV_PART_MAIN);
//lv_obj_set_style_text_align(label_gps_hot_switch, LV_TEXT_ALIGN_LEFT, 0);

	lv_obj_t *label_save_log = lv_label_create(data->obj);
//	lv_label_set_text(label_gps_switch, data->res_txts[0].txt);
	lv_label_set_text(label_save_log, "save log");
	lv_obj_add_style(label_save_log, &data->style_txts[3], LV_PART_MAIN);

//	lv_obj_t *obj_main_btn_2line = lv_obj_create(data->obj);
//	lv_obj_add_style(obj_main_btn_2line, &data->sty_btn_2line, LV_PART_MAIN);
//	lv_obj_add_event_cb(obj_main_btn_2line, arrow_event_handler, LV_EVENT_PRESSED, NULL);
//	lv_obj_add_event_cb(obj_main_btn_2line, arrow_event_handler, LV_EVENT_SHORT_CLICKED, NULL);

/*
	lv_obj_t *label_bt_switch = lv_label_create(data->obj);
	lv_label_set_text(label_bt_switch, data->res_txts[1].txt);
	lv_obj_add_style(label_bt_switch, &data->style_txts[1], LV_PART_MAIN);
//	lv_obj_set_width(label_gps_switch,300);
	*/


	data->label_gps_data = lv_label_create(data->obj);
	lv_label_set_text(data->label_gps_data, data->res_txts[1].txt);
	lv_obj_add_style(data->label_gps_data, &data->style_txts[1], LV_PART_MAIN);
//	lv_obj_set_style_text_align(data->label_gps_data, LV_TEXT_ALIGN_CENTER, 0);
	lv_obj_set_style_text_align(data->label_gps_data, LV_TEXT_ALIGN_LEFT, 0);

	extern void lsm6dsv16x_init(void);
	lsm6dsv16x_init();
	data->timer = lv_timer_create(timer_ing_update, 1000, view_data);
	if (data->timer)
		lv_timer_ready(data->timer);

        lv_style_init(&data->style);
        lv_style_set_bg_opa(&data->style, LV_OPA_0);
        lv_style_set_bg_color(&data->style, /*lv_palette_main(LV_PALETTE_BLUE)*/lv_color_hex(0x000000));
        lv_style_set_border_width(&data->style, 2); // 边框宽度
        lv_style_set_border_color(&data->style, lv_color_hex(0x000000)); // 边框颜色
        lv_style_set_border_opa(&data->style, LV_OPA_50); // 边框透明度
        lv_style_set_border_side(&data->style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向

	lv_style_init(&data->style3);
	lv_style_set_bg_opa(&data->style3, LV_OPA_50);
    	lv_style_set_bg_color(&data->style3, lv_palette_main(LV_PALETTE_BLUE)/*lv_color_hex(0x3c3c3c)*/);
	lv_style_set_border_width(&data->style3, 2); // 边框宽度
	lv_style_set_border_color(&data->style3, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&data->style3, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&data->style3, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向

	data->cold_start_btn = lv_btn_create(data->obj);
	lv_obj_add_style(data->cold_start_btn, &data->style_txts[0], LV_PART_MAIN);
	lv_obj_add_style(data->cold_start_btn, &data->style, LV_PART_MAIN);
	lv_obj_add_style(data->cold_start_btn, &data->style3, LV_STATE_PRESSED);
	lv_obj_add_event_cb(data->cold_start_btn, open_gps_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);

	/*
	data->obj_swtich = lv_img_create(data->obj);
	lv_img_set_src(data->obj_swtich, &data->res_imgs[gps_state]);
	lv_obj_set_pos(data->obj_swtich, data->pt_imgs[1].x, data->pt_imgs[1].y);
	lv_obj_add_flag(data->obj_swtich, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(data->obj_swtich, open_gps_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);
	*/

	/*
	data->obj_swtich_bt = lv_img_create(data->obj);
	lv_img_set_src(data->obj_swtich_bt, &data->res_imgs[bt_state]);
	lv_obj_set_pos(data->obj_swtich_bt, data->pt_imgs[2].x, data->pt_imgs[2].y);
	lv_obj_add_flag(data->obj_swtich_bt, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(data->obj_swtich_bt, open_bt_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);
	*/
#if 1
	data->hot_start_btn = lv_btn_create(data->obj);
	lv_obj_add_style(data->hot_start_btn, &data->style_txts[2], LV_PART_MAIN);
	lv_obj_add_style(data->hot_start_btn, &data->style, LV_PART_MAIN);
	lv_obj_add_style(data->hot_start_btn, &data->style3, LV_STATE_PRESSED);
	lv_obj_add_event_cb(data->hot_start_btn, open_gps_hot_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);

	data->save_log_btn = lv_btn_create(data->obj);
	lv_obj_add_style(data->save_log_btn, &data->style_txts[3], LV_PART_MAIN);
	lv_obj_add_style(data->save_log_btn, &data->style, LV_PART_MAIN);
	lv_obj_add_style(data->save_log_btn, &data->style3, LV_STATE_PRESSED);
	lv_obj_add_event_cb(data->save_log_btn, gps_save_log_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);
	/*
	data->obj_swtich_gps_hot = lv_img_create(data->obj);
	lv_img_set_src(data->obj_swtich_gps_hot, &data->res_imgs[gps_hot_state]);
	lv_obj_set_pos(data->obj_swtich_gps_hot, data->pt_imgs[3].x, data->pt_imgs[3].y);
	lv_obj_add_flag(data->obj_swtich_gps_hot, LV_OBJ_FLAG_CLICKABLE);
	lv_obj_add_event_cb(data->obj_swtich_gps_hot, open_gps_hot_switch_btn_event_handler, LV_EVENT_SHORT_CLICKED, NULL);
	*/
#endif
	gps_close();
	extern GPS_INFO GPS;
	memset(&GPS, 0, sizeof(GPS_INFO));
//	gps_close();
	gps_state = GPS_ON;
	gps_state = GPS_OFF;
	
	gps_state = GPS_OFF;
	gps_close();
	extern GPS_INFO GPS;
	memset(&GPS,0,sizeof(GPS));
		
	k_sleep(K_MSEC(300));
	gps_state = GPS_ON;
	gps_open();

	gps_hot_duration_time = 0;
	gps_hot_flag = 1;
	fix_flag = 0;
	fix_timeout = 0;
	printf("%s: %d %d\n", __func__, gps_hot_duration_time, gps_hot_flag );
	show_flag = 0;
	return 0;
}



static int epoc_set_flag = 0;
static int gps_bt_test_view_layout(view_data_t *view_data)
{
	int ret;
	gps_bt_test_view_data_t *data = view_data->user_data;


	data = app_mem_malloc(sizeof(*data));
	if (!data)
	{
		return -ENOMEM;
	}
	view_data->user_data = data;
	memset(data, 0, sizeof(*data));
	gps_bt_test_view_data = data;
	if (gps_bt_test_view_load_resource(data))
	{
		app_mem_free(data);
		view_data->user_data = NULL;
		return -ENOENT;
	}

	ret = gps_bt_test_view_create(view_data);
	if(ret < 0)
	{
		return ret;
	}
	lv_refr_now(view_data->display);

	
	if (epoc_set_flag == 0)
	{
	epoc_set_flag = 1;
        k_sleep(K_MSEC(600));
	_set_epoc();
	}
	

	return 0;
}

static int gps_bt_test_view_preload(view_data_t *view_data)
{
	static bool time_setting_ready = false;

	if (time_setting_ready == 0)
	{
		lvgl_res_preload_scene_compact_default_init(SCENE_ID, NULL, 0,
			NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
		time_setting_ready = 1;
	}

	return lvgl_res_preload_scene_compact_default(SCENE_ID, VIEW_ID, 0, 0);
}

static int gps_bt_test_view_delete(view_data_t *view_data)
{
	gps_bt_test_view_data_t *data = view_data->user_data;
	sys_wake_unlock(FULL_WAKE_LOCK);
	
	_save_epoc();
        k_sleep(K_MSEC(20));
	extern int save_gps_log_deinit(void);
	save_gps_log_deinit();
	
	extern k_tid_t uart_tid ;
	
	
	k_thread_suspend(uart_tid);
	gps_close();
	
//	display_composer_set_brightness(128);
	
	

	if (is_gps_points_file_open == 1)
	{
		is_gps_points_file_open = 0;
		fs_close(&gps_zfp);
	}

	if (data) {

		if (data->timer) {
			lv_timer_del(data->timer);
			data->timer = NULL;
		}
		
		for (int i=0; i<3; i++)
		{
			lv_style_reset(&data->style_txts[i]);
		}

	
		lv_style_reset(&data->style);
		lv_style_reset(&data->style3);
		lv_obj_del(data->obj);
		gps_bt_test_view_unload_resource(data);
		app_mem_free(data);
	} else {
		lvgl_res_preload_cancel_scene(SCENE_ID);
	}

	lvgl_res_unload_scene_compact(SCENE_ID);
	return 0;
}





int _gps_bt_test_view_handler(uint16_t view_id, uint8_t msg_id, void *msg_data)
{
	view_data_t *view_data = msg_data;

//	assert(view_id == GPS_BT_TEST_VIEW);

	switch (msg_id) {
	case MSG_VIEW_PRELOAD:
		return gps_bt_test_view_preload(view_data);
	case MSG_VIEW_LAYOUT:
		return gps_bt_test_view_layout(view_data);
	case MSG_VIEW_DELETE:
		return gps_bt_test_view_delete(view_data);
	case MSG_VIEW_UPDATE:
		return 0;
	case MSG_VIEW_PAINT:
		return gps_bt_test_updated(view_data);
	default:
		return 0;
	}
}

VIEW_DEFINE(gps_bt_test_view, _gps_bt_test_view_handler, NULL,
		NULL, GPS_BT_TEST_VIEW, NORMAL_ORDER, UI_VIEW_LVGL, DEF_UI_VIEW_WIDTH, DEF_UI_VIEW_HEIGHT);




















