// ref p4:gps_test_view.c
/*
 * Copyright (c) 2020 Actions Technology Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#include <assert.h>
#include <lvgl.h>
#include <lvgl/lvgl_res_loader.h>
#include <lvgl/lvgl_bitmap_font.h>

#include <ui_manager.h>
#include <view_manager.h>
#include "widgets/anim_img.h"
#include "widgets/img_number.h"

#include <res_manager_api.h>
#include "app_ui.h"
#include "app_defines.h"
#include "system_app.h"
#include <view_stack.h>


#include <sys_wakelock.h>


#ifndef CONFIG_SIMULATOR
#include <acts_bluetooth/host_interface.h>
#include <bt_manager.h>
#endif

#define SCENE_ID 	SCENE_GPS4_VIEW
#define VIEW_ID 	GPS4_VIEW

#define ITEM_NUM	1
typedef struct _gps4_data {

	lv_obj_t *obj;
	/*
	lv_obj_t *obj_line[ITEM_NUM];
	*/
	lv_obj_t *buttons[ITEM_NUM];
	lv_obj_t *labels[ITEM_NUM];
	lv_style_t buttons_style[ITEM_NUM];
	lvgl_res_string_t strs[ITEM_NUM];
	lv_style_t strs_style[ITEM_NUM];
	lv_style_t style_line;

	lv_style_t style;
	lv_style_t style3;

	lv_timer_t *timer;

	lvgl_res_scene_t scene;
	lv_font_t font;

	char gps_info[256];
} gps4_data;

const static uint32_t _txt_ids[ITEM_NUM] = {
    STRING33406
};

static void timer_ing_update(lv_timer_t *timer)
{
//    ui_view_paint(GPS4_VIEW); // _gps_test_view_paint
}

static void init_txt_style(gps4_data *data, lv_style_t *sty, lvgl_res_string_t *txt, uint32_t num)
{
    for (int i = 0; i < num; i++) {
        lv_style_init(&sty[i]);
        lv_style_set_x(&sty[i], txt[i].x);
        lv_style_set_y(&sty[i], txt[i].y);
        lv_style_set_width(&sty[i], txt[i].width);
        lv_style_set_height(&sty[i], txt[i].height);
        lv_style_set_text_color(&sty[i], txt[i].color);
        lv_style_set_text_align(&sty[i], txt[i].align);
	lv_style_set_bg_color(&sty[i], txt[i].bgcolor);
//	lv_style_set_bg_color(&sty[i], lv_color_hex(0x0000ff));

        lv_style_set_text_font(&sty[i], &data->font);
         SYS_LOG_INF("%s: %d %d %d %d\n", __func__, txt[i].x, txt[i].y, txt[i].width, txt[i].height);
    }
}

#include "fw_version.h"
#include <fs/fs.h>
#include <fs/fs_sys.h>
#include <fs_manager.h>
/*
*/
		/*
		*/
#include "drivers/uart.h"
static view_data_t *pp = NULL;
static int start_aac_count = 0;
static int start_record = 0;
static struct fs_file_t zfp;
static void setting_btn_event_handler(lv_event_t * e)
{
        lv_obj_t *btn = lv_event_get_current_target(e);
        int idx = (int)lv_obj_get_user_data(btn);
	printf("%s: idx: %d\n", __func__, idx);
	gps4_data *data = pp->user_data;

	start_record = ~start_record;
	if (start_record)
	{
		memset(&zfp, 0, sizeof(zfp));
		if (fs_open(&zfp, "/NAND:/mag_raw.txt", FA_READ | FA_WRITE | FS_O_CREATE))
		{
			printf("create file failed\n");
		}
	}
	else
	{
		fs_close(&zfp);
	}

	lv_refr_now(pp->display);

}

void test_save_data(float *acc, float *ang, float *mag, uint32_t timestamp)
{
	if (start_record)
	{
		char temp[256] = { 0 };
		int len = 0;
#if 0
		len = snprintf(temp, 128, "%.8f %.8f %.8f\n", 
			mag[0], mag[1], mag[2]);
		fs_write(&zfp, temp, len);
#else
//		if (start_aac_count == 20)
		{
static int64_t my_uptime_m = 0ll;
	if (my_uptime_m == 0ll)
		my_uptime_m = 0;
	//	my_uptime_m = k_uptime_get();
//		start_aac_count = 0;
		len = snprintf(temp, 128, "%.4f "
			"%.6f %.6f %.6f "
			"%.6f %.6f %.6f "
			"%.6f %.6f %.6f\n",
		//	(k_uptime_get() - my_uptime_m) / 1000.0f,
			(timestamp * 21.75) / 1000.0f * 0.001f,
			(acc[0] ), 
			(acc[1] ), 
			(acc[2] ), 
			(ang[0] ), 
			(ang[1] ), 
			(ang[2] ), 
			(mag[0] ), 
			(mag[1] ), 
			(mag[2] ));
		fs_write(&zfp, temp, len);
		}
#endif
		start_aac_count++;
	}
	else
	{
	}
}


static int _view_create(view_data_t *view_data)
{
	lv_obj_t *scr = lv_disp_get_scr_act(view_data->display);
	gps4_data *data = view_data->user_data;
	pp = view_data;
	lv_obj_set_style_bg_color(scr, data->scene.background, LV_PART_MAIN);
	lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, LV_PART_MAIN);

	data->timer = lv_timer_create(timer_ing_update, 1000, view_data);
	if (data->timer)
		lv_timer_ready(data->timer);
	/*
	lv_style_set_bg_opa(&style2, LV_OPA_50);
    	lv_style_set_bg_color(&style2, lv_palette_main(LV_PALETTE_BLUE));
	*/


	data->obj = lv_obj_create(scr);
	lv_obj_set_size(data->obj, DEF_UI_WIDTH , DEF_UI_HEIGHT);
	lv_obj_set_pos(data->obj, 0, 0);
//	lv_obj_add_flag(data->obj, LV_OBJ_FLAG_SCROLLABLE);
//	lv_obj_set_scrollbar_mode(data->obj, LV_SCROLLBAR_MODE_AUTO);
//	lv_obj_set_scroll_dir(data->obj, LV_DIR_VER);
//	lv_obj_add_style(data->obj, &data->strs_style[0], LV_PART_MAIN);

	lv_style_init(&data->style);
	lv_style_set_bg_opa(&data->style, LV_OPA_0);
    	lv_style_set_bg_color(&data->style, /*lv_palette_main(LV_PALETTE_BLUE)*/lv_color_hex(0x000000));
	lv_style_set_border_width(&data->style, 2); // 边框宽度
	lv_style_set_border_color(&data->style, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&data->style, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&data->style, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向

	lv_style_init(&data->style3);
	lv_style_set_bg_opa(&data->style3, LV_OPA_50);
    	lv_style_set_bg_color(&data->style3, lv_palette_main(LV_PALETTE_BLUE)/*lv_color_hex(0x3c3c3c)*/);
	lv_style_set_border_width(&data->style3, 4); // 边框宽度
	lv_style_set_border_color(&data->style3, lv_color_hex(0x000000)); // 边框颜色
	lv_style_set_border_opa(&data->style3, LV_OPA_50); // 边框透明度
	lv_style_set_border_side(&data->style3, LV_BORDER_SIDE_FULL /*LV_BORDER_SIDE_BOTTOM/*LV_BORDER_SIDE_TOP*/); // 边框方向
	// 应用样式到标签

	for (int i = 0; i < ITEM_NUM; i++) 
	{
		data->labels[i] = lv_label_create(data->obj);
		lv_obj_add_style(data->labels[i], &data->strs_style[i], LV_PART_MAIN);
		
//		if (i != 3)
		{
		lv_obj_add_style(data->labels[i], &data->style, LV_PART_MAIN /*LV_STATE_DEFAULT*/);
		lv_obj_add_style(data->labels[i], &data->style3, LV_STATE_PRESSED);
		}
		lv_obj_set_size(data->labels[i], DEF_UI_WIDTH , DEF_UI_HEIGHT);
		lv_obj_set_pos(data->labels[i], 0, 0);
		/*
		lv_obj_set_pos(data->labels[i], 146/2, i * 80 );
		lv_obj_set_size(data->labels[i], 320, 80);
		lv_obj_add_event_cb(data->labels[i], setting_btn_event_handler, LV_EVENT_SHORT_CLICKED,view_data);
		lv_obj_set_user_data(data->labels[i], (void *)i);
		*/

#if 1
		data->buttons[i] = lv_btn_create(data->obj);
		lv_obj_add_style(data->buttons[i], &data->strs_style[i], LV_PART_MAIN);
		//lv_obj_add_flag(data->buttons[i], LV_OBJ_FLAG_CHECKABLE);
//		if (i != 3)
		{
		lv_obj_add_style(data->buttons[i], &data->style, LV_PART_MAIN /*LV_STATE_DEFAULT*/);
		lv_obj_add_style(data->buttons[i], &data->style3, LV_STATE_PRESSED);
		}
		lv_obj_set_size(data->buttons[i], DEF_UI_WIDTH , DEF_UI_HEIGHT);
		lv_obj_set_pos(data->buttons[i], 0, 0);
		/*
		lv_obj_set_pos(data->buttons[i], 146/2, i * 80 );
		lv_obj_set_size(data->buttons[i], 320, 80);
		*/
		lv_obj_add_event_cb(data->buttons[i], setting_btn_event_handler, LV_EVENT_SHORT_CLICKED,view_data);
		lv_obj_set_user_data(data->buttons[i], (void *)i);
         	SYS_LOG_INF("%s: %d %d %d %d\n", __func__, 132, i * 80 + 20, data->strs[i].width, data->strs[i].height);
#endif
	}
	for (int i = 0; i < ITEM_NUM; i++)
	{
		lv_label_set_text(data->labels[i], data->strs[i].txt);
         	SYS_LOG_INF("%s: %s\n", __func__, data->strs[i].txt);
		char *strs[] = {
			"GPS ONLY",
			"ALL Systems",
			"ALL+MULTI-BAND",
			"Auto Select",
			"Ultra Trac",
		};
		lv_label_set_text(data->labels[i], strs[i]);
		/*
		if (i == 1)
		}
		*/
	}


	lv_style_init(&data->style_line);
	lv_style_set_line_width(&data->style_line, 2);
	lv_style_set_line_color(&data->style_line, lv_color_hex(0x000000));
	lv_style_set_line_rounded(&data->style_line, true);
	static lv_point_t line_points[] = { {10, 0}, {330, 0},};

	/*
	for(int i = 0; i < ITEM_NUM; i++)
	{
		data->obj_line[i] = lv_line_create(data->obj);
		lv_obj_add_style(data->obj_line[i], &data->style_line, LV_PART_MAIN);
		lv_line_set_points(data->obj_line[i], line_points, 2);
		lv_obj_align(data->obj_line[i], LV_ALIGN_TOP_MID, 0, i * 80);
	}
	*/


return 0;

}

static int _load_resource(gps4_data *data)
{
    int ret;

    /* load scene */
    ret = lvgl_res_load_scene(SCENE_ID, &data->scene, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
    if (ret < 0) {
        SYS_LOG_ERR("SCENE_ID not found");
        return -ENOENT;
    }

    /* open font */
    if (lvgl_bitmap_font_open(&data->font, DEF_FONT22_FILE) < 0)
    {
        SYS_LOG_ERR("font not found");
        return -ENOENT;
    }

#if 0 
    /* load pic resource */
    ret = lvgl_res_load_pictures_from_scene(&data->scene, _img_ids, data->res_imgs, data->pt_imgs, NUM_IMGS);
    if (ret < 0) {
        goto out_exit;
    }
#endif

    /* load string */
    ret = lvgl_res_load_strings_from_scene(&data->scene, _txt_ids, data->strs, ITEM_NUM);
    if (ret < 0) {
        goto out_exit;
    }
    init_txt_style(data, data->strs_style, data->strs, ITEM_NUM);

out_exit:
    if (ret < 0) {
    }

    SYS_LOG_INF("load resource succeed");
    return 0;
	return 0;
}

static int _unload_resource(gps4_data *data)
{

	//lvgl_res_preload_cancel_scene(SCENE_ID);
	//lvgl_res_unload_scene_compact(SCENE_ID);

	printf("%s unload\n", __func__);
	if (data)
	{
		printf("%s unload 222\n", __func__);
		lvgl_bitmap_font_close(&data->font);
		lvgl_res_unload_strings(data->strs, ITEM_NUM);
		lvgl_res_unload_scene(&data->scene);
	}

	return 0;
}

/*
 *
 */
static int _gps4_view_preload(view_data_t *view_data)
{
    static int resource_preload = 0;

    if (resource_preload == 0) {
        lvgl_res_preload_scene_compact_default_init(SCENE_ID, NULL, 0, NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
        resource_preload = 1;
    }

    return lvgl_res_preload_scene_compact_default(SCENE_ID, VIEW_ID, 0, 0);
}

static int _gps4_view_layout(view_data_t *view_data)
{
	gps4_data *data = view_data->user_data;

	if (data == NULL)
	{
		data = app_mem_malloc(sizeof(*data));
		if (!data) 
		{
			return -ENOMEM;
		}
		memset(data, 0, sizeof(*data));
		view_data->user_data = data;
	}

	_load_resource(data);
	_view_create(view_data);
	lv_refr_now(view_data->display);
	return 0;
}

static int _gps4_view_delete(view_data_t *view_data)
{
	gps4_data *data = view_data->user_data;

	printf("%s: delete resource\n", __func__);
	if (data)
	{
		if (data->timer) {
			lv_timer_del(data->timer);
			data->timer = NULL;
		}

		for (int i = 0; i < ITEM_NUM; i++)
		{
			lv_style_reset(&data->strs_style[i]);
		}
		lv_style_reset(&data->style_line);
		lv_style_reset(&data->style);
		lv_style_reset(&data->style3);

		for (int i = 0; i < ITEM_NUM; i++)
		{
			lv_obj_del(data->labels[i]);
			/*
			lv_obj_del(data->buttons[i]);
			*/
		}
		/*
		for(int i = 0; i < ITEM_NUM; i++)
		{
			lv_obj_del(data->obj_line[i]);
		}
		*/
		lv_obj_del(data->obj);
		_unload_resource(data);
	printf("%s: 222 delete resource\n", __func__);
		app_mem_free(data);
	}
	else
	{
		lvgl_res_preload_cancel_scene(SCENE_ID);
	}
	lvgl_res_unload_scene_compact(SCENE_ID);


	return 0;
}

void gry_cal(float *inGry, float *outGry)
{
	float newGry[3];

	float Bg[3] = {
		/*
   4.732018678529105,
  -3.067206470257861,
  -2.081606887250609,
  */
   4.136318196332966,
  -3.132622120612850,
  -2.418192437226511,
	};
	float TgKg[3][3] = {
		/*
		{0.001227923799785, -0.000018916496317, -0.000006717888670},
		{0.000014645795682,  0.001227716104703,  0.000000561449165},
		{0.000005889991959,  0.000004496430536,  0.001231052129079},
		*/
		{0.001233251991418, -0.000034419476429, -0.000007664247228},
		{0.000043076138201,  0.001235145125480, -0.000000111605455},
	      {0.000007431931102,  0.000010004784076,  0.001230826976351},
	};

	for (int i = 0; i < 3; i++)
	{
		newGry[i] = inGry[i] + Bg[i];
	}

	for (int i = 0; i < 3; i++)
	{
		outGry[i] = TgKg[i][0] * newGry[0] + TgKg[i][1] * newGry[1] + TgKg[i][2] * newGry[2];
	}

	/*
	for (int i = 0; i < 3; i++)
	{
		outGry[i] = outGry[i] * 70.0f * 0.001f;
	}
	*/
}

void mag_cal(float *inMag, float *outMag)
{
	float newMag[3];

	float Bm[3] = {
		/*
   1.711553223377082 * 100,
   3.769808659536185 * 100,
   3.673913115669258 * 100,
   */
  -3.988630221556102 * 100,
  -0.962128238414130 * 100,
  -3.445037587535898 * 100,
	};

	float Tm2a[3][3] = {
		/*
		{-0.003547632717272, -0.972928620229557, -0.014100186144232},
		{-1.021810558139672,  0.018835986345180,  0.005412027635189},
		{0.024987226917921,  0.017425435903093, -1.000000000000000},
		*/
		{-0.828843503655206,  0.033579122723825, -0.008075804716965},
		{-0.023405793219692, -0.875666103242268,  0.005246670045515},
		{-0.003360441556343,  0.004100982780401, -1.000000000000000},
	};

	for (int i = 0; i < 3; i++)
	{
		newMag[i] = inMag[i] + Bm[i];
	}

	for (int i = 0; i < 3; i++)
	{
		outMag[i] = Tm2a[i][0] * newMag[0] + Tm2a[i][1] * newMag[1] + Tm2a[i][2] * newMag[2];
	}
}


void acc_cal(float *inAcc, float *outAcc)
{
	float newAcc[3];

	float Ba[3] = {
		/*
  -0.738462442734177 * 100,
   1.629429042368612 * 100,
   2.159917802640594 * 100,
   */
  -0.649853356298214 * 100,
   1.558885490106543 * 100,
   1.815836357756680 * 100,
	};

	float TaKa[3][3] = {
		/*
		{0.601914382241354 * 0.001,     -0.005978710502991 * 0.001,     -0.002323623080853* 0.001,    },
		{0 * 0.001,      0.599613490814856 * 0.001,      0.000194581097606* 0.001,    },
		{0 * 0.001,                      0 * 0.001,      0.600600659089508* 0.001,    },
		*/
		{0.599367475148891 * 0.001,  -0.002026576434055 * 0.001,   -0.002130064046712 * 0.001,},  
		{0 * 0.001,    0.598459504307158 * 0.001,    0.000219690686377 * 0.001,  },
		{0 * 0.001,                    0 * 0.001,    0.600560426914725 * 0.001,  },
	};

	for (int i = 0; i < 3; i++)
	{
		newAcc[i] = inAcc[i] + Ba[i];
	}

	for (int i = 0; i < 3; i++)
	{
		outAcc[i] = TaKa[i][0] * newAcc[0] + TaKa[i][1] * newAcc[1] + TaKa[i][2] * newAcc[2];
	}

	/*
	for (int i = 0; i < 3; i++)
	{
		outAcc[i] = outAcc[i] * 0.061f;
	}
	*/
}

static float gry_sum[3] = { 0 };
void imu_get_gry_sum(float *ang, float dt)
{
	for (int i = 0; i < 3; i++)
	{
		gry_sum[i] += ang[i] * dt;
	}
}
void imu_gry_reset(void)
{
	for (int i = 0; i < 3; i++)
	{
		gry_sum[i] = 0;
	}
}
#include <math.h>
static void update_gps_info(char *info, int len)
{
	float oo[3];
	float acc[3];
	float ang[3];
	float mag[3];
extern void get_ahrs(float *oo, float *my_acc, float *my_ang, float *my_mag);
	get_ahrs(oo, acc, ang, mag);
extern int32_t get_iPsi(void);

	float inAcc[3];
	float outAcc[3];
	for (int i = 0; i < 3; i++)
		inAcc[i] = acc[i];
	acc_cal(inAcc, outAcc);
	for (int i = 0; i < 3; i++)
		acc[i] = outAcc[i];

	float inGry[3];
	float outGry[3];
	for (int i = 0; i < 3; i++)
		inGry[i] = ang[i];
	gry_cal(inGry, outGry);
	for (int i = 0; i < 3; i++)
		ang[i] = outGry[i];

	float inMag[3];
	float outMag[3];
	for (int i = 0; i < 3; i++)
		inMag[i] = mag[i];
	mag_cal(inMag, outMag);
	for (int i = 0; i < 3; i++)
		mag[i] = outMag[i];


	snprintf(info, len, "%s: %.2f %.2f %.2f\n"
			"gry: %.2f %.2f %.2f\n"
			"acc: %.2f %.2f %.2f\n"
			"ang: %.2f %.2f %.2f\n"
			"mag: %.2f %.2f %.2f\n"
			"%s %d\n%d %.2f %.2f",
			"OO",
			oo[0] * 180.0f / 3.14159265358979323846f,
			oo[1] * 180.0f / 3.14159265358979323846f,
			oo[2] > 0.0f ? oo[2] * 180.0f / 3.14159265358979323846f : 360.0f + oo[2] * 180.0f / 3.14159265358979323846f,
			gry_sum[0] / 3.14159265358979323846f * 180.0f,
			gry_sum[1] / 3.14159265358979323846f * 180.0f,
			gry_sum[2] / 3.14159265358979323846f * 180.0f,
			acc[0],
			acc[1],
			acc[2],
			ang[0] / 3.14159265358979323846f * 180.0f,
			ang[1] / 3.14159265358979323846f * 180.0f,
			ang[2] / 3.14159265358979323846f * 180.0f,
			mag[0],
			mag[1],
			mag[2],
			start_record ? "recording" : "NULL",
			start_aac_count,
			get_iPsi(), 
			atan2f(acc[1], acc[2]) * 180.0f / 3.14159265358979323846f,
			asinf(-acc[0] / sqrt(acc[1]*acc[1]+acc[2]*acc[2]+acc[0]*acc[0])) * 180.0f / 3.14159265358979323846f
			);
}

static int _gps4_view_paint(view_data_t *view_data)
{
	gps4_data *data = view_data->user_data;
	update_gps_info(data->gps_info, 256);
	lv_label_set_text(data->labels[0], data->gps_info);
	lv_refr_now(view_data->display);
	return 0;
}

static int _gps4_view_handler(uint16_t view_id, uint8_t msg_id, void *msg_data)
{
        view_data_t *view_data = msg_data;

        assert(view_id == VIEW_ID);

        switch (msg_id) {
        case MSG_VIEW_PRELOAD:
                return _gps4_view_preload(view_data);
        case MSG_VIEW_LAYOUT:
imu_gry_reset();
	sys_wake_lock(FULL_WAKE_LOCK);
                return _gps4_view_layout(view_data);
        case MSG_VIEW_DELETE:
	sys_wake_unlock(FULL_WAKE_LOCK);
extern int shell_test_ahrs_quit(const struct shell *shell, size_t argc, char **argv);
shell_test_ahrs_quit(NULL, 0, NULL);
                return _gps4_view_delete(view_data);
	case MSG_VIEW_FOCUS:
		return 0;
	case MSG_VIEW_DEFOCUS:
		return 0;
	case MSG_VIEW_PAINT:
		return _gps4_view_paint(view_data);
        default:
                return 0;
        }
}


VIEW_DEFINE(gps4_view, _gps4_view_handler, NULL, NULL, VIEW_ID, NORMAL_ORDER, UI_VIEW_LVGL,
            DEF_UI_VIEW_WIDTH, DEF_UI_VIEW_HEIGHT);

