
#include <assert.h>
#include <lvgl.h>
#include <lvgl/lvgl_res_loader.h>
#include <lvgl/lvgl_bitmap_font.h>

#include <ui_manager.h>
#include <view_manager.h>
#include "widgets/anim_img.h"
#include "widgets/img_number.h"


#include <res_manager_api.h>
#include "app_ui.h"
#include "app_defines.h"
#include "system_app.h"
#include <view_stack.h>
#include <acts_bluetooth/host_interface.h>

#include <bt_manager.h>
#include "uart2_to_gps.h"
#include <sys_wakelock.h>

static int lcd_test_preload_inited = 0;

static int _lcd_test_view_preload(view_data_t *view_data)
{

	if (lcd_test_preload_inited == 0) {
		lvgl_res_preload_scene_compact_default_init(SCENE_LCD_TEST_VIEW, NULL, 0,
			NULL, DEF_STY_FILE, DEF_RES_FILE, DEF_STR_FILE);
		lcd_test_preload_inited = 1;
	}

	return lvgl_res_preload_scene_compact_default(SCENE_LCD_TEST_VIEW, LCD_TEST_VIEW, 0, 0);
}

//static lv_color_t cbuf[LV_CANVAS_BUF_SIZE_TRUE_COLOR(DEF_UI_WIDTH, DEF_UI_HEIGHT)];
static lv_color_t cbuf[LV_CANVAS_BUF_SIZE_TRUE_COLOR_ALPHA(DEF_UI_WIDTH, DEF_UI_HEIGHT)];
static lv_timer_t *timer;
static int count = 2;
static lv_obj_t *canvas = NULL;

static void timer_ing_update(lv_timer_t *timer)
{
	view_data_t *view_data = timer->user_data;
	lv_draw_rect_dsc_t rect_dsc;
	lv_obj_t *src = NULL;

	src = lv_disp_get_scr_act(view_data->display);
	if (src == NULL)
		return ;

	lv_obj_align(canvas, LV_ALIGN_CENTER, 0, 0);
//	lv_canvas_set_buffer(canvas, cbuf, DEF_UI_WIDTH, DEF_UI_HEIGHT, LV_IMG_CF_TRUE_COLOR);
	lv_canvas_set_buffer(canvas, cbuf, DEF_UI_WIDTH, DEF_UI_HEIGHT, LV_IMG_CF_TRUE_COLOR_ALPHA);
	lv_draw_rect_dsc_init(&rect_dsc);
	rect_dsc.bg_opa = LV_OPA_COVER;
	count++;
	if (count % 3 == 0)
		rect_dsc.bg_color = lv_palette_main(LV_PALETTE_RED);
	else if (count % 4 == 0)
		rect_dsc.bg_color = lv_palette_main(LV_PALETTE_GREEN);
	else if (count % 5 == 0)
		rect_dsc.bg_color = lv_palette_main(LV_PALETTE_BLUE);
	if (count % 5 == 0)
		count = 2;
	lv_canvas_draw_rect(canvas, 0, 0, 240, 320, &rect_dsc);

	SYS_LOG_INF("%s: bat cap: %d\n", __func__, power_manager_get_battery_capacity());
}

static int create_view(view_data_t *view_data)
{
	lv_draw_rect_dsc_t rect_dsc;
	lv_obj_t *src = NULL;

	src = lv_disp_get_scr_act(view_data->display);
	if (src == NULL)
		return -1;

	canvas = lv_canvas_create(src);
	lv_obj_align(canvas, LV_ALIGN_CENTER, 0, 0);
//	lv_canvas_set_buffer(canvas, cbuf, DEF_UI_WIDTH, DEF_UI_HEIGHT, LV_IMG_CF_TRUE_COLOR);
	lv_canvas_set_buffer(canvas, cbuf, DEF_UI_WIDTH, DEF_UI_HEIGHT, LV_IMG_CF_TRUE_COLOR_ALPHA);
	lv_draw_rect_dsc_init(&rect_dsc);
	rect_dsc.bg_opa = LV_OPA_COVER;
	rect_dsc.bg_color = lv_palette_main(LV_PALETTE_RED);
	lv_canvas_draw_rect(canvas, 0, 0, 240, 320, &rect_dsc);
	timer = lv_timer_create(timer_ing_update, 1000, view_data);
	if (timer)
		lv_timer_ready(timer);
	return 0;
}

static int _lcd_test_view_layout(view_data_t *view_data)
{
	/*
	private_data = app_mem_malloc(sizeof(*private_data));
	if (private_data == NULL) return -1;

	memset(private_data, 0, sizeof(*private_data));

	view_data->user_data = private_data;
	load_resource(view_data);
	create_view(view_data);
	*/
	create_view(view_data);
	lv_refr_now(view_data->display);
	return 0;
}

static int _lcd_test_view_delete(view_data_t *view_data)
{
	/*
//	lvgl_res_preload_cancel_scene(SCENE_LCD_TEST_VIEW);
	unload_resource(view_data);
	destroy_view(view_data);

	app_mem_free(private_data);
	private_data = NULL;
	*/

	if (timer) 
	{
		lv_timer_del(timer);
		timer = NULL;
	}
	lv_obj_del(canvas);
	canvas = NULL;
	lvgl_res_unload_scene_compact(SCENE_LCD_TEST_VIEW);
	return 0;
}

int lcd_test_view_handler(uint16_t view_id, uint8_t msg_id, void *msg_data)
{
	int ret = 0;
	view_data_t *view_data = msg_data;

	SYS_LOG_INF("%s: %d %d\n", __func__, view_id, LCD_TEST_VIEW);
	assert(view_id == LCD_TEST_VIEW);

	switch (msg_id) {
	case MSG_VIEW_PRELOAD:
		ret = _lcd_test_view_preload(view_data);
		break;
	case MSG_VIEW_LAYOUT:
		ret = _lcd_test_view_layout(view_data);
		break;
	case MSG_VIEW_DELETE:
		ret = _lcd_test_view_delete(view_data);
		break;
//	case MSG_VIEW_UPDATE:
		break;
	default:
		break;
	}
	return ret;
}

VIEW_DEFINE(lcd_test_view, lcd_test_view_handler, NULL,
		NULL, LCD_TEST_VIEW, NORMAL_ORDER, UI_VIEW_LVGL, DEF_UI_VIEW_WIDTH, DEF_UI_VIEW_HEIGHT);


