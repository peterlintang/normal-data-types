# ellipsoid

Ellipsoid fit based magnetometer calibration.

## References

1. Li - Least Square Ellipsoid Fitting (2004)
2. Pedley, Stanley - Magnetic Calibration: Technical Note (2014)
3. Ozyagcilar - Calibrating an eCompass in the Presence of Hard and Soft-iron Interference (1992)
