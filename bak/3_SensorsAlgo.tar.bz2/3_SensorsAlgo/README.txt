
nineAxisfusion.h	exported header file
demo.c			example of usage
