
nineAxisfusion.h	exported header file
demo.c			example of usage

need to implemente
extern void lsm6dsv_read_gry_data(float *gry); unit: mdegree per second
extern void lsm6dsv_read_acc_data(float *acc); unit: mg
extern void MMC5983_GetData(float *mag_out); unit: Gauss 
extern void MMC5983_Disable(void);
extern void mmc5983_init(void);
extern void lsm6dsv_init(void);
extern void lsm6dsv_deinit(void);
