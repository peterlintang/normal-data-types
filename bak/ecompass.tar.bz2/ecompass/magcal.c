

#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "magcal.h"
#include "mem_manager.h"

void binary_expand_op(emxArray_real32_T *in1, const emxArray_real32_T *in3,
                      const emxArray_real32_T *in4,
                      const emxArray_real32_T *in5)
{
  const float *in3_data;
  const float *in4_data;
  const float *in5_data;
  float *in1_data;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  int stride_2_0;
  in5_data = in5->data;
  in4_data = in4->data;
  in3_data = in3->data;
  if (in5->size[0] == 1) {
    if (in4->size[0] == 1) {
      loop_ub = in3->size[0];
    } else {
      loop_ub = in4->size[0];
    }
  } else {
    loop_ub = in5->size[0];
  }
  i = in1->size[0];
  in1->size[0] = loop_ub;
  emxEnsureCapacity_real32_T(in1, i);
  in1_data = in1->data;
  stride_0_0 = (in3->size[0] != 1);
  stride_1_0 = (in4->size[0] != 1);
  stride_2_0 = (in5->size[0] != 1);
  for (i = 0; i < loop_ub; i++) {
    float b_varargin_1;
    float c_varargin_1;
    float varargin_1;
    varargin_1 = in3_data[i * stride_0_0];
    b_varargin_1 = in4_data[i * stride_1_0];
    c_varargin_1 = in5_data[i * stride_2_0];
    in1_data[i] = (varargin_1 * varargin_1 + b_varargin_1 * b_varargin_1) +
                  c_varargin_1 * c_varargin_1;
  }
}



real_T rtGetInf(void)
{
  return rtInf;
}

real32_T rtGetInfF(void)
{
  return rtInfF;
}

real_T rtGetMinusInf(void)
{
  return rtMinusInf;
}

real32_T rtGetMinusInfF(void)
{
  return rtMinusInfF;
}

real_T rtGetNaN(void)
{
  return rtNaN;
}

real32_T rtGetNaNF(void)
{
  return rtNaNF;
}


#if defined(__ICL) && __ICL == 1700
#pragma warning(disable : 264)
#endif

real_T rtNaN = (real_T)NAN;
real_T rtInf = (real_T)INFINITY;
real_T rtMinusInf = -(real_T)INFINITY;
real32_T rtNaNF = (real32_T)NAN;
real32_T rtInfF = (real32_T)INFINITY;
real32_T rtMinusInfF = -(real32_T)INFINITY;

#if defined(__ICL) && __ICL == 1700
#pragma warning(default : 264)
#endif

boolean_T rtIsInf(real_T value)
{
  return (isinf(value) != 0U);
}

boolean_T rtIsInfF(real32_T value)
{
  return (isinf((real_T)value) != 0U);
}

boolean_T rtIsNaN(real_T value)
{
  return (isnan(value) != 0U);
}

boolean_T rtIsNaNF(real32_T value)
{
  return (isnan((real_T)value) != 0U);
}

void b_sqrt(creal32_T *x)
{
  float absxi;
  float absxr;
  float xi;
  float xr;
  xr = x->re;
  xi = x->im;
  if (xi == 0.0F) {
    if (xr < 0.0F) {
      absxr = 0.0F;
      absxi = sqrtf(-xr);
    } else {
      absxr = sqrtf(xr);
      absxi = 0.0F;
    }
  } else if (xr == 0.0F) {
    if (xi < 0.0F) {
      absxr = sqrtf(-xi / 2.0F);
      absxi = -absxr;
    } else {
      absxr = sqrtf(xi / 2.0F);
      absxi = absxr;
    }
  } else if (rtIsNaNF(xr)) {
    absxr = rtNaNF;
    absxi = rtNaNF;
  } else if (rtIsNaNF(xi)) {
    absxr = rtNaNF;
    absxi = rtNaNF;
  } else if (rtIsInfF(xi)) {
    absxr = fabsf(xi);
    absxi = xi;
  } else if (rtIsInfF(xr)) {
    if (xr < 0.0F) {
      absxr = 0.0F;
      absxi = xi * -xr;
    } else {
      absxr = xr;
      absxi = 0.0F;
    }
  } else {
    absxr = fabsf(xr);
    absxi = fabsf(xi);
    if ((absxr > 8.50705867E+37F) || (absxi > 8.50705867E+37F)) {
      absxr *= 0.5F;
      absxi = rt_hypotf_snf(absxr, absxi * 0.5F);
      if (absxi > absxr) {
        absxr = sqrtf(absxi) * sqrtf(absxr / absxi + 1.0F);
      } else {
        absxr = sqrtf(absxi) * 1.41421354F;
      }
    } else {
      absxr = sqrtf((rt_hypotf_snf(absxr, absxi) + absxr) * 0.5F);
    }
    if (xr > 0.0F) {
      absxi = 0.5F * (xi / absxr);
    } else {
      if (xi < 0.0F) {
        absxi = -absxr;
      } else {
        absxi = absxr;
      }
      absxr = 0.5F * (xi / absxi);
    }
  }
  x->re = absxr;
  x->im = absxi;
}

void c_sqrt(const float A[9], creal32_T X[9])
{
  creal32_T R[9];
  creal32_T T[9];
  creal32_T U[9];
  float b_A[9];
  float U_re_tmp;
  float c;
  float cs;
  float d;
  float d_tmp;
  float mu1_im;
  float mu1_re;
  float r;
  float re;
  float rt1i;
  float s;
  float sn;
  float t1_im;
  int b_i;
  int exitg1;
  int i;
  int ia;
  int iaii;
  int j;
  int lastc;
  int lastv;
  bool exitg3;
  bool p;
  p = true;
  for (ia = 0; ia < 9; ia++) {
    if (p) {
      U_re_tmp = A[ia];
      if (rtIsInfF(U_re_tmp) || rtIsNaNF(U_re_tmp)) {
        p = false;
      }
    } else {
      p = false;
    }
  }
  if (!p) {
    for (i = 0; i < 9; i++) {
      U[i].re = rtNaNF;
      U[i].im = 0.0F;
    }
    U[2].re = 0.0F;
    U[2].im = 0.0F;
    for (i = 0; i < 9; i++) {
      T[i].re = rtNaNF;
      T[i].im = 0.0F;
    }
  } else {
    float Vr[9];
    float work[3];
    float tau[2];
    for (i = 0; i < 9; i++) {
      b_A[i] = A[i];
    }
    xgehrd(b_A, tau);
    for (i = 0; i < 9; i++) {
      Vr[i] = b_A[i];
    }
    for (j = 1; j >= 0; j--) {
      ia = (j + 1) * 3;
      for (b_i = 0; b_i <= j; b_i++) {
        Vr[ia + b_i] = 0.0F;
      }
      i = j + 3;
      for (b_i = i; b_i < 4; b_i++) {
        Vr[ia + 2] = Vr[ia - 1];
      }
    }
    Vr[1] = 0.0F;
    Vr[2] = 0.0F;
    Vr[0] = 1.0F;
    work[0] = 0.0F;
    work[1] = 0.0F;
    work[2] = 0.0F;
    for (b_i = 1; b_i >= 0; b_i--) {
      iaii = (b_i + b_i * 3) + 5;
      if (b_i + 1 < 2) {
        Vr[iaii - 1] = 1.0F;
        if (tau[b_i] != 0.0F) {
          lastv = 2;
          lastc = iaii;
          while ((lastv > 0) && (Vr[lastc] == 0.0F)) {
            lastv--;
            lastc--;
          }
          lastc = 1;
          ia = iaii + 3;
          do {
            exitg1 = 0;
            if (ia <= (iaii + lastv) + 2) {
              if (Vr[ia - 1] != 0.0F) {
                exitg1 = 1;
              } else {
                ia++;
              }
            } else {
              lastc = 0;
              exitg1 = 1;
            }
          } while (exitg1 == 0);
        } else {
          lastv = 0;
          lastc = 0;
        }
        if (lastv > 0) {
          xgemv(lastv, lastc, Vr, iaii + 3, Vr, iaii, work);
          xgerc(lastv, lastc, -tau[b_i], iaii, work, Vr, iaii + 3);
        }
        lastv = iaii + 1;
        for (ia = lastv; ia <= lastv; ia++) {
          Vr[ia - 1] *= -tau[b_i];
        }
      }
      Vr[iaii - 1] = 1.0F - tau[b_i];
      if (b_i - 1 >= 0) {
        Vr[iaii - 2] = 0.0F;
      }
    }
    xhseqr(b_A, Vr);
    for (i = 0; i < 9; i++) {
      T[i].re = b_A[i];
      T[i].im = 0.0F;
      U[i].re = Vr[i];
      U[i].im = 0.0F;
    }
    for (iaii = 1; iaii >= 0; iaii--) {
      lastv = iaii + 1;
      i = iaii + 3 * iaii;
      U_re_tmp = b_A[i + 1];
      if (U_re_tmp != 0.0F) {
        r = b_A[i];
        ia = 3 * (iaii + 1);
        lastc = iaii + ia;
        t1_im = b_A[lastc];
        c = U_re_tmp;
        d_tmp = b_A[lastc + 1];
        d = d_tmp;
        mu1_re = xdlanv2(&r, &t1_im, &c, &d, &rt1i, &mu1_im, &s, &cs, &sn);
        mu1_re -= d_tmp;
        r = rt_hypotf_snf(rt_hypotf_snf(mu1_re, rt1i), U_re_tmp);
        if (rt1i == 0.0F) {
          re = mu1_re / r;
          sn = 0.0F;
        } else if (mu1_re == 0.0F) {
          re = 0.0F;
          sn = rt1i / r;
        } else {
          re = mu1_re / r;
          sn = rt1i / r;
        }
        s = U_re_tmp / r;
        for (j = lastv; j < 4; j++) {
          lastc = iaii + 3 * (j - 1);
          r = T[lastc].re;
          t1_im = T[lastc].im;
          c = T[lastc + 1].re;
          d_tmp = T[lastc + 1].im;
          T[lastc].re = (re * r + sn * t1_im) + s * c;
          T[lastc].im = (re * t1_im - sn * r) + s * d_tmp;
          mu1_re = re * c - sn * d_tmp;
          mu1_im = re * d_tmp + sn * c;
          T[lastc + 1].re = mu1_re - s * r;
          T[lastc + 1].im = mu1_im - s * t1_im;
        }
        for (b_i = 0; b_i <= iaii + 1; b_i++) {
          lastc = b_i + 3 * iaii;
          r = T[lastc].re;
          t1_im = T[lastc].im;
          lastv = b_i + ia;
          c = T[lastv].re;
          d_tmp = T[lastv].im;
          mu1_re = re * r - sn * t1_im;
          mu1_im = re * t1_im + sn * r;
          T[lastc].re = mu1_re + s * c;
          T[lastc].im = mu1_im + s * d_tmp;
          T[lastv].re = (re * c + sn * d_tmp) - s * r;
          T[lastv].im = (re * d_tmp - sn * c) - s * t1_im;
        }
        r = U[3 * iaii].re;
        t1_im = U[3 * iaii].im;
        c = U[ia].re;
        d_tmp = U[ia].im;
        mu1_re = re * r - sn * t1_im;
        mu1_im = re * t1_im + sn * r;
        U[3 * iaii].re = mu1_re + s * c;
        U[3 * iaii].im = mu1_im + s * d_tmp;
        U[ia].re = (re * c + sn * d_tmp) - s * r;
        U[ia].im = (re * d_tmp - sn * c) - s * t1_im;
        lastc = 3 * iaii + 1;
        r = U[lastc].re;
        t1_im = U[lastc].im;
        c = U[ia + 1].re;
        d_tmp = U[ia + 1].im;
        mu1_re = re * r - sn * t1_im;
        mu1_im = re * t1_im + sn * r;
        U[lastc].re = mu1_re + s * c;
        U[lastc].im = mu1_im + s * d_tmp;
        U[ia + 1].re = (re * c + sn * d_tmp) - s * r;
        U[ia + 1].im = (re * d_tmp - sn * c) - s * t1_im;
        lastc = 3 * iaii + 2;
        r = U[lastc].re;
        t1_im = U[lastc].im;
        c = U[ia + 2].re;
        d_tmp = U[ia + 2].im;
        mu1_re = re * r - sn * t1_im;
        mu1_im = re * t1_im + sn * r;
        U[lastc].re = mu1_re + s * c;
        U[lastc].im = mu1_im + s * d_tmp;
        U[ia + 2].re = (re * c + sn * d_tmp) - s * r;
        U[ia + 2].im = (re * d_tmp - sn * c) - s * t1_im;
        T[(iaii + 3 * iaii) + 1].re = 0.0F;
        T[(iaii + 3 * iaii) + 1].im = 0.0F;
      }
    }
  }
  j = -1;
  int exitg2;
  do {
    exitg2 = 0;
    if (j + 1 < 3) {
      b_i = 0;
      do {
        exitg1 = 0;
        if (b_i <= j) {
          lastc = b_i + 3 * (j + 1);
          if ((T[lastc].re != 0.0F) || (T[lastc].im != 0.0F)) {
            memset(&R[0], 0, 9U * sizeof(creal32_T));
            for (j = 0; j < 3; j++) {
              iaii = j + 3 * j;
              R[iaii] = T[iaii];
              b_sqrt(&R[iaii]);
              for (b_i = j; b_i >= 1; b_i--) {
                mu1_re = 0.0F;
                mu1_im = 0.0F;
                i = b_i + 1;
                for (ia = i; ia <= j; ia++) {
                  t1_im = R[b_i + 2].re;
                  lastc = 3 * j + 1;
                  r = R[lastc].im;
                  c = R[b_i + 2].im;
                  d_tmp = R[lastc].re;
                  mu1_re += t1_im * d_tmp - c * r;
                  mu1_im += t1_im * r + c * d_tmp;
                }
                lastv = (b_i + 3 * j) - 1;
                mu1_re = T[lastv].re - mu1_re;
                cs = T[lastv].im - mu1_im;
                lastc = (b_i + 3 * (b_i - 1)) - 1;
                t1_im = R[lastc].re + R[iaii].re;
                c = R[lastc].im + R[iaii].im;
                if (c == 0.0F) {
                  if (cs == 0.0F) {
                    re = mu1_re / t1_im;
                    sn = 0.0F;
                  } else if (mu1_re == 0.0F) {
                    re = 0.0F;
                    sn = cs / t1_im;
                  } else {
                    re = mu1_re / t1_im;
                    sn = cs / t1_im;
                  }
                } else if (t1_im == 0.0F) {
                  if (mu1_re == 0.0F) {
                    re = cs / c;
                    sn = 0.0F;
                  } else if (cs == 0.0F) {
                    re = 0.0F;
                    sn = -(mu1_re / c);
                  } else {
                    re = cs / c;
                    sn = -(mu1_re / c);
                  }
                } else {
                  d_tmp = fabsf(t1_im);
                  r = fabsf(c);
                  if (d_tmp > r) {
                    s = c / t1_im;
                    d = t1_im + s * c;
                    re = (mu1_re + s * cs) / d;
                    sn = (cs - s * mu1_re) / d;
                  } else if (r == d_tmp) {
                    if (t1_im > 0.0F) {
                      t1_im = 0.5F;
                    } else {
                      t1_im = -0.5F;
                    }
                    if (c > 0.0F) {
                      r = 0.5F;
                    } else {
                      r = -0.5F;
                    }
                    re = (mu1_re * t1_im + cs * r) / d_tmp;
                    sn = (cs * t1_im - mu1_re * r) / d_tmp;
                  } else {
                    s = t1_im / c;
                    d = c + s * t1_im;
                    re = (s * mu1_re + cs) / d;
                    sn = (s * cs - mu1_re) / d;
                  }
                }
                R[lastv].re = re;
                R[lastv].im = sn;
              }
            }
            exitg1 = 1;
          } else {
            b_i++;
          }
        } else {
          j++;
          exitg1 = 2;
        }
      } while (exitg1 == 0);
      if (exitg1 == 1) {
        exitg2 = 1;
      }
    } else {
      memset(&R[0], 0, 9U * sizeof(creal32_T));
      R[0] = T[0];
      b_sqrt(&R[0]);
      R[4] = T[4];
      b_sqrt(&R[4]);
      R[8] = T[8];
      b_sqrt(&R[8]);
      exitg2 = 1;
    }
  } while (exitg2 == 0);
  for (i = 0; i < 3; i++) {
    r = U[i].re;
    t1_im = U[i].im;
    c = U[i + 3].re;
    d_tmp = U[i + 3].im;
    mu1_re = U[i + 6].re;
    mu1_im = U[i + 6].im;
    for (lastv = 0; lastv < 3; lastv++) {
      s = R[3 * lastv].im;
      cs = R[3 * lastv].re;
      lastc = 3 * lastv + 1;
      sn = R[lastc].im;
      rt1i = R[lastc].re;
      lastc = 3 * lastv + 2;
      U_re_tmp = R[lastc].im;
      d = R[lastc].re;
      lastc = i + 3 * lastv;
      T[lastc].re = ((r * cs - t1_im * s) + (c * rt1i - d_tmp * sn)) +
                    (mu1_re * d - mu1_im * U_re_tmp);
      T[lastc].im = ((r * s + t1_im * cs) + (c * sn + d_tmp * rt1i)) +
                    (mu1_re * U_re_tmp + mu1_im * d);
    }
    c = T[i].re;
    d_tmp = T[i].im;
    cs = T[i + 3].re;
    mu1_re = T[i + 3].im;
    mu1_im = T[i + 6].re;
    s = T[i + 6].im;
    for (lastv = 0; lastv < 3; lastv++) {
      r = U[lastv].re;
      t1_im = -U[lastv].im;
      re = c * r - d_tmp * t1_im;
      sn = c * t1_im + d_tmp * r;
      r = U[lastv + 3].re;
      t1_im = -U[lastv + 3].im;
      re += cs * r - mu1_re * t1_im;
      sn += cs * t1_im + mu1_re * r;
      r = U[lastv + 6].re;
      t1_im = -U[lastv + 6].im;
      re += mu1_im * r - s * t1_im;
      sn += mu1_im * t1_im + s * r;
      lastc = i + 3 * lastv;
      X[lastc].re = re;
      X[lastc].im = sn;
    }
  }
  for (i = 0; i < 9; i++) {
    b_A[i] = X[i].im;
  }
  r = 0.0F;
  j = 0;
  exitg3 = false;
  while ((!exitg3) && (j < 3)) {
    s = (fabsf(b_A[3 * j]) + fabsf(b_A[3 * j + 1])) + fabsf(b_A[3 * j + 2]);
    if (rtIsNaNF(s)) {
      r = rtNaNF;
      exitg3 = true;
    } else {
      if (s > r) {
        r = s;
      }
      j++;
    }
  }
  t1_im = 0.0F;
  j = 0;
  exitg3 = false;
  while ((!exitg3) && (j < 3)) {
    lastc = 3 * j + 1;
    lastv = 3 * j + 2;
    s = (rt_hypotf_snf(X[3 * j].re, X[3 * j].im) +
         rt_hypotf_snf(X[lastc].re, X[lastc].im)) +
        rt_hypotf_snf(X[lastv].re, X[lastv].im);
    if (rtIsNaNF(s)) {
      t1_im = rtNaNF;
      exitg3 = true;
    } else {
      if (s > t1_im) {
        t1_im = s;
      }
      j++;
    }
  }
  if (r <= 6.66133815E-15F * t1_im) {
    for (j = 0; j < 3; j++) {
      X[3 * j].im = 0.0F;
      X[3 * j + 1].im = 0.0F;
      X[3 * j + 2].im = 0.0F;
    }
  }
}

emxArray_real32_T *emxCreateND_real32_T(int numDimensions, const int *size)
{
  emxArray_real32_T *emx;
  int i;
  int numEl;
  emxInit_real32_T(&emx, numDimensions);
  numEl = 1;
  for (i = 0; i < numDimensions; i++) {
    numEl *= size[i];
    emx->size[i] = size[i];
  }
  emx->data = (float *)app_mem_malloc((unsigned int)numEl * sizeof(float));
  emx->numDimensions = numDimensions;
  emx->allocatedSize = numEl;
  return emx;
}

emxArray_real32_T *emxCreateWrapperND_real32_T(float *data, int numDimensions,
                                               const int *size)
{
  emxArray_real32_T *emx;
  int i;
  int numEl;
  emxInit_real32_T(&emx, numDimensions);
  numEl = 1;
  for (i = 0; i < numDimensions; i++) {
    numEl *= size[i];
    emx->size[i] = size[i];
  }
  emx->data = data;
  emx->numDimensions = numDimensions;
  emx->allocatedSize = numEl;
  emx->canFreeData = false;
  return emx;
}

emxArray_real32_T *emxCreateWrapper_real32_T(float *data, int rows, int cols)
{
  emxArray_real32_T *emx;
  emxInit_real32_T(&emx, 2);
  emx->size[0] = rows;
  emx->size[1] = cols;
  emx->data = data;
  emx->numDimensions = 2;
  emx->allocatedSize = rows * cols;
  emx->canFreeData = false;
  return emx;
}

emxArray_real32_T *emxCreate_real32_T(int rows, int cols)
{
  emxArray_real32_T *emx;
  int numEl;
  emxInit_real32_T(&emx, 2);
  emx->size[0] = rows;
  numEl = rows * cols;
  emx->size[1] = cols;
  emx->data = (float *)app_mem_malloc((unsigned int)numEl * sizeof(float));
  emx->numDimensions = 2;
  emx->allocatedSize = numEl;
  return emx;
}

void emxDestroyArray_real32_T(emxArray_real32_T *emxArray)
{
  emxFree_real32_T(&emxArray);
}

void emxInitArray_real32_T(emxArray_real32_T **pEmxArray, int numDimensions)
{
  emxInit_real32_T(pEmxArray, numDimensions);
}


void emxEnsureCapacity_real32_T(emxArray_real32_T *emxArray, int oldNumel)
{
  int i;
  int newNumel;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }
  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }
  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }
    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i *= 2;
      }
    }
    newData = app_mem_malloc((unsigned int)i * sizeof(float));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(float) * (unsigned int)oldNumel);
      if (emxArray->canFreeData) {
        app_mem_free(emxArray->data);
      }
    }
    emxArray->data = (float *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

void emxFree_real32_T(emxArray_real32_T **pEmxArray)
{
  if (*pEmxArray != (emxArray_real32_T *)NULL) {
    if (((*pEmxArray)->data != (float *)NULL) && (*pEmxArray)->canFreeData) {
      app_mem_free((*pEmxArray)->data);
    }
    app_mem_free((*pEmxArray)->size);
    app_mem_free(*pEmxArray);
    *pEmxArray = (emxArray_real32_T *)NULL;
  }
}

void emxInit_real32_T(emxArray_real32_T **pEmxArray, int numDimensions)
{
  emxArray_real32_T *emxArray;
  int i;
  *pEmxArray = (emxArray_real32_T *)app_mem_malloc(sizeof(emxArray_real32_T));
  emxArray = *pEmxArray;
  emxArray->data = (float *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int *)app_mem_malloc(sizeof(int) * (unsigned int)numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

float rt_hypotf_snf(float u0, float u1)
{
  float a;
  float b;
  float y;
  a = fabsf(u0);
  b = fabsf(u1);
  if (a < b) {
    a /= b;
    y = b * sqrtf(a * a + 1.0F);
  } else if (a > b) {
    b /= a;
    y = a * sqrtf(b * b + 1.0F);
  } else if (rtIsNaNF(b)) {
    y = rtNaNF;
  } else {
    y = a * 1.41421354F;
  }
  return y;
}

float xdlanv2(float *a, float *b, float *c, float *d, float *rt1i, float *rt2r,
              float *rt2i, float *cs, float *sn)
{
  float rt1r;
  if (*c == 0.0F) {
    *cs = 1.0F;
    *sn = 0.0F;
  } else if (*b == 0.0F) {
    float temp;
    *cs = 0.0F;
    *sn = 1.0F;
    temp = *d;
    *d = *a;
    *a = temp;
    *b = -*c;
    *c = 0.0F;
  } else {
    float temp;
    temp = *a - *d;
    if ((temp == 0.0F) && ((*b < 0.0F) != (*c < 0.0F))) {
      *cs = 1.0F;
      *sn = 0.0F;
    } else {
      float bcmax;
      float bcmis;
      float p;
      float scale;
      float z;
      int count;
      int i;
      p = 0.5F * temp;
      bcmis = fabsf(*b);
      scale = fabsf(*c);
      bcmax = fmaxf(bcmis, scale);
      if (!(*b < 0.0F)) {
        count = 1;
      } else {
        count = -1;
      }
      if (!(*c < 0.0F)) {
        i = 1;
      } else {
        i = -1;
      }
      bcmis = fminf(bcmis, scale) * (float)count * (float)i;
      scale = fmaxf(fabsf(p), bcmax);
      z = p / scale * p + bcmax / scale * bcmis;
      if (z >= 4.76837158E-7F) {
        float tau;
        *a = sqrtf(scale) * sqrtf(z);
        if (p < 0.0F) {
          *a = -*a;
        }
        z = p + *a;
        *a = *d + z;
        *d -= bcmax / z * bcmis;
        tau = rt_hypotf_snf(*c, z);
        *cs = z / tau;
        *sn = *c / tau;
        *b -= *c;
        *c = 0.0F;
      } else {
        float tau;
        bcmis = *b + *c;
        scale = fmaxf(fabsf(temp), fabsf(bcmis));
        count = 0;
        while ((scale >= 5.49755814E+11F) && (count <= 20)) {
          bcmis *= 1.8189894E-12F;
          temp *= 1.8189894E-12F;
          scale = fmaxf(fabsf(temp), fabsf(bcmis));
          count++;
        }
        while ((scale <= 1.8189894E-12F) && (count <= 20)) {
          bcmis *= 5.49755814E+11F;
          temp *= 5.49755814E+11F;
          scale = fmaxf(fabsf(temp), fabsf(bcmis));
          count++;
        }
        tau = rt_hypotf_snf(bcmis, temp);
        *cs = sqrtf(0.5F * (fabsf(bcmis) / tau + 1.0F));
        if (!(bcmis < 0.0F)) {
          count = 1;
        } else {
          count = -1;
        }
        *sn = -(0.5F * temp / (tau * *cs)) * (float)count;
        bcmax = *a * *cs + *b * *sn;
        scale = -*a * *sn + *b * *cs;
        z = *c * *cs + *d * *sn;
        bcmis = -*c * *sn + *d * *cs;
        *b = scale * *cs + bcmis * *sn;
        *c = -bcmax * *sn + z * *cs;
        temp = 0.5F * ((bcmax * *cs + z * *sn) + (-scale * *sn + bcmis * *cs));
        *a = temp;
        *d = temp;
        if (*c != 0.0F) {
          if (*b != 0.0F) {
            if ((*b < 0.0F) == (*c < 0.0F)) {
              bcmis = sqrtf(fabsf(*b));
              scale = sqrtf(fabsf(*c));
              *a = bcmis * scale;
              if (!(*c < 0.0F)) {
                p = *a;
              } else {
                p = -*a;
              }
              tau = 1.0F / sqrtf(fabsf(*b + *c));
              *a = temp + p;
              *d = temp - p;
              *b -= *c;
              *c = 0.0F;
              bcmax = bcmis * tau;
              bcmis = scale * tau;
              temp = *cs * bcmax - *sn * bcmis;
              *sn = *cs * bcmis + *sn * bcmax;
              *cs = temp;
            }
          } else {
            *b = -*c;
            *c = 0.0F;
            temp = *cs;
            *cs = -*sn;
            *sn = temp;
          }
        }
      }
    }
  }
  rt1r = *a;
  *rt2r = *d;
  if (*c == 0.0F) {
    *rt1i = 0.0F;
    *rt2i = 0.0F;
  } else {
    *rt1i = sqrtf(fabsf(*b)) * sqrtf(fabsf(*c));
    *rt2i = -*rt1i;
  }
  return rt1r;
}

void xgehrd(float a[9], float tau[2])
{
  float work[3];
  int i;
  int ia;
  int ix0;
  int k;
  int knt;
  work[0] = 0.0F;
  work[1] = 0.0F;
  work[2] = 0.0F;
  for (i = 0; i < 2; i++) {
    float alpha1_tmp;
    float xnorm;
    int alpha1_tmp_tmp;
    int b_i;
    int c_i;
    int exitg1;
    int in;
    int iv0_tmp;
    int lastc;
    int lastv;
    bool exitg2;
    b_i = i * 3 + 2;
    in = (i + 1) * 3;
    alpha1_tmp_tmp = (i + 3 * i) + 1;
    alpha1_tmp = a[alpha1_tmp_tmp];
    ix0 = b_i + 1;
    tau[i] = 0.0F;
    xnorm = 0.0F;
    if (1 - i >= 1) {
      xnorm = fabsf(a[b_i]);
    }
    if (xnorm != 0.0F) {
      float beta1;
      beta1 = rt_hypotf_snf(alpha1_tmp, xnorm);
      if (alpha1_tmp >= 0.0F) {
        beta1 = -beta1;
      }
      if (fabsf(beta1) < 9.86076132E-32F) {
        knt = 0;
        c_i = (b_i - i) + 1;
        do {
          knt++;
          for (k = ix0; k <= c_i; k++) {
            a[k - 1] *= 1.01412048E+31F;
          }
          beta1 *= 1.01412048E+31F;
          alpha1_tmp *= 1.01412048E+31F;
        } while ((fabsf(beta1) < 9.86076132E-32F) && (knt < 20));
        xnorm = 0.0F;
        if (1 - i >= 1) {
          xnorm = fabsf(a[b_i]);
        }
        beta1 = rt_hypotf_snf(alpha1_tmp, xnorm);
        if (alpha1_tmp >= 0.0F) {
          beta1 = -beta1;
        }
        tau[i] = (beta1 - alpha1_tmp) / beta1;
        xnorm = 1.0F / (alpha1_tmp - beta1);
        for (k = ix0; k <= c_i; k++) {
          a[k - 1] *= xnorm;
        }
        for (k = 0; k < knt; k++) {
          beta1 *= 9.86076132E-32F;
        }
        alpha1_tmp = beta1;
      } else {
        tau[i] = (beta1 - alpha1_tmp) / beta1;
        xnorm = 1.0F / (alpha1_tmp - beta1);
        c_i = (b_i - i) + 1;
        for (k = ix0; k <= c_i; k++) {
          a[k - 1] *= xnorm;
        }
        alpha1_tmp = beta1;
      }
    }
    a[alpha1_tmp_tmp] = 1.0F;
    iv0_tmp = i + b_i;
    k = in + 1;
    if (tau[i] != 0.0F) {
      lastv = 1 - i;
      b_i = iv0_tmp - i;
      while ((lastv + 1 > 0) && (a[b_i] == 0.0F)) {
        lastv--;
        b_i--;
      }
      lastc = 3;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        b_i = in + lastc;
        ia = b_i;
        do {
          exitg1 = 0;
          if (ia <= b_i + lastv * 3) {
            if (a[ia - 1] != 0.0F) {
              exitg1 = 1;
            } else {
              ia += 3;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    } else {
      lastv = -1;
      lastc = 0;
    }
    if (lastv + 1 > 0) {
      int i1;
      if (lastc != 0) {
        memset(&work[0], 0, (unsigned int)lastc * sizeof(float));
        b_i = iv0_tmp - 1;
        c_i = (in + 3 * lastv) + 1;
        for (knt = k; knt <= c_i; knt += 3) {
          i1 = (knt + lastc) - 1;
          for (ia = knt; ia <= i1; ia++) {
            ix0 = ia - knt;
            work[ix0] += a[ia - 1] * a[b_i];
          }
          b_i++;
        }
      }
      if (!(-tau[i] == 0.0F)) {
        b_i = in;
        for (ix0 = 0; ix0 <= lastv; ix0++) {
          xnorm = a[(iv0_tmp + ix0) - 1];
          if (xnorm != 0.0F) {
            xnorm *= -tau[i];
            c_i = b_i + 1;
            i1 = lastc + b_i;
            for (knt = c_i; knt <= i1; knt++) {
              a[knt - 1] += work[(knt - b_i) - 1] * xnorm;
            }
          }
          b_i += 3;
        }
      }
    }
    k = (i + in) + 2;
    if (tau[i] != 0.0F) {
      lastv = 2 - i;
      b_i = iv0_tmp - i;
      while ((lastv > 0) && (a[b_i] == 0.0F)) {
        lastv--;
        b_i--;
      }
      lastc = 2 - i;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        b_i = k + (lastc - 1) * 3;
        ia = b_i;
        do {
          exitg1 = 0;
          if (ia <= (b_i + lastv) - 1) {
            if (a[ia - 1] != 0.0F) {
              exitg1 = 1;
            } else {
              ia++;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    } else {
      lastv = 0;
      lastc = 0;
    }
    if (lastv > 0) {
      xgemv(lastv, lastc, a, k, a, iv0_tmp, work);
      xgerc(lastv, lastc, -tau[i], iv0_tmp, work, a, k);
    }
    a[alpha1_tmp_tmp] = alpha1_tmp;
  }
}

static int div_nzp_s32_floor(int numerator);

static int div_nzp_s32_floor(int numerator)
{
  unsigned int absNumerator;
  int quotient;
  unsigned int tempAbsQuotient;
  bool quotientNeedsNegation;
  if (numerator < 0) {
    absNumerator = ~(unsigned int)numerator + 1U;
  } else {
    absNumerator = (unsigned int)numerator;
  }
  quotientNeedsNegation = (numerator < 0);
  tempAbsQuotient = absNumerator / 3U;
  if (quotientNeedsNegation) {
    absNumerator %= 3U;
    if (absNumerator > 0U) {
      tempAbsQuotient++;
    }
    quotient = -(int)tempAbsQuotient;
  } else {
    quotient = (int)tempAbsQuotient;
  }
  return quotient;
}

void xgemv(int m, int n, const float A[9], int ia0, const float x[9], int ix0,
           float y[3])
{
  int ia;
  int iac;
  if (n != 0) {
    int i;
    i = (unsigned char)n;
    memset(&y[0], 0, (unsigned int)i * sizeof(float));
    i = ia0 + 3 * (n - 1);
    for (iac = ia0; iac <= i; iac += 3) {
      float c;
      int i1;
      c = 0.0F;
      i1 = (iac + m) - 1;
      for (ia = iac; ia <= i1; ia++) {
        c += A[ia - 1] * x[((ix0 + ia) - iac) - 1];
      }
      i1 = div_nzp_s32_floor(iac - ia0);
      y[i1] += c;
    }
  }
}

void xgerc(int m, int n, float alpha1, int ix0, const float y[3], float A[9],
           int ia0)
{
  int ijA;
  int j;
  if (!(alpha1 == 0.0F)) {
    int i;
    int jA;
    jA = ia0;
    i = (unsigned char)n;
    for (j = 0; j < i; j++) {
      float temp;
      temp = y[j];
      if (temp != 0.0F) {
        int i1;
        temp *= alpha1;
        i1 = m + jA;
        for (ijA = jA; ijA < i1; ijA++) {
          A[ijA - 1] += A[((ix0 + ijA) - jA) - 1] * temp;
        }
      }
      jA += 3;
    }
  }
}

static int div_nzp_s32(int numerator, int denominator);

static int div_nzp_s32(int numerator, int denominator)
{
  int quotient;
  unsigned int tempAbsQuotient;
  unsigned int u;
  if (numerator < 0) {
    tempAbsQuotient = ~(unsigned int)numerator + 1U;
  } else {
    tempAbsQuotient = (unsigned int)numerator;
  }
  if (denominator < 0) {
    u = ~(unsigned int)denominator + 1U;
  } else {
    u = (unsigned int)denominator;
  }
  tempAbsQuotient /= u;
  if ((numerator < 0) != (denominator < 0)) {
    quotient = -(int)tempAbsQuotient;
  } else {
    quotient = (int)tempAbsQuotient;
  }
  return quotient;
}

int xhseqr(float h[9], float z[9])
{
  float bb;
  float f;
  float h12;
  float h22;
  float rt1r;
  float rt2r;
  float s;
  float tr;
  int b_k;
  int c_k;
  int i;
  int info;
  int kdefl;
  int nr;
  bool exitg1;
  info = 0;
  h[2] = 0.0F;
  kdefl = 0;
  i = 2;
  exitg1 = false;
  while ((!exitg1) && (i + 1 >= 1)) {
    float tst;
    int b_i;
    int i1;
    int its;
    int k;
    int knt;
    bool converged;
    bool exitg2;
    k = -1;
    converged = false;
    its = 0;
    exitg2 = false;
    while ((!exitg2) && (its < 301)) {
      bool exitg3;
      k = i - 1;
      exitg3 = false;
      while ((!exitg3) && (k + 2 > 1)) {
        b_i = k + 3 * k;
        f = fabsf(h[b_i + 1]);
        if (f <= 2.95822839E-31F) {
          exitg3 = true;
        } else {
          nr = 3 * (k + 1);
          knt = k + nr;
          h12 = h[knt + 1];
          tr = fabsf(h12);
          bb = h[b_i];
          tst = fabsf(bb) + tr;
          if (tst == 0.0F) {
            if (k >= 1) {
              tst = fabsf(h[k]);
            }
            if (k + 3 <= 3) {
              tst += fabsf(h[nr + 2]);
            }
          }
          if (f <= 1.1920929E-7F * tst) {
            rt2r = fabsf(h[knt]);
            h12 = fabsf(bb - h12);
            tst = fmaxf(tr, h12);
            bb = fminf(tr, h12);
            s = tst + bb;
            if (fminf(f, rt2r) * (fmaxf(f, rt2r) / s) <=
                fmaxf(2.95822839E-31F, 1.1920929E-7F * (bb * (tst / s)))) {
              exitg3 = true;
            } else {
              k--;
            }
          } else {
            k--;
          }
        }
      }
      if (k + 2 > 1) {
        h[(k + 3 * k) + 1] = 0.0F;
      }
      if (k + 2 >= i) {
        converged = true;
        exitg2 = true;
      } else {
        float v[3];
        int m;
        kdefl++;
        if (kdefl - div_nzp_s32(kdefl, 20) * 20 == 0) {
          s = fabsf(h[i + 3 * (i - 1)]) + fabsf(h[i - 1]);
          tst = 0.75F * s + h[i + 3 * i];
          h12 = -0.4375F * s;
          bb = s;
          h22 = tst;
        } else if (kdefl - div_nzp_s32(kdefl, 10) * 10 == 0) {
          s = fabsf(h[1]) + fabsf(h[5]);
          tst = 0.75F * s + h[0];
          h12 = -0.4375F * s;
          bb = s;
          h22 = tst;
        } else {
          nr = i + 3 * (i - 1);
          tst = h[nr - 1];
          bb = h[nr];
          nr = i + 3 * i;
          h12 = h[nr - 1];
          h22 = h[nr];
        }
        s = ((fabsf(tst) + fabsf(h12)) + fabsf(bb)) + fabsf(h22);
        if (s == 0.0F) {
          rt1r = 0.0F;
          tst = 0.0F;
          rt2r = 0.0F;
          bb = 0.0F;
        } else {
          tst /= s;
          bb /= s;
          h12 /= s;
          h22 /= s;
          tr = (tst + h22) / 2.0F;
          tst = (tst - tr) * (h22 - tr) - h12 * bb;
          bb = sqrtf(fabsf(tst));
          if (tst >= 0.0F) {
            rt1r = tr * s;
            rt2r = rt1r;
            tst = bb * s;
            bb = -tst;
          } else {
            rt1r = tr + bb;
            rt2r = tr - bb;
            if (fabsf(rt1r - h22) <= fabsf(rt2r - h22)) {
              rt1r *= s;
              rt2r = rt1r;
            } else {
              rt2r *= s;
              rt1r = rt2r;
            }
            tst = 0.0F;
            bb = 0.0F;
          }
        }
        m = i - 1;
        if (i - 1 >= 1) {
          h12 = h[0] - rt2r;
          s = (fabsf(h12) + fabsf(bb)) + fabsf(h[1]);
          tr = h[1] / s;
          v[0] = (tr * h[3] + (h[0] - rt1r) * (h12 / s)) - tst * (bb / s);
          v[1] = tr * (((h[0] + h[4]) - rt1r) - rt2r);
          v[2] = tr * h[5];
          tst = (fabsf(v[0]) + fabsf(v[1])) + fabsf(v[2]);
          v[0] /= tst;
          v[1] /= tst;
          v[2] /= tst;
        }
        for (b_k = m; b_k <= i; b_k++) {
          nr = (i - b_k) + 2;
          if (nr >= 3) {
            nr = 3;
          }
          if (b_k > i - 1) {
            knt = ((b_k - 2) * 3 + b_k) - 1;
            for (c_k = 0; c_k < nr; c_k++) {
              v[c_k] = h[knt + c_k];
            }
          }
          h12 = v[0];
          rt2r = 0.0F;
          if (nr > 0) {
            tst = xnrm2(nr - 1, v);
            if (tst != 0.0F) {
              bb = rt_hypotf_snf(v[0], tst);
              if (v[0] >= 0.0F) {
                bb = -bb;
              }
              if (fabsf(bb) < 9.86076132E-32F) {
                knt = 0;
                do {
                  knt++;
                  for (c_k = 2; c_k <= nr; c_k++) {
                    v[c_k - 1] *= 1.01412048E+31F;
                  }
                  bb *= 1.01412048E+31F;
                  h12 *= 1.01412048E+31F;
                } while ((fabsf(bb) < 9.86076132E-32F) && (knt < 20));
                bb = rt_hypotf_snf(h12, xnrm2(nr - 1, v));
                if (h12 >= 0.0F) {
                  bb = -bb;
                }
                rt2r = (bb - h12) / bb;
                tst = 1.0F / (h12 - bb);
                for (c_k = 2; c_k <= nr; c_k++) {
                  v[c_k - 1] *= tst;
                }
                for (c_k = 0; c_k < knt; c_k++) {
                  bb *= 9.86076132E-32F;
                }
                h12 = bb;
              } else {
                rt2r = (bb - v[0]) / bb;
                tst = 1.0F / (v[0] - bb);
                for (c_k = 2; c_k <= nr; c_k++) {
                  v[c_k - 1] *= tst;
                }
                h12 = bb;
              }
            }
          }
          if (b_k > i - 1) {
            h[b_k - 1] = h12;
            h[b_k] = 0.0F;
            if (b_k < i) {
              h[2] = 0.0F;
            }
          }
          f = v[1];
          h12 = rt2r * v[1];
          if (nr == 3) {
            s = v[2];
            tst = rt2r * v[2];
            for (nr = b_k; nr < 4; nr++) {
              c_k = 3 * (nr - 1);
              knt = b_k + c_k;
              bb = h[knt - 1];
              tr = (bb + f * h[knt]) + s * h[c_k + 2];
              h[knt - 1] = bb - tr * rt2r;
              h[knt] -= tr * h12;
              h[c_k + 2] -= tr * tst;
            }
            if (b_k + 3 <= i + 1) {
              b_i = b_k + 2;
            } else {
              b_i = i;
            }
            for (nr = 0; nr <= b_i; nr++) {
              c_k = nr + 3 * (b_k - 1);
              bb = h[c_k];
              knt = nr + 3 * b_k;
              tr = (bb + f * h[knt]) + s * h[nr + 6];
              h[c_k] = bb - tr * rt2r;
              h[knt] -= tr * h12;
              h[nr + 6] -= tr * tst;
            }
            c_k = 3 * (b_k - 1);
            bb = z[c_k];
            tr = (bb + v[1] * z[3 * b_k]) + v[2] * z[6];
            z[c_k] = bb - tr * rt2r;
            z[3 * b_k] -= tr * h12;
            z[6] -= tr * tst;
            bb = z[c_k + 1];
            knt = 3 * b_k + 1;
            tr = (bb + v[1] * z[knt]) + v[2] * z[7];
            z[c_k + 1] = bb - tr * rt2r;
            z[knt] -= tr * h12;
            z[7] -= tr * tst;
            bb = z[c_k + 2];
            knt = 3 * b_k + 2;
            tr = (bb + v[1] * z[knt]) + v[2] * z[8];
            z[c_k + 2] = bb - tr * rt2r;
            z[knt] -= tr * h12;
            z[8] -= tr * tst;
          } else if (nr == 2) {
            for (nr = b_k; nr < 4; nr++) {
              b_i = b_k + 3 * (nr - 1);
              s = h[b_i - 1];
              h22 = h[b_i];
              tr = s + f * h22;
              s -= tr * rt2r;
              h[b_i - 1] = s;
              h22 -= tr * h12;
              h[b_i] = h22;
            }
            for (nr = 0; nr <= i; nr++) {
              b_i = nr + 3 * (b_k - 1);
              s = h[b_i];
              i1 = nr + 3 * b_k;
              h22 = h[i1];
              tr = s + f * h22;
              s -= tr * rt2r;
              h[b_i] = s;
              h22 -= tr * h12;
              h[i1] = h22;
            }
            b_i = 3 * (b_k - 1);
            f = z[b_i];
            s = z[3 * b_k];
            tr = f + v[1] * s;
            f -= tr * rt2r;
            z[b_i] = f;
            s -= tr * h12;
            z[3 * b_k] = s;
            f = z[b_i + 1];
            i1 = 3 * b_k + 1;
            s = z[i1];
            tr = f + v[1] * s;
            f -= tr * rt2r;
            z[b_i + 1] = f;
            s -= tr * h12;
            z[i1] = s;
            f = z[b_i + 2];
            i1 = 3 * b_k + 2;
            s = z[i1];
            tr = f + v[1] * s;
            f -= tr * rt2r;
            z[b_i + 2] = f;
            s -= tr * h12;
            z[i1] = s;
          }
        }
        its++;
      }
    }
    if (!converged) {
      info = i + 1;
      exitg1 = true;
    } else {
      if ((k + 2 != i + 1) && (k + 2 == i)) {
        b_i = i + 3 * i;
        f = h[b_i - 1];
        i1 = 3 * (i - 1);
        nr = i + i1;
        s = h[nr];
        h22 = h[b_i];
        xdlanv2(&h[nr - 1], &f, &s, &h22, &bb, &h12, &tr, &rt2r, &rt1r);
        h[b_i - 1] = f;
        h[nr] = s;
        h[b_i] = h22;
        if (i + 1 < 3) {
          nr = (i + 1) * 3 + i;
          b_i = 1 - i;
          for (b_k = 0; b_k <= b_i; b_k++) {
            knt = nr + b_k * 3;
            tst = h[knt];
            h12 = h[knt - 1];
            h[knt] = rt2r * tst - rt1r * h12;
            h[knt - 1] = rt2r * h12 + rt1r * tst;
          }
        }
        if (i - 1 >= 1) {
          nr = i * 3;
          b_i = (unsigned char)(i - 1);
          for (b_k = 0; b_k < b_i; b_k++) {
            knt = nr + b_k;
            tst = h[knt];
            c_k = i1 + b_k;
            h12 = h[c_k];
            h[knt] = rt2r * tst - rt1r * h12;
            h[c_k] = rt2r * h12 + rt1r * tst;
          }
        }
        nr = i * 3;
        tst = rt2r * z[i1] + rt1r * z[nr];
        z[nr] = rt2r * z[nr] - rt1r * z[i1];
        z[i1] = tst;
        tst = z[nr + 1];
        h12 = z[i1 + 1];
        z[nr + 1] = rt2r * tst - rt1r * h12;
        z[i1 + 1] = rt2r * h12 + rt1r * tst;
        tst = z[nr + 2];
        h12 = z[i1 + 2];
        z[nr + 2] = rt2r * tst - rt1r * h12;
        z[i1 + 2] = rt2r * h12 + rt1r * tst;
      }
      kdefl = 0;
      i = k;
    }
  }
  h[2] = 0.0F;
  return info;
}

float xnrm2(int n, const float x[3])
{
  float y;
  y = 0.0F;
  if (n >= 1) {
    if (n == 1) {
      y = fabsf(x[1]);
    } else {
      float absxk;
      float scale;
      float t;
      scale = 1.29246971E-26F;
      absxk = fabsf(x[1]);
      if (absxk > 1.29246971E-26F) {
        y = 1.0F;
        scale = absxk;
      } else {
        t = absxk / 1.29246971E-26F;
        y = t * t;
      }
      absxk = fabsf(x[2]);
      if (absxk > scale) {
        t = scale / absxk;
        y = y * t * t + 1.0F;
        scale = absxk;
      } else {
        t = absxk / scale;
        y += t * t;
      }
      y = scale * sqrtf(y);
    }
  }
  return y;
}


static float rt_powf_snf(float u0, float u1);

static float rt_powf_snf(float u0, float u1)
{
  float y;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = rtNaNF;
  } else {
    float f;
    float f1;
    f = fabsf(u0);
    f1 = fabsf(u1);
    if (rtIsInfF(u1)) {
      if (f == 1.0F) {
        y = 1.0F;
      } else if (f > 1.0F) {
        if (u1 > 0.0F) {
          y = rtInfF;
        } else {
          y = 0.0F;
        }
      } else if (u1 > 0.0F) {
        y = 0.0F;
      } else {
        y = rtInfF;
      }
    } else if (f1 == 0.0F) {
      y = 1.0F;
    } else if (f1 == 1.0F) {
      if (u1 > 0.0F) {
        y = u0;
      } else {
        y = 1.0F / u0;
      }
    } else if (u1 == 2.0F) {
      y = u0 * u0;
    } else if ((u1 == 0.5F) && (u0 >= 0.0F)) {
      y = sqrtf(u0);
    } else if ((u0 < 0.0F) && (u1 > floorf(u1))) {
      y = rtNaNF;
    } else {
      y = powf(u0, u1);
    }
  }
  return y;
}

void MAG_Calculate2(const emxArray_real32_T *x, const emxArray_real32_T *y,
              const emxArray_real32_T *z, creal32_T Ainv[9], float b[3],
              float *r)
{
  emxArray_real32_T *X;
  emxArray_real32_T *Y;
  emxArray_real32_T *a_tmp;
  float XTX[16];
  float b_x[9];
  float XTY[4];
  float b_k[3];
  const float *x_data;
  const float *y_data;
  const float *z_data;
  float bkj;
  float d;
  float s;
  float varargin_1;
  float y2n;
  float *X_data;
  float *Y_data;
  float *a_tmp_data;
  int aoffset;
  int b_tmp;
  int boffset;
  int coffset;
  int i;
  int j;
  int jA;
  int k;
  signed char A[9];
  signed char ipiv[4];
  signed char b_ipiv[3];
  bool isodd;
  z_data = z->data;
  y_data = y->data;
  x_data = x->data;
  emxInit_real32_T(&X, 2);
  i = X->size[0] * X->size[1];
  X->size[0] = x->size[0];
  X->size[1] = 4;
  emxEnsureCapacity_real32_T(X, i);
  X_data = X->data;
  jA = x->size[0];
  for (i = 0; i < jA; i++) {
    X_data[i] = 2.0F * x_data[i];
  }
  jA = y->size[0];
  for (i = 0; i < jA; i++) {
    X_data[i + X->size[0]] = 2.0F * y_data[i];
  }
  jA = z->size[0];
  for (i = 0; i < jA; i++) {
    X_data[i + X->size[0] * 2] = 2.0F * z_data[i];
  }
  jA = (int)(float)x->size[0];
  for (i = 0; i < jA; i++) {
    X_data[i + X->size[0] * 3] = 1.0F;
  }
  emxInit_real32_T(&Y, 1);
  if (x->size[0] == 1) {
    i = y->size[0];
  } else {
    i = x->size[0];
  }
  if ((x->size[0] == y->size[0]) && (i == z->size[0])) {
    i = Y->size[0];
    Y->size[0] = x->size[0];
    emxEnsureCapacity_real32_T(Y, i);
    Y_data = Y->data;
    jA = x->size[0];
    for (i = 0; i < jA; i++) {
      bkj = x_data[i];
      s = y_data[i];
      varargin_1 = z_data[i];
      Y_data[i] = (bkj * bkj + s * s) + varargin_1 * varargin_1;
    }
  } else {
    binary_expand_op(Y, x, y, z);
    Y_data = Y->data;
  }
  emxInit_real32_T(&a_tmp, 2);
  i = a_tmp->size[0] * a_tmp->size[1];
  a_tmp->size[0] = 4;
  a_tmp->size[1] = X->size[0];
  emxEnsureCapacity_real32_T(a_tmp, i);
  a_tmp_data = a_tmp->data;
  jA = X->size[0];
  for (i = 0; i < jA; i++) {
    a_tmp_data[4 * i] = X_data[i];
    a_tmp_data[4 * i + 1] = X_data[i + X->size[0]];
    a_tmp_data[4 * i + 2] = X_data[i + X->size[0] * 2];
    a_tmp_data[4 * i + 3] = X_data[i + X->size[0] * 3];
  }
  jA = a_tmp->size[1];
  XTY[0] = 0.0F;
  XTY[1] = 0.0F;
  XTY[2] = 0.0F;
  XTY[3] = 0.0F;
  for (k = 0; k < jA; k++) {
    aoffset = k << 2;
    XTY[0] += a_tmp_data[aoffset] * Y_data[k];
    XTY[1] += a_tmp_data[aoffset + 1] * Y_data[k];
    XTY[2] += a_tmp_data[aoffset + 2] * Y_data[k];
    XTY[3] += a_tmp_data[aoffset + 3] * Y_data[k];
  }
  emxFree_real32_T(&Y);
  jA = a_tmp->size[1];
  for (j = 0; j < 4; j++) {
    coffset = j << 2;
    boffset = j * X->size[0];
    XTX[coffset] = 0.0F;
    XTX[coffset + 1] = 0.0F;
    XTX[coffset + 2] = 0.0F;
    XTX[coffset + 3] = 0.0F;
    for (k = 0; k < jA; k++) {
      aoffset = k << 2;
      bkj = X_data[boffset + k];
      XTX[coffset] += a_tmp_data[aoffset] * bkj;
      XTX[coffset + 1] += a_tmp_data[aoffset + 1] * bkj;
      XTX[coffset + 2] += a_tmp_data[aoffset + 2] * bkj;
      XTX[coffset + 3] += a_tmp_data[aoffset + 3] * bkj;
    }
  }
  emxFree_real32_T(&a_tmp);
  emxFree_real32_T(&X);
  for (i = 0; i < 16; i++) {
    XTX[i] = -XTX[i];
  }
  ipiv[0] = 1;
  ipiv[1] = 2;
  ipiv[2] = 3;
  ipiv[3] = 4;
  for (j = 0; j < 3; j++) {
    signed char i1;
    boffset = 2 - j;
    b_tmp = j * 5;
    coffset = b_tmp + 2;
    jA = 4 - j;
    aoffset = 0;
    bkj = fabsf(XTX[b_tmp]);
    for (k = 2; k <= jA; k++) {
      s = fabsf(XTX[(b_tmp + k) - 1]);
      if (s > bkj) {
        aoffset = k - 1;
        bkj = s;
      }
    }
    if (XTX[b_tmp + aoffset] != 0.0F) {
      if (aoffset != 0) {
        jA = j + aoffset;
        ipiv[j] = (signed char)(jA + 1);
        bkj = XTX[j];
        XTX[j] = XTX[jA];
        XTX[jA] = bkj;
        bkj = XTX[j + 4];
        XTX[j + 4] = XTX[jA + 4];
        XTX[jA + 4] = bkj;
        bkj = XTX[j + 8];
        XTX[j + 8] = XTX[jA + 8];
        XTX[jA + 8] = bkj;
        bkj = XTX[j + 12];
        XTX[j + 12] = XTX[jA + 12];
        XTX[jA + 12] = bkj;
      }
      i = (b_tmp - j) + 4;
      for (aoffset = coffset; aoffset <= i; aoffset++) {
        XTX[aoffset - 1] /= XTX[b_tmp];
      }
    }
    jA = b_tmp;
    for (coffset = 0; coffset <= boffset; coffset++) {
      bkj = XTX[(b_tmp + (coffset << 2)) + 4];
      if (bkj != 0.0F) {
        i = jA + 6;
        aoffset = (jA - j) + 8;
        for (k = i; k <= aoffset; k++) {
          XTX[k - 1] += XTX[((b_tmp + k) - jA) - 5] * -bkj;
        }
      }
      jA += 4;
    }
    i1 = ipiv[j];
    if (i1 != j + 1) {
      bkj = XTY[j];
      XTY[j] = XTY[i1 - 1];
      XTY[i1 - 1] = bkj;
    }
  }
  for (k = 0; k < 4; k++) {
    jA = k << 2;
    if (XTY[k] != 0.0F) {
      i = k + 2;
      for (aoffset = i; aoffset < 5; aoffset++) {
        XTY[aoffset - 1] -= XTY[k] * XTX[(aoffset + jA) - 1];
      }
    }
  }
  for (k = 3; k >= 0; k--) {
    jA = k << 2;
    bkj = XTY[k];
    if (bkj != 0.0F) {
      bkj /= XTX[k + jA];
      XTY[k] = bkj;
      for (aoffset = 0; aoffset < k; aoffset++) {
        XTY[aoffset] -= XTY[k] * XTX[aoffset + jA];
      }
    }
  }
  A[0] = 1;
  A[3] = 0;
  A[6] = 0;
  A[1] = 0;
  A[4] = 1;
  A[7] = 0;
  A[2] = 0;
  A[5] = 0;
  A[8] = 1;
  b_k[0] = XTY[0];
  b_k[1] = XTY[1];
  b_k[2] = XTY[2];
  for (i = 0; i < 9; i++) {
    b_x[i] = A[i];
  }
  b_ipiv[0] = 1;
  b_ipiv[1] = 2;
  for (j = 0; j < 2; j++) {
    boffset = 1 - j;
    b_tmp = j << 2;
    coffset = b_tmp + 2;
    jA = 3 - j;
    aoffset = 0;
    bkj = fabsf(b_x[b_tmp]);
    for (k = 2; k <= jA; k++) {
      s = fabsf(b_x[(b_tmp + k) - 1]);
      if (s > bkj) {
        aoffset = k - 1;
        bkj = s;
      }
    }
    if (b_x[b_tmp + aoffset] != 0.0F) {
      if (aoffset != 0) {
        jA = j + aoffset;
        b_ipiv[j] = (signed char)(jA + 1);
        bkj = b_x[j];
        b_x[j] = b_x[jA];
        b_x[jA] = bkj;
        bkj = b_x[j + 3];
        b_x[j + 3] = b_x[jA + 3];
        b_x[jA + 3] = bkj;
        bkj = b_x[j + 6];
        b_x[j + 6] = b_x[jA + 6];
        b_x[jA + 6] = bkj;
      }
      i = (b_tmp - j) + 3;
      for (aoffset = coffset; aoffset <= i; aoffset++) {
        b_x[aoffset - 1] /= b_x[b_tmp];
      }
    }
    jA = b_tmp;
    for (coffset = 0; coffset <= boffset; coffset++) {
      bkj = b_x[(b_tmp + coffset * 3) + 3];
      if (bkj != 0.0F) {
        i = jA + 5;
        aoffset = (jA - j) + 6;
        for (k = i; k <= aoffset; k++) {
          b_x[k - 1] += b_x[((b_tmp + k) - jA) - 4] * -bkj;
        }
      }
      jA += 3;
    }
  }
  isodd = (b_ipiv[0] > 1);
  bkj = b_x[0] * b_x[4] * b_x[8];
  if (b_ipiv[1] > 2) {
    isodd = !isodd;
  }
  if (isodd) {
    bkj = -bkj;
  }
  if (bkj < 0.0F) {
    s = -rt_powf_snf(-bkj, 0.333333343F);
  } else {
    s = rt_powf_snf(bkj, 0.333333343F);
  }
  varargin_1 = s;
  isodd = ((!rtIsInfF(s)) && (!rtIsNaNF(s)));
  if (isodd && (bkj != 0.0F)) {
    y2n = rt_powf_snf(s, 3.0F);
    d = y2n - bkj;
    if (d != 0.0F) {
      varargin_1 = s - d / (3.0F * (y2n / s));
    }
  }
  for (i = 0; i < 9; i++) {
    b_x[i] = (float)A[i] / varargin_1;
  }
  c_sqrt(b_x, Ainv);
  for (i = 0; i < 9; i++) {
    b_x[i] = -(float)A[i];
  }
  aoffset = 0;
  coffset = 1;
  boffset = 2;
  jA = (int)fabsf(b_x[0]);
  if ((int)fabsf(b_x[1]) > jA) {
    jA = 1;
    aoffset = 1;
    coffset = 0;
  }
  if ((int)fabsf(b_x[2]) > jA) {
    aoffset = 2;
    coffset = 1;
    boffset = 0;
  }
  b_x[coffset] /= b_x[aoffset];
  b_x[boffset] /= b_x[aoffset];
  b_x[coffset + 3] -= b_x[coffset] * b_x[aoffset + 3];
  b_x[boffset + 3] -= b_x[boffset] * b_x[aoffset + 3];
  b_x[coffset + 6] -= b_x[coffset] * b_x[aoffset + 6];
  b_x[boffset + 6] -= b_x[boffset] * b_x[aoffset + 6];
  if (fabsf(b_x[boffset + 3]) > fabsf(b_x[coffset + 3])) {
    jA = coffset;
    coffset = boffset;
    boffset = jA;
  }
  b_x[boffset + 3] /= b_x[coffset + 3];
  b_x[boffset + 6] -= b_x[boffset + 3] * b_x[coffset + 6];
  b[1] = b_k[coffset] - b_k[aoffset] * b_x[coffset];
  b[2] = (b_k[boffset] - b_k[aoffset] * b_x[boffset]) - b[1] * b_x[boffset + 3];
  b[2] /= b_x[boffset + 6];
  b[0] = b_k[aoffset] - b[2] * b_x[aoffset + 6];
  b[1] -= b[2] * b_x[coffset + 6];
  b[1] /= b_x[coffset + 3];
  b[0] -= b[1] * b_x[aoffset + 3];
  b[0] /= b_x[aoffset];
  if (isodd && (bkj != 0.0F)) {
    y2n = rt_powf_snf(s, 3.0F);
    d = y2n - bkj;
    if (d != 0.0F) {
      s -= d / (3.0F * (y2n / s));
    }
  }
  *r = sqrtf(fabsf((((((b[0] * b[0] + 0.0F * b[0] * b[1]) + b[1] * b[1]) +
                      0.0F * b[0] * b[2]) +
                     b[2] * b[2]) +
                    0.0F * b[1] * b[2]) -
                   XTY[3])) /
       sqrtf(s);
}

void argInit_Unboundedx1_real32_T(emxArray_real32_T **px, emxArray_real32_T **py, emxArray_real32_T **pz, float data[][3], int nlines)
{
  emxArray_real32_T *x;
  emxArray_real32_T *y;
  emxArray_real32_T *z;
  float *x_data;
  float *y_data;
  float *z_data;
  int idx0 = 0;

  idx0 = nlines;
  x = emxCreateND_real32_T(1, &idx0);
  idx0 = nlines;
  x_data = x->data;
  y = emxCreateND_real32_T(1, &idx0);
  y_data = y->data;
  idx0 = nlines;
  z = emxCreateND_real32_T(1, &idx0);
  z_data = z->data;


  for (idx0 = 0; idx0 < x->size[0U]; idx0++) {
    x_data[idx0] = data[idx0][0];
    y_data[idx0] = data[idx0][1];
    z_data[idx0] = data[idx0][2];

  }

  *px = x;
  *py = y;
  *pz = z;
  return ;
}

