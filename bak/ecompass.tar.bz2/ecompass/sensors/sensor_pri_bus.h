/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @File	  sensor_pri_bus.h
  * @Brief	This file contains all the function prototypes for 
  *			    the sensor_pri_bus.c file
  ******************************************************************************
  * @Attention
  *
  * This notice applies to any and all portions of this file.
  * Any changes including modifications, additions, comments, etc.
  * need to add the author, time, and function notes. Other portions of
  * this file, whether inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2024 - , IBE Technology Co., Ltd.
  * All rights reserved.
  *
  ******************************************************************************
  *	@History
  * @<author>              @<version>              @<desc>
  *		  HG         		  0.0.1.250716_base       Build this module
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SENSOR_PRI_BUS_H__
#define __SENSOR_PRI_BUS_H__

#ifdef __cplusplus
extern "C" {
#endif


/* Includes -------------------------------------------------------------------*/


/* Public includes ------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sensor_dev.h>

/* Exported macro ------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

extern struct device *i2c_dev;
/* Exported constants --------------------------------------------------------*/


/* Exported functions ------------------------------------------------------- */
void Delay_Ms(int cnt);
void Delay_Us(int cnt);
// int sensor_normal_bus_i2c_read(struct device *dev,uint16_t dev_addr,uint16_t reg, uint16_t reg_len,uint8_t *buf, uint16_t len);
// int sensor_normal_bus_i2c_write(struct device *dev, uint16_t dev_addr,uint16_t reg, uint16_t reg_len,uint8_t *buf, uint16_t len);
int I2C_Read_Reg(unsigned char i2c_add, unsigned char reg_add, unsigned char *data);
int I2C_MultiRead_Reg(unsigned char i2c_add, unsigned char reg_add, int num, unsigned char *data);
int I2C_Write_Reg(uint8_t sla_addr, uint8_t reg, uint8_t reg_data);
int sensor_normal_bus_i2c_read(struct device *dev,uint16_t dev_addr,uint16_t reg, uint16_t reg_len,uint8_t *buf, uint16_t len);
int sensor_normal_bus_i2c_write(struct device *dev, uint16_t dev_addr,uint16_t reg, uint16_t reg_len,uint8_t *buf, uint16_t len);


#ifdef __cplusplus
}
#endif

#endif /* __SENSOR_PRI_BUS_H__ */

/*********** (C) Copyright 2024 IBE Technology Co., Ltd. *****END OF FILE****/
