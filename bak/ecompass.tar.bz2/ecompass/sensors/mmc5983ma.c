/*****************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software is protected by Copyright, and the information and source code
 *  contained herein is confidential. The software including the source code
 *  may not be copied and the information contained herein may not be used or
 *  disclosed except with the written permission of MEMSIC Inc. (C) 2019
 *****************************************************************************/

/**
 * @brief
 * This file implement magnetic sensor driver APIs.
 * Modified history: 
 * V1.1: Add the interrupt function on 20190109
 */

#include "mmc5983ma.h"
#include "sensor_pri_bus.h"
/* Function declaration */

/**
 * @brief OTP read done check
 */
int MMC5983_Check_OTP(void);

/**
 * @brief Check Product ID
 */
int MMC5983_Check_ID(void);

/**
 * @brief Reset the sensor by software
 */
void MMC5983_Software_Reset(void);

/**
 * @brief SET operation 
 */
void MMC5983_SET(void);

/**
 * @brief RESET operation 
 */
void MMC5983_RESET(void);

/**
 * @brief Continuous mode configuration with auto set and reset
 */
void MMC5983_Continuous_Mode_With_Auto_SR(uint8_t bandwith, uint8_t sampling_rate);

/*********************************************************************************
* decription: OTP read done check
*********************************************************************************/
int MMC5983_Check_OTP(void)
{
	unsigned char reg_val = 0;
	
	Delay_Ms(20);	
	/* Read reg 0x08, check OTP_Read_Done bit */
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_STATUS, &reg_val);	
	printk("%s: addr: 0x%x 0x%x, reg_val: 0x%x\n", __func__, MMC5983_7BITI2C_ADDRESS, MMC5983_REG_STATUS, reg_val);
	if((reg_val&MMC5983_OTP_READ_DONE) != MMC5983_OTP_READ_DONE)
		return -1;
	
	return 1;
}

/*********************************************************************************
* decription: Product ID check
*********************************************************************************/
int MMC5983_Check_ID(void)
{
	unsigned char pro_id = 0;
	//mmc_i2c_obj = drv_i2c_find("i2c1");
	/* Read reg 0x2F, check product ID, default value is 0x30 */
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_PRODUCTID1, &pro_id);	
	printk("%s: addr: 0x%x 0x%x, reg_val: 0x%x\n", __func__, MMC5983_7BITI2C_ADDRESS, MMC5983_REG_PRODUCTID1, pro_id);
	if(pro_id != MMC5983_PRODUCT_ID)
		return -1;
	
	return 1;
}

/*********************************************************************************
* decription: Reset the sensor by software
*********************************************************************************/
void MMC5983_Software_Reset(void)
{
	/* Write reg 0x0A, set SW_RST bit '1', cause the chip to reset, re-read OTP */
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL1, MMC5983_CMD_SW_RST);
	
	/* Delay 20ms to finish the software reset operation */
	Delay_Ms(20);
	
	return;	
}

/*********************************************************************************
* decription: SET operation 
*********************************************************************************/
void MMC5983_SET(void)
{	
	/* Write reg 0x09, Set Set bit '1', cause the chip to do Set operation */
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL0, MMC5983_CMD_SET);	
	
	/* Delay to finish the SET operation */
	Delay_Us(500);
	
	return;	
}

/*********************************************************************************
* decription: RESET operation 
*********************************************************************************/
void MMC5983_RESET(void)
{	
	/* Write reg 0x09, Set Reset bit '1', cause the chip to do Reset operation */
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL0, MMC5983_CMD_RESET);
	
	/* Delay to finish the RESET operation */
	Delay_Us(500);
	
	return;	
}

/*********************************************************************************
* decription: Continuous mode configuration with auto set and reset
*********************************************************************************/
void MMC5983_Continuous_Mode_With_Auto_SR(uint8_t bandwith, uint8_t sampling_rate)
{
	/* Write reg 0x0A */
	/* Set BW<1:0> = bandwith 
		BW1	BW0	Measurement Time	Bandwidth
		0	0		8ms				100Hz
		0	1		4ms				200Hz
		1	0		2ms				400Hz
		1	1		0.5ms			800Hz
	*/
	unsigned char reg_val = 0;
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL1, &reg_val);	
	printk("%s: addr: 0x%x, write reg: 0x%x, read reg: 0x%x\n", __func__, MMC5983_REG_CTRL1, bandwith, reg_val);
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL1, bandwith);
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL1, &reg_val);	
	printk("%s: addr: 0x%x, write reg: 0x%x, read reg: 0x%x\n", __func__, MMC5983_REG_CTRL1, bandwith, reg_val);
	
	/* Write reg 0x09 */
	/* Set Auto_SR_en bit '1', Enable the function of automatic set/reset */
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL0, &reg_val);	
	printk("%s: addr: 0x%x, write reg: 0x%x, read reg: 0x%x\n", __func__, MMC5983_REG_CTRL0, MMC5983_CMD_AUTO_SR_EN, reg_val);
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL0, MMC5983_CMD_AUTO_SR_EN);	
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL0, &reg_val);	
	printk("%s: addr: 0x%x, write reg: 0x%x, read reg: 0x%x\n", __func__, MMC5983_REG_CTRL0, MMC5983_CMD_AUTO_SR_EN, reg_val);

	/* Write reg 0x0B */
	/* Set Cmmm_en bit '1', Enable the continuous mode */	
	/* Set CM_Freq<2:0> = sampling_rate 
				001				1 Hz
				010				10 Hz
				011				20 Hz
				100				50 Hz
				101				100 Hz
				110				200 Hz
				111				1000 Hz
	*/
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL2, &reg_val);	
	printk("%s: addr: 0x%x, write reg: 0x%x, read reg: 0x%x\n", __func__, MMC5983_REG_CTRL2, MMC5983_CMD_CMM_EN|sampling_rate, reg_val);
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL2, MMC5983_CMD_CMM_EN|sampling_rate);
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL2, &reg_val);	
	printk("%s: addr: 0x%x, write reg: 0x%x, read reg: 0x%x\n", __func__, MMC5983_REG_CTRL2, MMC5983_CMD_CMM_EN|sampling_rate, reg_val);
	
	return;
}

/*********************************************************************************
* decription: Disable sensor continuous mode
*********************************************************************************/
void MMC5983_Disable(void)
{
	/* Write reg 0x0B */
	/* Set Cmm_en bit '0', Disable continuous mode */	
	I2C_Write_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_CTRL2, 0x00);
	
	/* Delay 20ms to make sure finish the last measurement */
	Delay_Ms(20);
	
	return;
}

/*********************************************************************************
* decription: Enable sensor
*********************************************************************************/
int MMC5983_Enable(void)
{	
	int ret = 0;

	/* Check OTP Read status */
	ret = MMC5983_Check_OTP();
	if(ret<0)
	{
		printk("%s: check otp failed\n", __func__);
		return 0;	
	}
	
	/* Check product ID */
	ret = MMC5983_Check_ID();
	if(ret<0)
	{
		printk("%s: check chip id failed\n", __func__);
		return 0;	
	}
	
	/*Work mode setting*/
	MMC5983_Continuous_Mode_With_Auto_SR(MMC5983_CMD_BW00, MMC5983_CMD_CM_FREQ_50HZ);
	
	Delay_Ms(20);
	
	return 1;
}


/*********************************************************************************
* decription: Read the data register and convert to magnetic field 
*********************************************************************************/
void MMC5983_GetData(float *mag_out)
{
	uint8_t data_reg[7] = {0};
   uint32_t data18bit[3] = {0};
			
	/* Read register data */
	I2C_MultiRead_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_DATA, 7, data_reg);
	
	// /* Get 18bits data, raw data unit is "count or LSB" */  
	data18bit[0] = (uint32_t)(data_reg[0]<<10 | data_reg[1]<<2 | (data_reg[6]&0xC0)>>6);
	data18bit[1] = (uint32_t)(data_reg[2]<<10 | data_reg[3]<<2 | (data_reg[6]&0x30)>>4);
	data18bit[2] = (uint32_t)(data_reg[4]<<10 | data_reg[5]<<2 | (data_reg[6]&0x0C)>>2);	

	// /* Magnetic field output, unit is Gauss */
	mag_out[0] = ((float)data18bit[0] - MMC5983_18BIT_OFFSET)/MMC5983_18BIT_SENSITIVITY; 
	mag_out[1] = ((float)data18bit[1] - MMC5983_18BIT_OFFSET)/MMC5983_18BIT_SENSITIVITY;
	mag_out[2] = ((float)data18bit[2] - MMC5983_18BIT_OFFSET)/MMC5983_18BIT_SENSITIVITY;

#if 0
    uint32_t data16bit[3] = {0};
	/* Get high 16bits data */
	data16bit[0] = (uint32_t)(data_reg[0] << 8 | data_reg[1]);	
	data16bit[1] = (uint32_t)(data_reg[2] << 8 | data_reg[3]);			
	data16bit[2] = (uint32_t)(data_reg[4] << 8 | data_reg[5]); 
			
	/* Magnetic field output, unit is Gauss */
	mag_out[0] = ((float)data16bit[0] - MMC5983_16BIT_OFFSET)/MMC5983_16BIT_SENSITIVITY; 
	mag_out[1] = ((float)data16bit[1] - MMC5983_16BIT_OFFSET)/MMC5983_16BIT_SENSITIVITY;
	mag_out[2] = ((float)data16bit[2] - MMC5983_16BIT_OFFSET)/MMC5983_16BIT_SENSITIVITY;
#endif

	/*
	for (int i = 0; i < 7; i++)
	{
		printf("regs: %x ", data_reg[i]);
	}

	printf("\n16bit: %.8f %.8f %.8f\n", 
		((float)data16bit[0] - MMC5983_16BIT_OFFSET)/MMC5983_16BIT_SENSITIVITY * 1000, 
		((float)data16bit[1] - MMC5983_16BIT_OFFSET)/MMC5983_16BIT_SENSITIVITY * 1000,
		((float)data16bit[2] - MMC5983_16BIT_OFFSET)/MMC5983_16BIT_SENSITIVITY * 1000
			);
	printf("18bit: %.8f %.8f %.8f\n", 
	((float)data18bit[0] - MMC5983_18BIT_OFFSET)/MMC5983_18BIT_SENSITIVITY * 1000, 
	((float)data18bit[1] - MMC5983_18BIT_OFFSET)/MMC5983_18BIT_SENSITIVITY * 1000,
	((float)data18bit[2] - MMC5983_18BIT_OFFSET)/MMC5983_18BIT_SENSITIVITY * 1000
			);
			*/
		
		
	return;
}

