/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  *	@File	  sensor_pri_hal.c
  *	@Brief	This file provides code for the configuration
  *        	of the sensor_privately_hal instances.
  ******************************************************************************
  * @Attention
  *
  * This notice applies to any and all portions of this file.
  * Any changes including modifications, additions, comments, etc.
  * need to add the author, time, and function notes. Other portions of
  * this file, whether inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2024 - , IBE Technology Co., Ltd.
  * All rights reserved.
  *
  ******************************************************************************
  * @History
  * @<author>              @<version>              @<desc>
  *		  HG         		  0.0.1.250716_base       Build this module
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
/* Public includes -----------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <sensor_bus.h>
#include <zephyr.h>
#include <drivers/gpio.h>
#include <drivers/i2c.h>
#include <drivers/spi.h>
#include <drivers/spimt.h>
#include <os_common_api.h>
#include <board_cfg.h>
#include <sensor_devices.h>
/* Private define ------------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/

static __act_s2_sleep_data struct device *spi_dev[4] = { NULL };
static __act_s2_sleep_data struct device *i2c_dev[4] = { NULL };

/* Private function prototypes -----------------------------------------------*/	
/* Private application code begin --------------------------------------------*/

static int sensor_bus_i2c_read(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len)
{
	int ret = 0;
	uint8_t cmd[4];

	if (reg != REG_NULL) {
		if (dev->hw.adr_len > 1) {
			cmd[0] = (reg >> 8) & 0xff;
			cmd[1] = reg & 0xff;
		} else {
			cmd[0] = reg;
		}
		ret = i2c_write_read(i2c_dev[dev->io.bus_id], dev->hw.dev_addr, cmd, dev->hw.adr_len, buf, len);
	} else {
		ret = i2c_read(i2c_dev[dev->io.bus_id], buf, len, dev->hw.dev_addr);
	}
	
	return ret;
}
static int sensor_bus_i2c_write(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len)
{
	int ret = 0;
	uint8_t wr_buf[16];

	if (reg != REG_NULL) {
		if ((dev->hw.adr_len + len) > sizeof(wr_buf)) {
//			SYS_LOG_ERR("sensor: i2c_write %d bytes too long!\n", len);
			return -1;
		}
		if (dev->hw.adr_len > 1) {
			wr_buf[0] = (reg >> 8) & 0xff;
			wr_buf[1] = reg & 0xff;
		} else {
			wr_buf[0] = reg;
		}
		memcpy(wr_buf+dev->hw.adr_len, buf, len);
		ret = i2c_write(i2c_dev[dev->io.bus_id], wr_buf, dev->hw.adr_len+len, dev->hw.dev_addr);
	} else {
		ret = i2c_write(i2c_dev[dev->io.bus_id], buf, len, dev->hw.dev_addr);
	}

	return ret;
}

static int sensor_bus_spi_read(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len)
{
	int ret = 0;
	uint8_t cmd[4];
	const struct spi_buf tx_bufs[] = { { .buf = cmd, .len = 1, },	};
	const struct spi_buf rx_bufs[] = { { .buf = buf, .len = len, }, };
	const struct spi_buf_set tx = {	.buffers = tx_bufs,	.count = ARRAY_SIZE(tx_bufs) };
	const struct spi_buf_set rx = {	.buffers = rx_bufs,	.count = ARRAY_SIZE(rx_bufs) };

	if (reg != REG_NULL) {
		cmd[0] = reg | (1 << 7); //rw=1
		ret = spi_transceive(spi_dev[dev->io.bus_id], NULL, &tx, &rx);
	} else {
		ret = spi_read(spi_dev[dev->io.bus_id], NULL, &rx);
	}

	return ret;
}

static int sensor_bus_spi_write(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len)
{
	int ret = 0;
	uint8_t cmd[4];
	const struct spi_buf tx_bufs[] = { { .buf = buf, .len = len, },	};
	const struct spi_buf_set tx = {	.buffers = tx_bufs,	.count = ARRAY_SIZE(tx_bufs) };
	const struct spi_buf tx2_bufs[] = { { .buf = cmd, .len = 1, }, { .buf = buf, .len = len, },	};
	const struct spi_buf_set tx2 = {	.buffers = tx2_bufs,	.count = ARRAY_SIZE(tx2_bufs) };

	if (reg != REG_NULL) {
		cmd[0] = reg & ~(1 << 7); //rw=0
		ret = spi_write(spi_dev[dev->io.bus_id], NULL, &tx2);
	} else {
		ret = spi_write(spi_dev[dev->io.bus_id], NULL, &tx);
	}

	return ret;
}

static int sensor_bus_i2c_xfer(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len, uint8_t rd)
{
	int ret = 0;
	
	if (rd) {
		ret = sensor_bus_i2c_read(dev, reg, buf, len);
	} else {
		ret = sensor_bus_i2c_write(dev, reg, buf, len);
	}
	
	return ret;
}
static int sensor_bus_spi_xfer(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len, uint8_t rd)
{
	int ret = 0;
	
	spi_cs_select(spi_dev[dev->io.bus_id], dev->io.bus_cs);
	
	if (rd) {
		ret = sensor_bus_spi_read(dev, reg, buf, len);
	} else {
		ret = sensor_bus_spi_write(dev, reg, buf, len);
	}
	
	return ret;
}
static int sensor_bus_xfer(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len, uint8_t rd)
{
	int ret = 0;
	
	if (dev->hw.name == NULL) {
		return -1;
	}
	
	if (dev->io.bus_type == BUS_I2C) {
		ret = sensor_bus_i2c_xfer(dev, reg, buf, len, rd);
	} else if (dev->io.bus_type == BUS_SPI) {
		ret = sensor_bus_spi_xfer(dev, reg, buf, len, rd);
	}
	
	return ret;
}
int sensor_pri_bus_read(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len)
{
	return sensor_bus_xfer(dev, reg, buf, len, 1);
}

int sensor_pri_bus_write(const sensor_dev_t *dev, uint16_t reg, uint8_t *buf, uint16_t len)
{
	return sensor_bus_xfer(dev, reg, buf, len, 0);
}

#if 0
static int sensor_bus_i2c_task_start(int bus_id, i2c_task_t *task, sensor_bus_cb_t cb, void *ctx)
{
	uint32_t task_id;

	// get task id
	task_id = ((task->trig.task - SPI_TASK_NUM * 2) % I2C_TASK_NUM);
	
	// add task callback
	i2c_register_callback(i2c_dev[bus_id], task_id, cb, ctx);
	
	// start task
	return i2c_task_start(i2c_dev[bus_id], task_id, task);
}

static int sensor_bus_i2c_task_stop(int bus_id, i2c_task_t *task)
{
	uint32_t task_id;
	
	// get task id
	task_id = ((task->trig.task - SPI_TASK_NUM * 2) % I2C_TASK_NUM);
	
	// remove task callback
	i2c_register_callback(i2c_dev[bus_id], task_id, NULL, NULL);
	
	// stop task
	return i2c_task_stop(i2c_dev[bus_id], task_id);
}

static int sensor_bus_spi_task_start(int bus_id, spi_task_t *task, sensor_bus_cb_t cb, void *ctx)
{
	uint32_t task_id;

	// get task id
	task_id = (task->trig.task % SPI_TASK_NUM);
	
	// add task callback
	spi_register_callback(spi_dev[bus_id], task_id, cb, ctx);
	
	// start task
	return spi_task_start(spi_dev[bus_id], task_id, task);
}

static int sensor_bus_spi_task_stop(int bus_id, spi_task_t *task)
{
	uint32_t task_id;
	
	// get task id
	task_id = (task->trig.task % SPI_TASK_NUM);
		
	// remove task callback
	spi_register_callback(spi_dev[bus_id], task_id, NULL, NULL);
	
	// stop task
	return spi_task_stop(spi_dev[bus_id], task_id);
}

int sensor_bus_task_start(const sensor_dev_t *dev, sensor_bus_cb_t cb, void *ctx)
{
	int ret = -1;
	
	if ((dev->task == NULL) || (cb == NULL)) {
		return -1;
	}
	
	if (dev->io.bus_type == BUS_I2C) {
		ret = sensor_bus_i2c_task_start(dev->io.bus_id, (i2c_task_t*)dev->task, cb, ctx);
	} else if (dev->io.bus_type == BUS_SPI) {
		ret = sensor_bus_spi_task_start(dev->io.bus_id, (spi_task_t*)dev->task, cb, ctx);
	}
	
	return ret;
}

int sensor_bus_task_stop(const sensor_dev_t *dev)
{
	int ret = -1;
	
	if (dev->task == NULL) {
		return -1;
	}

	if (dev->io.bus_type == BUS_I2C) {
		ret = sensor_bus_i2c_task_stop(dev->io.bus_id, (i2c_task_t*)dev->task);
	} else if (dev->io.bus_type == BUS_SPI) {
		ret = sensor_bus_spi_task_stop(dev->io.bus_id, (spi_task_t*)dev->task);
	}
	
	return ret;
}
#endif

#include <sensor_hal.h>
#include <sensor_io.h>
#include <sensor_bus.h>
#include <sensor_devices.h>

void sensor_id_test(void)
{
	const sensor_dev_t *dev;
	uint16_t chip_id = 0xffff;
	dev = sensor_dev_list[2];
	if (sensor_dev_is_valid(dev)) {
			sensor_io_init(dev);
		}
	printk("tom i2c sensor[%s] = %s\n", sensor_hal_get_type(2), sensor_dev_get_name(dev));	
	for(int i=0;i<128;i++)	{
		sensor_pri_bus_read(dev,dev->hw.chip_reg, (uint8_t*)&chip_id, dev->hw.reg_len);
	}
	

}


/* Private application code end ----------------------------------------------*/
/*********** (C) Copyright 2024 IBE Technology Co., Ltd. *****END OF FILE****/
