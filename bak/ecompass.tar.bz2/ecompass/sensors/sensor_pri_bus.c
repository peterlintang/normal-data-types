/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  *	@File	  sensor_pri_bus.c
  *	@Brief	This file provides code for the configuration
  *        	of the sensor private bus instances.
  ******************************************************************************
  * @Attention
  *
  * This notice applies to any and all portions of this file.
  * Any changes including modifications, additions, comments, etc.
  * need to add the author, time, and function notes. Other portions of
  * this file, whether inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2024 - , IBE Technology Co., Ltd.
  * All rights reserved.
  *
  ******************************************************************************
  * @History
  * @<author>              @<version>              @<desc>
  *		  HG         		  0.0.1.250716_base       Build this module
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
/* Public includes -----------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <sensor_bus.h>
#include <zephyr.h>
#include <drivers/gpio.h>
#include <drivers/i2c.h>
#include <drivers/spi.h>
#include <os_common_api.h>
#include <board_cfg.h>
#include "sensor_pri_bus.h"
/* Private define ------------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
//static __act_s2_sleep_data struct device *spi_dev[4] = { NULL };
// static __act_s2_sleep_data struct device *i2c_dev[4] = { NULL };
struct device *i2c_dev = NULL;
/* Private function prototypes -----------------------------------------------*/	
/* Private application code begin --------------------------------------------*/
void Delay_Ms(int cnt)
{
	/*  cnt is the time to wait */
	k_sleep(K_MSEC(cnt));
	/* 
	.
	. Need to be implemented by user. 
	.
	*/
	
	return;
}
void Delay_Us(int cnt)
{
  	cnt*=1000;
	/*  cnt is the time to wait */
	while(cnt--)
	{
		
	}
	/* 
	.
	. Need to be implemented by user. 
	.
	*/

	return;
}

int sensor_normal_bus_i2c_read(struct device *dev,uint16_t dev_addr,uint16_t reg, uint16_t reg_len,uint8_t *buf, uint16_t len)
{
  int ret=0;
  uint8_t cmd[4];

	if (reg != REG_NULL) {
		if (reg_len > 1) {
			cmd[0] = (reg >> 8) & 0xff;
			cmd[1] = reg & 0xff;
		} else {
			cmd[0] = reg;
		}
		//ret = i2c_write_read(dev, dev_addr, cmd, dev->hw.adr_len, buf, len);
    ret = i2c_write_read(dev,dev_addr,cmd,reg_len,buf,len);
	}else{
    ret = i2c_read(dev, buf, len, dev_addr);
  }

  return ret;
}

int sensor_normal_bus_i2c_write(struct device *dev, uint16_t dev_addr,uint16_t reg, uint16_t reg_len,uint8_t *buf, uint16_t len)
{
	int ret = 0;
	uint8_t wr_buf[16];

	if (reg != REG_NULL) {
		if ((reg_len + len) > sizeof(wr_buf)) {
//			SYS_LOG_ERR("sensor: i2c_write %d bytes too long!\n", len);
			return -1;
		}
		if (reg_len > 1) {
			wr_buf[0] = (reg >> 8) & 0xff;
			wr_buf[1] = reg & 0xff;
		} else {
			wr_buf[0] = reg;
		}
		memcpy(wr_buf+reg_len, buf, len);
		ret = i2c_write(dev, wr_buf, reg_len+len, dev_addr);
	} else {
		ret = i2c_write(dev, buf, len, dev_addr);
	}

	return ret;
}

int I2C_Read_Reg(unsigned char i2c_add, unsigned char reg_add, unsigned char *data)
{
	uint8_t ret;
  if(i2c_dev == NULL) 
  {
	  printf("%s: i2c dev null\n", __func__);
	  return -1;
  }
	//ret=drv_i2c_read(mmc_dev,i2c_add,reg_add,1,(uint8_t*)data,1);
  ret=sensor_normal_bus_i2c_read(i2c_dev,i2c_add,reg_add,1,(uint8_t*)data,1);
	return ret;
}

 
int I2C_MultiRead_Reg(unsigned char i2c_add, unsigned char reg_add, int num, unsigned char *data)
{
	uint8_t ret;
  if(i2c_dev == NULL) 
  {
	  printf("%s: i2c dev null\n", __func__);
	  return -1;
  }
	//ret=drv_i2c_read(mmc_dev,i2c_add,reg_add,1,(uint8_t*)data,num);
  ret=sensor_normal_bus_i2c_read(i2c_dev,i2c_add,reg_add,1,(uint8_t*)data,num);
	return ret;
}

int I2C_Write_Reg(uint8_t sla_addr, uint8_t reg, uint8_t reg_data)
{
	uint8_t ret;
  if(i2c_dev == NULL) 
  {
	  printf("%s: i2c dev null\n", __func__);
	  return -1;
  }
	//ret=drv_i2c_write(mmc_dev,sla_addr,reg,1,&reg_data,1);
  ret=sensor_normal_bus_i2c_write(i2c_dev,sla_addr,reg,1,&reg_data,1);
	return ret;
}



//  int sensor_nor_bus_init(const struct device *dev)
// {

//   ARG_UNUSED(dev);

// 	/* get device */
// 	i2c_dev[3] = (struct device*)device_get_binding(CONFIG_I2C_3_NAME);
// 	if (!i2c_dev[3]) {
// 		SYS_LOG_ERR("[i2c3] get device failed!");
// 		//return -1;
// 	}
// 	i2c_dev[0] = (struct device*)device_get_binding(CONFIG_I2CMT_1_NAME);
// 	if (!i2c_dev[0]) {
// 		SYS_LOG_ERR("[i2c3] get device failed!");
// 		//return -1;
// 	}

// //uint16_t addr=0x6b;
// uint16_t chip_addr=0x0f;
// uint8_t chip_id=0x0;
// int ret=0;

// //ret = i2c_write(i2c_dev[3],&buf,len,addr);
// for(int i=0;i<256;i++){
  
// 	//ret = i2c_write_read(i2c_dev[0],i,&chip_addr,1,&chip_id,1);
//   ret = sensor_normal_bus_i2c_read(i2c_dev[0],i,chip_addr,1,&chip_id,1);
// 	printk("tom i2c3:%d,%02x,%d\n",i,chip_id,ret);
// }

// 	return 0;
// }





/* Private application code end ----------------------------------------------*/
/*********** (C) Copyright 2024 IBE Technology Co., Ltd. *****END OF FILE****/
