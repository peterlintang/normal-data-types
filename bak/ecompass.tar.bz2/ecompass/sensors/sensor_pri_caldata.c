/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  *	@File	  sensor_nor_caldata.c
  *	@Brief	This file provides code for the configuration
  *        	of the sensor normal caldata instances.
  ******************************************************************************
  * @Attention
  *
  * This notice applies to any and all portions of this file.
  * Any changes including modifications, additions, comments, etc.
  * need to add the author, time, and function notes. Other portions of
  * this file, whether inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2024 - , IBE Technology Co., Ltd.
  * All rights reserved.
  *
  ******************************************************************************
  * @History
  * @<author>              @<version>              @<desc>
  *		  HG         		  0.0.1.250716_base       Build this module
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
/* Public includes -----------------------------------------------------------*/
#include <soc.h>
#include <zephyr.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <device.h>
#include "sensor_pri_bus.h"
#include <board_cfg.h>
#include <sensor_manager.h>
#include "sensor_hal.h"

#if 1
#include "mmc5983ma.h"
#if 0
#include "compass_type.h"

#include "SensorAlgoMotion_Mad/SensorAlgoMotion_mad.h"
#include "MadgwickAHRS/MadgwickAHRS.h"
#include "MadgwickAHRS/MahonyAHRS.h"
#endif
#ifdef CONFIG_PROPERTY
#include <property_manager.h>
#endif
#ifdef CONFIG_SENSOR_PRI_ACC_LSM6DSL
#include "lsm6dsl/lsm6dsl.h"
#endif
#ifdef CONFIG_SENSOR_PRI_ACC_LSM6DSV
#include "lsm6dsv/lsm6dsv.h"
#endif
#if CONFIG_SENSOR_ALGO_ANGLE
#include "algorithm_angle.h"
#include "algorithm_angle/compass_type.h"
#endif

#if CONFIG_SENSOR_PRI_BARO_BMP5
#include "bmp5/bmp5.h"
#endif

#if CONFIG_SENSOR_PRI_TEMP_NST112_DSTR
#include "nst112_dstr/nst112_dstr.h"
#endif
#if CONFIG_SENSOR_PRI_MAG_MMC5983MA
#include "mmc5983ma/mmc5983ma.h"
#endif
#if CONFIG_MOTIONFX
#include "motionfx/motion_fx.h"
#include "motionfx/motion_fx_manager.h"
#endif
#if 0
#include "motion_fx.h"
#include "sensor_pri_hal.h"
#endif
#include "msg_manager.h"

#ifdef CONFIG_GOLF_MANAGER
#include "golf_manager.h"
#endif // CONFIG_GOLF_MANAGER

#ifdef CONFIG_MODULE_SATEST
#include "satest_manager.h"
#endif // CONFIG_MODULE_SATEST


/* Private define ------------------------------------------------------------*/
#define LSM6DLS_PRI 0
#define INT_GPIO54 0
#define M4_ALGO 0
#define CONV_M2R 0

#define ACC_FUN   0
#define GYRO_FUN  0
#define MAG_FUN   1
#define TEMP_FUN  0
#define CAL_FUN   0
#define ALGO_FUN  0
#define ALGO_MAD  0
#define ALGO_MOTIONFX  0

#define MSG_FUN  1

#define NST112_ADDR   NST112_I2C_ADDR_SEC
#define MMC5983_ADDR  MMC5983_7BITI2C_ADDRESS
#define BMP5_ADDR     BMP5_I2C_ADDR_PRIM//SDO=0;->0x46; SDO=1;->0x47

#define CFG_COMPASS_PARAM "COMPASS_PARAM"
#define FX_STATE_SIZE 9
#define MAG_DRIFT 0
#define PRES_Pa  101325.0f

#define MFX_STR_LENG 35
#define STATE_SIZE (size_t)(128)
#define ENABLE_6X   0


#if(CONV_M2R)
static float Conv_ms2 = 0;					// 9.8m/s * ACC_SENSITIVITY_FS_2G / 1000
static float Conv_rads = 0;	
//static uint8_t angle_initsta=1;
#endif
//static lsm6dsv_filt_settling_mask_t filt_settling_mask;

#define CAL_PARAM 0

#if CAL_PARAM
static float acc_set[3];
static uint8_t cal_cnt;
static uint8_t cal_init=0;
#endif

// static uint8_t cal_gyrozero=0;
// static float gyro_zeroparam[3];
/* Private typedef -----------------------------------------------------------*/
// LSM6DSV_AxesRaw_t ism6dsv_axesraw;

/* 定义定时器结构体 */
struct k_timer compass_timer;
struct k_work sensor_algo_work;
struct device *lsm6d_dev = NULL;
struct k_delayed_work sensor_save_work;


void compass_param_send(void);
#if CONFIG_SENSOR_ALGO_ANGLE
struct cfg_compass_param_t{
    char calmagParam[4][4];//float ->char
  char iniAccuracy[4];  //int ->char
};

#endif
#if CONFIG_SENSOR_PRI_ACC_LSM6DSL
LSM6DSL_IO_t 	ism6dsl_i2c_bus;
LSM6DSL_Object_t	ism6dsl_obj;
#endif
#if CONFIG_SENSOR_PRI_ACC_LSM6DSV
LSM6DSV_IO_t 	ism6dsv_i2c_bus;
LSM6DSV_Object_t	ism6dsv_obj;
#endif
typedef struct{
  uint8_t state;//bit0:acc;bit1:gyro;bit2:mag;bit3:temp;bit4:baro;
  int16_t raw_acc[3];
  int16_t raw_gyro[3];
  float   mag[3];

  uint64_t bmp5_pres;
  int64_t  bmp5_temp;

  double temperature;

}sensor_rawdata_t;
sensor_rawdata_t sensor_data;
static uint8_t run_cnt;

/* Private variables ---------------------------------------------------------*/
#if CONFIG_SENSOR_PRI_BARO_BMP5
   int8_t bmp_init;
  struct bmp5_dev BMP5_dev;
  struct bmp5_osr_odr_press_config osr_odr_press_cfg = { 0 };
  static uint8_t dev_addr;
#endif
float acc_sensity=0,gyro_sensity=0;
//compass_mq_t compass_mq;
typedef struct
{     
  float slope;
  float yaw;
  float temperature;
  float altitude;
}sensor_msg_t;
sensor_msg_t sensor_param;
static uint8_t sensorfun_state;
/* Private function prototypes -----------------------------------------------*/	
/* Private application code begin --------------------------------------------*/
#if MSG_FUN

#if 0
  /* 创建消息队列 */
  K_MSGQ_DEFINE(sensorparam_msg, sizeof(sensor_msg_t), 10, 4);
  void sensor_param_put(sensor_msg_t *msg)
  {
    k_msgq_put(&sensorparam_msg, &sensor_param, K_FOREVER);
  }
  void sensor_param_get(sensor_msg_t *msg)
  {
    /* 从消息队列获取数据 */
    if (k_msgq_get(&sensorparam_msg, &sensor_param, K_MSEC(100)) == 0) {
        /* 使用接收到的数据 */
        //printk("Temperature: %d\n", received_data.temperature);
    }
  }
#else
/**
 * struct app_msg
{
	uint16_t sender;
	uint8_t type;
	uint8_t cmd;
	uint8_t reserve;
	uint8_t __pad[3];
	union {
		char content[MSG_CONTENT_SIZE];
		short short_content[MSG_CONTENT_SIZE / 2];
		int value;
		void *ptr;
	};
	MSG_CALLBAK callback;
	os_sem *sync_sem;
};
 */
#endif
void sensor_sync_msg_send(sensor_msg_t *sensormsg)
{
  struct app_msg msg; 
  sensor_msg_t *sensor = &sensor_param;
	
  sensor->yaw = sensormsg->yaw;
  sensor->altitude = sensormsg->altitude;
  sensor->temperature = sensormsg->temperature;
  
	
  msg.type = 0x23; /**MSG_SENSOR_EVENT*/
  msg.cmd = 0x92;  /**GSVC_MSG_LRF_GET_COMPASS */
  msg.ptr = sensor;

	send_async_msg("defaults", &msg);
}
#endif
#if 1
typedef struct{
	uint8_t state;
	double longitude;
	double latitude;
}gps_raw_t;
 gps_raw_t rawparam={2,35,35};

void upcoordinate_to_golf(gps_raw_t *param)
{
  struct app_msg msg;
	gps_raw_t *raw = &rawparam;
	

	raw->state = param->state;
	raw->longitude = param->longitude;
	raw->latitude = param->latitude;
printk("tom coor:%d,%f,%f\n",raw->state,raw->longitude,raw->latitude);
	//msg.type = 0x85;/**GOLF_MSG_GET_RAWCOOR */
	msg.type = MSG_INIT_APP;
	//msg.ptr = raw;
  send_async_msg("golf_service", &msg);
  //send_async_msg(GOLF_SERVICE_NAME1, &msg);
	//send_async_msg("golf_app", &msg);
}
#endif


void sensorfun_start_all(void)
{
//  sensorfun_state = SENSOR_FUN_ALL_OPEN;
  k_timer_start(&compass_timer, K_MSEC(10), K_MSEC(20));
}
void sensorfun_stop_all(void)
{
 // sensorfun_state = SENSORFUN_ALL_OFF;
  k_timer_stop(&compass_timer);
}
void sensorfun_start(uint8_t sensor_id)
{
  if(sensorfun_state == 0x00){
    sensorfun_state |= sensor_id;
    k_timer_start(&compass_timer, K_MSEC(10), K_MSEC(20));
  }else{
    sensorfun_state |= sensor_id;
  }
}
void sensorfun_stop(uint8_t sensor_id)
{
  sensorfun_state |= sensor_id;
  if(sensorfun_state == 0x00){
    k_timer_stop(&compass_timer);
  }
}
/**
 * @brief sensorfun check open or close
 * 
 * @param sensorfun_id 
 * @return uint8_t 1:open;0 close
 */
/*
static uint8_t sensorfun_check(uint8_t sensorfun_id)
{
  return (sensorfun_state & sensorfun_id);
}
*/

#if CONFIG_SENSOR_PRI_TEMP_NST112_DSTR

NST112_T nst112_dev;
int nst_i2c_read_func(uint8_t addr,uint8_t reg_addr, uint8_t *reg_data, uint32_t length)
{
  if(i2c_dev ==NULL) return -1;
  return sensor_normal_bus_i2c_read(i2c_dev,addr,reg_addr,1,reg_data,length);
}
int nst112_i2c_write_func(uint8_t addr,uint8_t reg_addr, uint8_t *reg_data, uint32_t length)
{
  if(i2c_dev ==NULL) return -1;
  return sensor_normal_bus_i2c_write(i2c_dev,addr, reg_addr, 1,reg_data, length);
}
void nst112_init(NST112_T *dev)
{
  dev->i2c_read_bytes = nst_i2c_read_func;
  dev->i2c_write_bytes = nst112_i2c_write_func;
  
}
#endif

#if CONFIG_SENSOR_PRI_BARO_BMP5
/*!
 * Delay function map to COINES platform
 */
void bmp5_delay_us(uint32_t period, void *intf_ptr)
{
    (void)intf_ptr;
    k_sleep(K_USEC(period));
}
/*!
 * I2C read function map to COINES platform
 */
BMP5_INTF_RET_TYPE bmp5_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t length, void *intf_ptr)
{
    //uint8_t device_addr = *(uint8_t*)intf_ptr;

    (void)intf_ptr;
    if(i2c_dev ==NULL) return -1;
    //return I2C_MultiRead_Reg(0X47,reg_addr,length,reg_data);
    return sensor_normal_bus_i2c_read(i2c_dev,0X47,reg_addr,1,reg_data,length);
  //return sensor_normal_bus_i2c_write(i2c_dev,0x47, reg_addr, 1,reg_data, length);
    //return coines_read_i2c(COINES_I2C_BUS_0, device_addr, reg_addr, reg_data, (uint16_t)length);
}

/*!
 * I2C write function map to COINES platform
 */
BMP5_INTF_RET_TYPE bmp5_i2c_write(uint8_t reg_addr, uint8_t *reg_data, uint32_t length, void *intf_ptr)
{
    //uint8_t device_addr = *(uint8_t*)intf_ptr;

    (void)intf_ptr;
    if(i2c_dev ==NULL) return -1;
    //sensor_normal_bus_i2c_write(i2c_dev,0x47,reg_addr,1,&reg_data,1);
  return sensor_normal_bus_i2c_write(i2c_dev,0x47, reg_addr, 1,reg_data, length);
    //return coines_write_i2c(COINES_I2C_BUS_0, device_addr, reg_addr, (uint8_t *)reg_data, (uint16_t)length);
}

 int8_t set_config(struct bmp5_osr_odr_press_config *osr_odr_press_cfg, struct bmp5_dev *dev)
{
    int8_t rslt;
    struct bmp5_iir_config set_iir_cfg;
    struct bmp5_int_source_select int_source_select;

    rslt = bmp5_set_power_mode(BMP5_POWERMODE_STANDBY, dev);
    if (rslt == BMP5_OK)
    {
        /* Get default odr */
        rslt = bmp5_get_osr_odr_press_config(osr_odr_press_cfg, dev);
        if (rslt == BMP5_OK)
        {
            /* Set ODR as 50Hz */
            osr_odr_press_cfg->odr = BMP5_ODR_50_HZ;

            /* Enable pressure */
            osr_odr_press_cfg->press_en = BMP5_ENABLE;

            /* Set Over-sampling rate with respect to odr */
            osr_odr_press_cfg->osr_t = BMP5_OVERSAMPLING_64X;
            osr_odr_press_cfg->osr_p = BMP5_OVERSAMPLING_4X;

            rslt = bmp5_set_osr_odr_press_config(osr_odr_press_cfg, dev);
        }

        if (rslt == BMP5_OK)
        {
            set_iir_cfg.set_iir_t = BMP5_IIR_FILTER_COEFF_1;
            set_iir_cfg.set_iir_p = BMP5_IIR_FILTER_COEFF_1;
            set_iir_cfg.shdw_set_iir_t = BMP5_ENABLE;
            set_iir_cfg.shdw_set_iir_p = BMP5_ENABLE;

            rslt = bmp5_set_iir_config(&set_iir_cfg, dev);
        }

        if (rslt == BMP5_OK)
        {
            rslt = bmp5_configure_interrupt(BMP5_PULSED, BMP5_ACTIVE_HIGH, BMP5_INTR_PUSH_PULL, BMP5_INTR_ENABLE, dev);
            if (rslt == BMP5_OK)
            {
                /* Note : Select INT_SOURCE after configuring interrupt */
                int_source_select.drdy_en = BMP5_ENABLE;
                rslt = bmp5_int_source_select(&int_source_select, dev);
            }
        }
        /* Set powermode as normal */
        rslt = bmp5_set_power_mode(BMP5_POWERMODE_NORMAL, dev);
    }
    return rslt;
}

/*!
 *  @brief Function to select the interface between SPI and I2C.
 */
int8_t bmp5_interface_init(struct bmp5_dev *bmp5_dev, uint8_t intf)
{
    int8_t rslt = BMP5_OK;
    //struct coines_board_info board_info;

    if (bmp5_dev != NULL)
    {
        /* Bus configuration : I2C */
        if (intf == BMP5_I2C_INTF)
        {
          dev_addr = BMP5_I2C_ADDR_PRIM;
          bmp5_dev->read = bmp5_i2c_read;
          bmp5_dev->write = bmp5_i2c_write;
          bmp5_dev->intf = BMP5_I2C_INTF;
        }
        /* Bus configuration : SPI */
        else if (intf == BMP5_SPI_INTF)
        {
          dev_addr = 0;
          bmp5_dev->read = NULL;
          bmp5_dev->write = NULL;
          bmp5_dev->intf = BMP5_SPI_INTF;
        }
        k_sleep(K_USEC(100));

        /* Holds the I2C device addr or SPI chip selection */
        bmp5_dev->intf_ptr = &dev_addr;

        /* Configure delay in microseconds */
        bmp5_dev->delay_us = bmp5_delay_us;
    }
    else
    {
        rslt = BMP5_E_NULL_PTR;
    }

    return rslt;
}
#endif

#if CONFIG_SENSOR_ALGO_ANGLE

 void sensor_property_save_work(struct k_work *work)
{
  //property_set(CFG_COMPASS_PARAM, cpParam, sizeof(struct compass_param));
}
#endif


#if CONFIG_SENSOR_PRI_ACC_LSM6DSV

int32_t BSP_I2CMT1_WriteReg(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length)
{
  // sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x10,1,buf,1);
	sensor_normal_bus_i2c_write(lsm6d_dev,DevAddr,Reg,1,pData,Length);
  //k_sleep(K_MSEC(10));
	return 0;
}
int32_t  BSP_I2CMT1_ReadReg(uint16_t DevAddr, uint16_t Reg, uint8_t *pData, uint16_t Length)
{
  //sensor_hal_read(0,Reg,pData,Length);
  //i2c_write_read(lsm6d_dev,DevAddr,Reg,1,pData,Length);
  sensor_normal_bus_i2c_read(lsm6d_dev,DevAddr,Reg,1,pData,Length);
	//drv_i2c_read(ism_i2c_obj,DevAddr,Reg,1,(uint8_t*)pData,Length);
    return 0;
}
#endif
void delay_ms(uint8_t ms)
{
  k_sleep(K_MSEC(ms));
}
/**
tom 6dl 0X10:50
tom 6dl 0X11:5c
tom 6dl 0X12:44
tom 6dl 0X13:00
tom 6dl 0X0A:00
tom 6dl 0X1E:04
 * 
 */
void sensor_param_init(void)
{
//  uint8_t buf[12];

//ACC+GYRO
#if CONFIG_SENSOR_PRI_ACC_LSM6DSL
		ism6dsl_i2c_bus.Init=NULL;
		ism6dsl_i2c_bus.DeInit=NULL;
		ism6dsl_i2c_bus.Address=LSM6DSL_I2C_ADD_H;
		ism6dsl_i2c_bus.BusType=0;
		ism6dsl_i2c_bus.ReadReg=BSP_I2CMT1_ReadReg;
		ism6dsl_i2c_bus.WriteReg=BSP_I2CMT1_WriteReg;
		ism6dsl_i2c_bus.Delay=NULL;
		ism6dsl_i2c_bus.GetTick=NULL;
		LSM6DSL_RegisterBusIO(&ism6dsl_obj,&ism6dsl_i2c_bus);
		/*启动加速计、陀螺仪*/
		LSM6DSL_Init(&ism6dsl_obj);
		LSM6DSL_ACC_Enable(&ism6dsl_obj);
		LSM6DSL_GYRO_Enable(&ism6dsl_obj);
		LSM6DSL_ACC_SetFullScale(&ism6dsl_obj,LSM6DSL_2g);
		LSM6DSL_ACC_SetOutputDataRate(&ism6dsl_obj,208.0f);
		LSM6DSL_GYRO_SetOutputDataRate(&ism6dsl_obj,208.0f);
		LSM6DSL_GYRO_SetFullScale(&ism6dsl_obj, 2000);
#endif
#if CONFIG_SENSOR_PRI_ACC_LSM6DSV
		ism6dsv_i2c_bus.Init=NULL;
		ism6dsv_i2c_bus.DeInit=NULL;
		ism6dsv_i2c_bus.Address=(LSM6DSV_I2C_ADD_H>>1);
		ism6dsv_i2c_bus.BusType=0;
		ism6dsv_i2c_bus.ReadReg=BSP_I2CMT1_ReadReg;
		ism6dsv_i2c_bus.WriteReg=BSP_I2CMT1_WriteReg;
		ism6dsv_i2c_bus.Delay=NULL;
		ism6dsv_i2c_bus.GetTick=NULL;
    buf[0]=1;
    // BSP_I2CMT1_WriteReg(LSM6DSV_I2C_ADD_H>>1,0x12,&buf[0],1);
    // k_sleep(K_MSEC(500));
		LSM6DSV_RegisterBusIO(&ism6dsv_obj,&ism6dsv_i2c_bus);
		/*启动加速计、陀螺仪*/
		LSM6DSV_Init(&ism6dsv_obj);
		LSM6DSV_ACC_Enable(&ism6dsv_obj);
		LSM6DSV_GYRO_Enable(&ism6dsv_obj);
		LSM6DSV_ACC_SetFullScale(&ism6dsv_obj,LSM6DSV_2g);
		LSM6DSV_ACC_SetOutputDataRate(&ism6dsv_obj,240.0f);
    LSM6DSV_GYRO_SetOutputDataRate(&ism6dsv_obj,240.0f);
		LSM6DSV_GYRO_SetFullScale(&ism6dsv_obj, LSM6DSV_2000dps);

    //LSM6DSV_GYRO_GetFullScale(&ism6dsv_obj,&gyro_tom);
    //printk("gyro scale:%d\n",gyro_tom);
    buf[0] = 0x04;
    BSP_I2CMT1_WriteReg(LSM6DSV_I2C_ADD_H>>1,0x15,&buf[0],1);
    k_sleep(K_MSEC(500));
    BSP_I2CMT1_ReadReg(LSM6DSV_I2C_ADD_H>>1,0x15,&buf[0],1);
    printk("tom set 0:%02x\n",buf[0]);

   buf[0] = 0x03;
    BSP_I2CMT1_WriteReg(LSM6DSV_I2C_ADD_H>>1,0x15,&buf[0],1);
    k_sleep(K_MSEC(500));
    BSP_I2CMT1_ReadReg(LSM6DSV_I2C_ADD_H>>1,0x15,&buf[0],1);
    printk("tom set 3:%02x\n",buf[0]);

#endif

#if(CONV_M2R)
    
    #if CONFIG_SENSOR_PRI_ACC_LSM6DSL
    LSM6DSL_ACC_GetSensitivity(&ism6dsl_obj,&acc_sensity);
		LSM6DSL_GYRO_GetSensitivity(&ism6dsl_obj,&gyro_sensity);
    #endif
    #if CONFIG_SENSOR_PRI_ACC_LSM6DSV
    LSM6DSV_ACC_GetSensitivity(&ism6dsv_obj,&acc_sensity);
		LSM6DSV_GYRO_GetSensitivity(&ism6dsv_obj,&gyro_sensity);
    #endif
// acc_sensity = 0.061;
// gyro_sensity = 70.0;
    printk("sensity-a-g:%f,%f\n",acc_sensity,gyro_sensity);
    Conv_ms2=acc_sensity*MS2_PARAMTER*1000.0f;
		Conv_rads=gyro_sensity*RADS_PARAMTER*1000.0f;
#endif
  /**MAG*/
  /**Temp*/
  #if CONFIG_SENSOR_PRI_TEMP_NST112_DSTR
  printk("nst112 init\n");
  nst112_init(&nst112_dev);
  nst112_config_reg(&nst112_dev,NST112_ADDR);
  #endif
  /**BARO*/
  #if CONFIG_SENSOR_PRI_BARO_BMP5
  bmp_init = bmp5_interface_init(&BMP5_dev, BMP5_I2C_INTF);
  if(bmp_init == BMP5_OK)
  {printk("tom bmp5 int ok\n");
    bmp_init = bmp5_init(&BMP5_dev);
    if(bmp_init == BMP5_OK){
      bmp_init = set_config(&osr_odr_press_cfg, &BMP5_dev);
      printk("tom bmp5 set config rslt:%d\n",bmp_init);
    }
  }
  #endif

#if 0
  //check reg
  //I2C_Read_Reg(0x47,0x01,&bmp_id);
  bmp5_i2c_read(0x01,&buf[0],1,NULL);
  printk("bmp 0x47:%02x\n",buf[0]);



  buf[0] = 0X03;
  BSP_I2CMT1_ReadReg(0x6b,0x0d,buf,12);
  for(uint8_t i=0;i<12;i++){
    printk("tom reg[%02x]:%02x\n",0x0d+i,buf[i]);
  }
#endif

}

void Algo_lib_init(void)
{
  //uint8_t data = MFX_QNUM_AXES;
  #if ALGO_FUN
    #if ALGO_MAD
      MadgwickAHRS_Init(20);
    #endif
    #if ALGO_MOTIONFX
        uint8_t motionfx_size=0;
        motionfx_size=MotionFX_GetStateSize();
        printk("tom motionfx size:%d\n",motionfx_size);
        // static uint8_t mfxstate_9x[FX_STATE_SIZE];
        // MotionFX_initialize((MFXState_t *)mfxstate_9x);
        //setup();
        //char lib_version[MFX_STR_LENG];
        //static uint8_t mfxstate[STATE_SIZE];
        //MFX_knobs_t iKnobs;
        //float LastTime;
      // data= MotionFX_GetStateSize();
      // printk("tom mation size:%d\n",data);
      // MotionFX_initialize((MFXState_t*)mfxstate);
        //MotionFX_GetLibVersion(lib_version);
        //printk("tom mation ver:%s\n",lib_version);
        // MotionFX_getKnobs(mfxstate,&iKnobs);
        // MotionFX_setKnobs(mfxstate,&iKnobs);
        // MotionFX_enable_6X(mfxstate,MFX_ENGINE_DISABLE);
        // MotionFX_enable_9X(mfxstate,MFX_ENGINE_DISABLE);
        // if(ENABLE_6X ==1){
        //   MotionFX_enable_6X(mfxstate,MFX_ENGINE_ENABLE);
        // }else{
        //   MotionFX_enable_9X(mfxstate,MFX_ENGINE_ENABLE);
        // }
    #endif
    #if CONFIG_LIB69D
      // compass_mq_t compass;
      // // sensor_data_t *sensordata = &data_in;
      // sensor_data_t sensordata; 
      //  memsic_compass_algorithm(&sensordata,&compass);
    #endif
  #endif
  

  printk("tom motionfx init ok\n");
}



/* 定时器到期时的回调函数 */
void compass_timer_handler(struct k_timer *timer_id)
{
  k_work_submit(&sensor_algo_work);
}

static void _sensor_algo_handler(struct k_work *work)
{

    //acc+gyro+mag //20ms
//  if(sensorfun_check(SENSORFUN_COMPASS))
  {
    // LSM6DSV_AxesRaw_t ism6dsv_acc;
    // LSM6DSV_AxesRaw_t ism6dsv_gyro;
    // LSM6DSV_Axes_t ism6dsv_acc;
    // LSM6DSV_Axes_t ism6dsv_gyro;

    // LSM6DSV_GYRO_Get_DRDY_Status(&ism6dsv_obj,&buf[0]);
  //    LSM6DSV_GYRO_GetAxesRaw(&ism6dsv_obj,&ism6dsv_gyro);
  //   printk("tom 6dl gyro:%d\n",buf[0]);
    // LSM6DSV_ACC_Get_DRDY_Status(&ism6dsv_obj,&buf[0]);
  //   printk("tom 6dl acc:%d\n",buf[0]);
  //   LSM6DSV_ACC_GetAxes(&ism6dsv_obj,&ism6dsv_acc);
  //   LSM6DSV_GYRO_GetAxes(&ism6dsv_obj,&ism6dsv_gyro);

   
  //   #if CONFIG_SENSOR_PRI_ACC_LSM6DSL
  //   lsm6dsv_status_reg_get(&ism6dsv_obj,&buf[0]);
  //   #endif
    #if 0
      uint8_t ism6d_state;
      BSP_I2CMT1_ReadReg(LSM6DSV_I2C_ADD_H>>1,0x1e,&ism6d_state,1);
      printk("tom lsm6d state:%02x\n",ism6d_state);
    #endif
    #if 0
    int16_t ism6d_temp=0;
    BSP_I2CMT1_ReadReg(LSM6DSV_I2C_ADD_H>>1,0x20,ism6d_raw,2);
    ism6d_temp = ism6d_raw[0] |ism6d_raw[1]<<8;
    printk("tom lsm6d temp:%d\n",ism6d_temp);
    #endif
    #if ACC_FUN
      #if 1
      BSP_I2CMT1_ReadReg(LSM6DSV_I2C_ADD_H>>1,0x22,ism6d_raw,6);
      for(uint8_t i=0;i<3;i++)
      sensor_data.raw_acc[i] = ism6d_raw[i*2] | ism6d_raw[i*2+1]<<8;
      #else
      LSM6DSV_ACC_GetAxesRaw(&ism6dsv_obj,&ism6dsv_axesraw);
      //printk("raw:%x,%x,%x\n",ism6dsv_axesraw.x,ism6dsv_axesraw.y,ism6dsv_axesraw.z);
      
      memcpy(sensor_data.raw_acc,&ism6dsv_axesraw,sizeof(LSM6DSV_AxesRaw_t));
      #endif
      sensor_data.state |=0x01;
      //printk("acc:%x,%x,%x\n",sensor_data.raw_acc[0],sensor_data.raw_acc[1],sensor_data.raw_acc[2]);
    #endif

    #if GYRO_FUN
      #if 1
        BSP_I2CMT1_ReadReg(LSM6DSV_I2C_ADD_H>>1,0x28,ism6d_raw,6);
        for(uint8_t i=0;i<3;i++)
          sensor_data.raw_gyro[i] = ism6d_raw[i*2] | ism6d_raw[i*2+1]<<8;
      #else
        memset(&ism6dsv_axesraw,0,sizeof(LSM6DSV_AxesRaw_t));
        LSM6DSV_GYRO_GetAxesRaw(&ism6dsv_obj,&ism6dsv_axesraw);
        //printk("raw:%02x,%02x,%02x\n",ism6dsv_axesraw.x,ism6dsv_axesraw.y,ism6dsv_axesraw.z);
        memcpy(sensor_data.raw_gyro,&ism6dsv_axesraw,sizeof(LSM6DSV_AxesRaw_t));
      #endif
      sensor_data.state |=0x02;
      //printk("gyro:%x,%x,%x\n",sensor_data.raw_gyro[0],sensor_data.raw_gyro[1],sensor_data.raw_gyro[2]);
    #endif

    #if MAG_FUN
    /**mag*/
    MMC5983_GetData(sensor_data.mag);
    sensor_data.state |=0x04;
    printk("mag:%f,%f,%f\n",sensor_data.mag[0],sensor_data.mag[1],sensor_data.mag[2]);
    #endif
  }
#if 0
  /**temp*/
  if(sensorfun_check(SENSORFUN_TEMP))
  {
    #if TEMP_FUN
      if(run_cnt%50 ==0){//1s
        sensor_data.temperature =0;
        nst112_read_temp(&nst112_dev,NST112_ADDR,TEMP_REG,&sensor_data.temperature);
        sensor_data.state |=0x08;
        //printk("\nnst temp:%f\n",sensor_data.raw_temp);
      }
    #endif
  }
  /**BARO */
  if(sensorfun_check(SENSORFUN_BARO))
  {
    #if BARO_FUN
      if(run_cnt %20 ==0){  //0.5s
        #if CONFIG_SENSOR_PRI_BARO_BMP5
          uint8_t int_status;
          struct bmp5_sensor_data bmp_data;
          //if(bmp_init)
          {
            bmp5_get_interrupt_status(&int_status, &BMP5_dev);
            //printk("bmp get status:%d\n",int_status);
            if (int_status & BMP5_INT_ASSERTED_DRDY)
            {
              bmp5_get_sensor_data(&bmp_data, &osr_odr_press_cfg, &BMP5_dev);
              sensor_data.bmp5_pres =bmp_data.pressure;
              sensor_data.bmp5_temp =bmp_data.temperature;
              // float altitude=0;
              // if(bmp_data.pressure<PRES_Pa) {
              //   altitude = (PRES_Pa -bmp_data.pressure)/16.5;
              // }

              sensor_data.state |=0x10;
              //printk("bmp: %f(hPa), %f(°),%f(m)\n", sensor_data.pressure/100.0f, sensor_data.temperature,altitude);
              //h=[((P0/P)(1/5.257)−1)×(T+273.15)]/0.0065
              // // Convert pressure from Pa to hPa (1 hPa = 100 Pa)
              // float pressure_hPa = data.pressure / 100.0;
              // // Calculate altitude using simplified formula
              // float altitude = (1013.25 - pressure_hPa) / 16.5 * 100; 
            }
          }
        #endif
      }
    #endif
  }
#endif


  if(sensor_data.state & 0x07){//acc+gyro+mag
    float cal_data[9];
    #if ACC_FUN /**acc */
      #if 0
        cal_data[3] = (float)sensor_data.raw_acc[0]*acc_sensity/1000.0f;
        cal_data[4] = (float)sensor_data.raw_acc[1]*acc_sensity/1000.0f;
        cal_data[5] = (float)sensor_data.raw_acc[2]*acc_sensity/1000.0f;
      #else
        cal_data[3] = (float)sensor_data.raw_acc[0] /acc_sensity*9.80f;
        cal_data[4] = (float)sensor_data.raw_acc[1] /acc_sensity*9.80f;
        cal_data[5] = (float)sensor_data.raw_acc[2] /acc_sensity*9.80f;
      #endif
      //printk("cal acc:%f,%f,%f\n",cal_data[3],cal_data[4],cal_data[5]);
    #endif

    #if GYRO_FUN  /**gyro */
      #if 0
        cal_data[0] = (float)sensor_data.raw_gyro[0] *gyro_sensity*3.1415927f/180.0F/1000.0F;
        cal_data[1] = (float)sensor_data.raw_gyro[1] *gyro_sensity*3.1415927f/180.0F/1000.0F;
        cal_data[2] = (float)sensor_data.raw_gyro[2] *gyro_sensity*3.1415927f/180.0F/1000.0F;
      #else
        cal_data[0] = (float)sensor_data.raw_gyro[0] /gyro_sensity*3.1415927f  / 180.0f;
        cal_data[1] = (float)sensor_data.raw_gyro[1] /gyro_sensity*3.1415927f  / 180.0f;
        cal_data[2] = (float)sensor_data.raw_gyro[2] /gyro_sensity*3.1415927f  / 180.0f;
      #endif
      printk("cal gyro:%f,%f,%f\n",cal_data[0],cal_data[1],cal_data[2]);
    #endif

    #if MAG_FUN /**mag */
      cal_data[6] = sensor_data.mag[0] /1.0f;
      cal_data[7] = sensor_data.mag[1] /1.0f;
      cal_data[8] = sensor_data.mag[2] /1.0f;
    #endif

    #if CAL_FUN
      #if 0
       // cal zero
        sensor_id.mag_id = MMC5983_ID;
        sensor_id.accgyro_id = ISM6DSL_ID;

        cal_gyro_zero(&data_in);
        printk("algo:%f,%f,%f\n",data_in.gyro[0],data_in.gyro[1],data_in.gyro[2]);
      #endif

      #if CAL_PARAM
        // if(!cal_init){
        //    cal_init=Average_cal_zeroparam(&cal_cnt,10,data_in.acc,acc_set);
        //    printk("cal cnt:%d,%d\n",cal_init,cal_cnt);
        // }

        // data_in.acc[0] -=acc_set[0];
        // data_in.acc[1] -=acc_set[1];
        // data_in.acc[2] -=acc_set[2];  
        // printk("cal-acc:%.6f,%.6f,%.6f\n",data_in.acc[0],data_in.acc[1],data_in.acc[2]);
        // printk("cal-gyr:%.6f,%.6f,%.6f\n",data_in.gyro[0],data_in.gyro[1],data_in.gyro[2]);
        // printk("cal-mag:%.6f,%.6f,%.6f\n",data_in.mag[0],data_in.mag[1],data_in.mag[2]);
      #endif
    #endif

    #if ALGO_FUN
      #if 0
        axis_convert(&data_in,&sensor_id);
        //angle cvt
        if(angle_initsta){
        angle_initsta=algorithm_angle_init(data_in.acc);
        }
        algorithm_angle_update(data_in.acc);
        printk("angle:%f\n",get_angle());
      #endif
      #if ALGO_MAD
        #if 1    
   //       MadgwickAHRSupdate(cal_data[0],cal_data[1],cal_data[2],
    //      cal_data[3],cal_data[4],cal_data[5],
     //     cal_data[6],cal_data[7],cal_data[8]);
        #else
          MadgwickAHRSupdateIMU(cal_data[0],cal_data[1],cal_data[2],
          cal_data[3],cal_data[4],cal_data[5]);
        #endif
        #if 0
          //MadgwickAHRSupdateIMU(0,0,0,0,0,2);
          compass_mq.roll = Madgwick_getRoll();
          compass_mq.pitch = Madgwick_getPitch();
          compass_mq.yaw  = Madgwick_getYaw();
          
        #endif
//          sensor_param.slope = tan(compass_mq.pitch);
 //         sensor_param.yaw = compass_mq.yaw;
  //      printk("Roll-Pitch-Yaw-slop:%f,%f,%f,%f\n",compass_mq.roll,compass_mq.pitch,compass_mq.yaw,sensor_param.slope);
      #endif
      #if ALGO_MOTIONFX
        #if 0
          MotionFX_manager_MagCal_start(ALGO_PERIOD);
          mag_data_in.time_stamp = (int)TimeStamp;
          TimeStamp += (uint32_t)ALGO_PERIOD;
          MotionFX_manager_MagCal_run(&mag_data_in, &mag_data_out);
          if (mag_data_out.cal_quality == MFX_MAGCALGOOD)
          {
          MagCalStatus = 1;

          ans_float = (mag_data_out.hi_bias[0] * FROM_UT50_TO_MGAUSS);
          MagOffset.x = (int32_t)ans_float;
          ans_float = (mag_data_out.hi_bias[1] * FROM_UT50_TO_MGAUSS);
          MagOffset.y = (int32_t)ans_float;
          ans_float = (mag_data_out.hi_bias[2] * FROM_UT50_TO_MGAUSS);
          MagOffset.z = (int32_t)ans_float;

          /* Disable magnetometer calibration */
          MotionFX_manager_MagCal_stop(ALGO_PERIOD);
          }
          printk("\n[mag]:%.6f,%.6f,%.6f\n",mag_data_in.mag[0],mag_data_in.mag[1],mag_data_in.mag[2]);
        #endif
      #endif
    #endif
  }

  if(sensor_data.state & 0x08){//temperature
    #if TEMP_FUN
      sensor_data.temperature /= 1.0f;
      printk("tom temp:%f\n",sensor_data.temperature);
      sensor_param.temperature = sensor_data.temperature;
    #endif
    
  }
  if(sensor_data.state & 0x10){//baro
    #if BRAO_FUN
      float altitude=0;
      if(sensor_data.bmp5_pres<PRES_Pa) {
        altitude = (PRES_Pa -sensor_data.bmp5_pres)/16.5;
        sensor_param.altitude = altitude;
        printk("tom altitude:%f\n",altitude);
      }
    #endif
  }
  /**send param */
  {
    if(run_cnt%100==0){
          sensor_sync_msg_send(&sensor_param);
        printk("tom send \ncompass param:%f\naltitude:%f\ntemp:%f\n\n",
        sensor_param.yaw,sensor_param.altitude,sensor_param.temperature);
    }
  

      #ifdef CONFIG_MODULE_SATEST
      if(run_cnt%100==0){
        rawparam.state=1;
        rawparam.longitude=233.0;
        rawparam.latitude=233.0;
        printk("sensor cal send gps test\n");
        upcoordinate_to_golf(&rawparam);
      }
      if(run_cnt%50==0){
        //golf_send_msg(0,0,0,0);
          test_send_msg(0,0,0,0);
      }
      
      #endif
      run_cnt++;
  }
}
uint8_t sensor_cal_zero(uint8_t sensor_id)
{

  return 0;
}


#if(INT_GPIO54)
#define GPIO_PIN 54  // 目标引脚号
struct device *gpio_dev = NULL;
struct gpio_callback gpio_cb;

// 定义中断回调函数
static void gpio_callback(const struct device *dev, struct gpio_callback *cb, uint32_t pins)
{
    // 检测是否是目标引脚触发
    if(gpio_pin_get(gpio_dev, GPIO_PIN%32)) {
        printk("GPIO %d 中断触发!\n",GPIO_PIN);
        // 此处添加中断处理逻辑
    }else printk("tom gpio 54 set\n");
}



#endif

#if CONFIG_SENSOR_ALGO_ANGLE
void algo_angle_init(void)
{
  //MemsicCal_init(0.02f);

}
#endif
int sensor_port_init(const struct device *dev)
{
  
  ARG_UNUSED(dev);

  i2c_dev = (struct device*)device_get_binding(CONFIG_I2C_3_NAME);
	if (!i2c_dev) {
		printk("[i2c3] get device failed!");
	}
  k_sleep(K_MSEC(500));
	unsigned char mmc_id = 0;
	/* Read reg 0x2F, check product ID, default value is 0x30 */
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_PRODUCTID1, &mmc_id);
  printk("tom sensor mmc:%02x\n",mmc_id);
  if(MMC5983_Enable()==true){
    printk("MMC5983 Enable ok\n");
  }
   //k_sleep(K_MSEC(500));
  //sensor_hal_enable(0);

  //setup();
//MotionFX_GetStateSize();
 // MadgwickAHRS_Init(200);


  #if(INT_GPIO54)
  //GPS_WAKEUP_MCU	
	gpio_dev = (struct device *)device_get_binding(CONFIG_GPIO_PIN2NAME(GPIO_PIN));
	if(gpio_dev != NULL)
	printk("GPS WAKEUP mcu init success\n");
	gpio_pin_configure(gpio_dev , GPIO_PIN%32, GPIO_INPUT | GPIO_INT_DEBOUNCE);
	gpio_pin_interrupt_configure(gpio_dev, GPIO_PIN%32, (GPIO_INT_EDGE_TO_ACTIVE));
	gpio_pin_interrupt_configure(gpio_dev, GPIO_PIN%32, (GPIO_INT_EDGE_TO_ACTIVE));
	gpio_init_callback(&gpio_cb , gpio_callback, BIT(GPIO_PIN%32));
	gpio_add_callback(gpio_dev , &gpio_cb); 
  #endif

  #if CONFIG_SENSOR_ALGO_ANGLE
  algo_angle_init();
  #endif

#if(LSM6DLS_PRI)
#if CONFIG_SENSOR_PRI_ACC_LSM6DSL ||CONFIG_SENSOR_PRI_ACC_LSM6DSV
    lsm6d_dev = (struct device*)device_get_binding(CONFIG_I2CMT_1_NAME);
	if (!lsm6d_dev) {
		printk("[i2c3] get device failed!");
	}
#endif


  uint8_t chip_id=0;
  uint8_t reg_add=0x0f;
//i2c_write_read(lsm6d_dev,0x6b,&reg_add,1,&chip_id,1);
sensor_normal_bus_i2c_read(lsm6d_dev,0x6b,reg_add,1,&chip_id,1);
printk("tom 6d id:%02x\n",chip_id);

uint8_t reg_data=0x64;
sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x12,1,&reg_data,1);

reg_data=0x0;
sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x0a,1,&reg_data,1);

reg_data=0x42;
sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x10,1,&reg_data,1);

reg_data=0x4c;
sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x11,1,&reg_data,1);


reg_data=0x00;
sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x17,1,&reg_data,1);

reg_data=0x03;
sensor_normal_bus_i2c_write(lsm6d_dev,0x6b,0x0d,1,&reg_data,1);
#endif


  sensor_param_init();
  Algo_lib_init();


  k_timer_init(&compass_timer, compass_timer_handler, NULL);
  k_work_init(&sensor_algo_work, _sensor_algo_handler);
  //k_delayed_work_init(&sensor_save_work, sensor_property_save_work);
  sensorfun_start_all();
  //k_timer_start(&compass_timer, K_MSEC(5000), K_MSEC(20));

  return 0;
}


//SYS_INIT(sensor_port_init, APPLICATION, CONFIG_APPLICATION_INIT_PRIORITY);


/* Private application code end ----------------------------------------------*/
/*********** (C) Copyright 2024 IBE Technology Co., Ltd. *****END OF FILE****/
#endif

void mmc5983_init(void)
{
//	const struct device *i2c_dev = NULL;
  i2c_dev = (struct device*)device_get_binding(CONFIG_I2C_3_NAME);
	if (!i2c_dev) {
		printk("[i2c3] get device failed!");
	}
  k_sleep(K_MSEC(500));
	unsigned char mmc_id = 0;
	/* Read reg 0x2F, check product ID, default value is 0x30 */
	I2C_Read_Reg(MMC5983_7BITI2C_ADDRESS, MMC5983_REG_PRODUCTID1, &mmc_id);
  printk("tom sensor mmc:%02x\n",mmc_id);
  if(MMC5983_Enable()==true){
    printk("MMC5983 Enable ok\n");
  }
  k_sleep(K_MSEC(500));
  float mag[3] = { 0.0f };
  MMC5983_GetData(mag);
  printk("mmc5983 mag: %f %f %f\n", mag[0], mag[1], mag[2]);
}

