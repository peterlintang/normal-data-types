/*****************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software is protected by Copyright and the information and source code
 *  contained herein is confidential. The software including the source code
 *  may not be copied and the information contained herein may not be used or
 *  disclosed except with the written permission of MEMSIC Inc. (C) 2019
 *****************************************************************************/

/**
 * @brief
 * This file implement magnetic sensor driver APIs. 
 * Modified history: 
 * V1.1: Add the interrupt function on 20190109
 */
 
#ifndef _MMC5983_H
#define _MMC5983_H 

typedef   signed char  int8_t; 		// signed 8-bit number    (-128 to +127)
typedef unsigned char  uint8_t; 	// unsigned 8-bit number  (+0 to +255)
typedef   signed short int16_t; 	// signed 16-bt number    (-32768 to +32767)
typedef unsigned short uint16_t; 	// unsigned 16-bit number (+0 to +65535)
typedef   signed int   int32_t; 	// signed 32-bt number    (-2,147,483,648 to +2,147,483,647)
typedef unsigned int   uint32_t; 	// unsigned 32-bit number (+0 to +4,294,967,295)

#define MMC5983_7BITI2C_ADDRESS		0x30

#define MMC5983_PRODUCT_ID			0x30

#define MMC5983_REG_DATA			0x00
#define MMC5983_REG_TEMP			0x07
#define MMC5983_REG_STATUS			0x08
#define MMC5983_REG_CTRL0			0x09
#define MMC5983_REG_CTRL1			0x0A
#define MMC5983_REG_CTRL2			0x0B
#define MMC5983_REG_CTRL3			0x0C
#define MMC5983_REG_PRODUCTID1		0x2F

/* Bit definition for status register 0x08 */
#define MMC5983_MM_DONE				0x01
#define MMC5983_MT_DONE				0x02
#define MMC5983_OTP_READ_DONE		0x10

/* Bit definition for control register 0 0x09 */
#define MMC5983_CMD_TMM				0x01
#define MMC5983_CMD_TMT         	0x02
#define MMC5983_CMD_INT_MD_EN		0x04
#define MMC5983_CMD_SET				0x08
#define MMC5983_CMD_RESET			0x10
#define MMC5983_CMD_AUTO_SR_EN		0x20
#define MMC5983_CMD_OTP_READ		0x40

/* Bit definition for control register 1 0x0A */
#define MMC5983_CMD_BW00			0x00
#define MMC5983_CMD_BW01			0x01
#define MMC5983_CMD_BW10			0x02
#define MMC5983_CMD_BW11			0x03
#define MMC5983_CMD_X_INHIBIT		0x04
#define MMC5983_CMD_Y_INHIBIT		0x08
#define MMC5983_CMD_Z_INHIBIT		0x10
#define MMC5983_CMD_SW_RST			0x80

/* Bit definition for control register 2 0x0B */
#define MMC5983_CMD_CM_FREQ_OFF		0x00
#define MMC5983_CMD_CM_FREQ_1HZ		0x01
#define MMC5983_CMD_CM_FREQ_10HZ	0x02
#define MMC5983_CMD_CM_FREQ_20HZ	0x03
#define MMC5983_CMD_CM_FREQ_50HZ	0x04
#define MMC5983_CMD_CM_FREQ_100HZ	0x05
#define MMC5983_CMD_CM_FREQ_200HZ	0x06
#define MMC5983_CMD_CM_FREQ_1000HZ	0x07
#define MMC5983_CMD_CMM_EN			0x08

#define MMC5983_CMD_PART_SET1		0x00
#define MMC5983_CMD_PART_SET25		0x10
#define MMC5983_CMD_PART_SET75		0x20
#define MMC5983_CMD_PART_SET100		0x30
#define MMC5983_CMD_PART_SET250		0x40
#define MMC5983_CMD_PART_SET500		0x50
#define MMC5983_CMD_PART_SET1000	0x60
#define MMC5983_CMD_PART_SET2000	0x70
#define MMC5983_CMD_EN_PART_SET		0x80

//18-bit mode, null field output (32768)
#define	MMC5983_16BIT_OFFSET		32768
#define	MMC5983_16BIT_SENSITIVITY	4096

#define	MMC5983_18BIT_OFFSET		131072
#define	MMC5983_18BIT_SENSITIVITY	16384

#define MMC5983_T_ZERO				(-75)
#define MMC5983_T_SENSITIVITY		(0.8)	

/**
 * @brief Enable the sensor
 */
int MMC5983_Enable(void);

/**
 * @brief Disable the sensor
 */
void MMC5983_Disable(void);

/**
 * @brief Get sensor data
 * @param mag_out is the magnetic field vector, unit is gauss
 */
void MMC5983_GetData(float *mag_out);

int MMC5983_Check_ID(void);

typedef struct {
    void (*Delay_Us)(int cnt);
    int (*mmc_read_reg)(unsigned char mmc_add,unsigned char reg_add,unsigned char *data);
    int (*i2c_MultiRead_Reg)(unsigned char i2c_add,unsigned reg_add,int num,unsigned char *data);
    int (*I2C_Write_Reg)(uint8_t sal_addr,uint8_t reg,uint8_t reg_data);
}mmc_fun_t;
typedef struct {
    struct device *dev;
    mmc_fun_t fun;
}mmc_dev_t;


#endif

