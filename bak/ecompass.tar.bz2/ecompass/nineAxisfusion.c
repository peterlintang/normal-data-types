

#include "nineAxisfusion.h"
#include <stdint.h>
#include <stdio.h>

#define HRS_NOTIFY 0
#define MY_PI (3.14159265358979f)

extern void MahonyAHRSinit(float q[4]);
extern void quater2euler(float euler[3], float quater[4]);
extern void MahonyAHRSupdate(float q[4], float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz) ;
extern float mx_offset,my_offset,mz_offset;
extern float mx_k_ratio,my_k_ratio,mz_k_ratio;
extern float M_L;
extern float M_L_DIFF;

static int calibrate_status = 0;  // 0 not calibrate, 1 calibrate ok
static int start_flag = 0;    // 0 not need start calibrate, 1 immediate calibrate
static int auto_calibrate_flag = 0;  // 0 not auto calibrate, 1 while check *** auto start calibrate
static float quatern[4] = { 1.0f, 0.0f, 0.0f, 0.0f };

int nineAxisFusion_init(param_t *param)
{
  mag_calibration_init(); 
  mx_offset = param->param[0];
  my_offset = param->param[1];
  mz_offset = param->param[2];
  mx_k_ratio = param->param[3];
  my_k_ratio = param->param[4];
  mz_k_ratio = param->param[5];
  M_L = param->param[6];
  M_L_DIFF = param->param[7];
  calibrate_status = (int)param->param[8];
  start_flag = param->start;
  printf("%s: status %d, start: %d, auto: %d\n", __func__, calibrate_status, param->start, param->auto_calibrate);
  if (start_flag == 1)
    calibrate_status = 0;
  auto_calibrate_flag = param->auto_calibrate;
  MahonyAHRSinit(quatern);
  return 0;
}

int nineAxisFusion_process(float gry[3],
    float acc[3], 
    float mag[3], 
    float attitude[3])
{

  uint8_t res=0;
  float inAcc[3];
  float outAcc[3];
  float inGry[3];
  float outGry[3];
  float inMag[3];
  float outMag[3];
  float euler[3] = { 0 };

  inAcc[0] = (acc[0] ) ;
  inAcc[1] = -(acc[1] );
  inAcc[2] = (acc[2] ) ;
  for (int i = 0; i < 3; i++)
  {
    outAcc[i] = inAcc[i] / 1000.0f * 9.8f;
  }

  inGry[0] = -gry[0];
  inGry[1] = gry[1] ;
  inGry[2] = -gry[2];
  for (int i = 0; i < 3; i++)
  {
    outGry[i] = inGry[i] / 1000.0f * MY_PI / 180.0f;
  }

  inMag[0] = mag[0];
  inMag[1] = mag[1];
  inMag[2] = mag[2];
  for (int i = 0; i < 3; i++)
  {
    outMag[i] = 1000 * inMag[i];
  }

//  printf("start_flag: %d, auto_flag: %d, status: %d\n", start_flag, auto_calibrate_flag, calibrate_status );
  if (start_flag)
  {
    res = mag_calculate(outMag);  
    if (res == 1)
    {
      start_flag = 0;
      calibrate_status = 1;
    }
    else if (res == 0)
    {
    /*  printf("cal fail\n"); */
      mag_calibration_init();
      calibrate_status = 0;
    }
  }
  get_calibrat_mag_data(outMag);

  static int count = 0;
  if (count++ % 100 == 0)
  {
#if HRS_NOTIFY
    extern int bt_hrs_notify(uint8_t *data, uint16_t len);
#endif
    int len = 0;
    char data[128] = { 0 };
    float L = sqrtf(outMag[0] * outMag[0] + outMag[1] * outMag[1] + outMag[2] * outMag[2]);
    len = snprintf(data, 128, "mag value: %.8f\n", 
          L);
    printf("%s", data);
#if HRS_NOTIFY
    bt_hrs_notify(data, len);
#endif
  }

  if (auto_calibrate_flag && (start_flag == 0))
  {
    float L = sqrtf(outMag[0] * outMag[0] + outMag[1] * outMag[1] + outMag[2] * outMag[2]);
    if (fabsf(L-M_L) > 50.0f)
    {
      printf("auto restart calibrate %f %f %f\n", L, M_L, L-M_L);
      start_flag = 1;
      mag_calibration_init(); 
      calibrate_status = 0;
    }
    if (calibrate_status == 1)
    {
      if (M_L_DIFF < 10.0f)
      {
      //  printf("3 do nothing\n");
      }
      else if (M_L_DIFF < 32.0f)
      {
        printf("2 restart calibrate\n");
        start_flag = 1;
        mag_calibration_init(); 
//        calibrate_status = 0;
      }
      else
      {
        printf("1 restart calibrate\n");
        start_flag = 1;
        mag_calibration_init(); 
//        calibrate_status = 0;
      }
    }
  }

  MahonyAHRSupdate(quatern, outGry[0], outGry[1], outGry[2], outAcc[0], outAcc[1], outAcc[2], outMag[1], outMag[0], outMag[2]) ;

  quater2euler(euler, quatern);

  attitude[0] = euler[0] * 180 / MY_PI;
  attitude[1] = euler[1] * 180 / MY_PI;
  attitude[2] = euler[2] * 180 / MY_PI > 0.0f ? euler[2] * 180 / MY_PI : 360 + euler[2] * 180 / MY_PI;

  return 0;
}

int nineAxisFusion_getAccuracy(void)
{
  if (calibrate_status == 1)
  {
    if (M_L_DIFF < 10.0f)
      return 3;
    else if (M_L_DIFF < 32.0f)
      return 2;
    else
      return 1;
  }
  else if (calibrate_status == 0)
  {
    return 0;
  }
  return 0;
}

int nineAxisFusion_getCalibrationParam(float param[9])
{
  float par[6] = { 0.0 };
  get_calibration_parameter(par);
  param[0] = par[0];
  param[1] = par[1];
  param[2] = par[2];
  param[3] = par[3];
  param[4] = par[4];
  param[5] = par[5];
  param[6] = M_L;
  param[7] = M_L_DIFF;
  param[8] = (float)calibrate_status;
  return 0;
}

int nineAxisFusion_deinit(void)
{
  return 0;
}



