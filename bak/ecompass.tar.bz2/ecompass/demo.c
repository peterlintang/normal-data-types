

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "nineAxisfusion.h"
#include <fs/fs.h>
#include <fs/fs_sys.h>
#include <fs_manager.h>
#include <drivers/rtc.h> // for rtc
#include <stdio.h>

#define MDEBUG_2 1
#define HRS_NOTIFY 1

#if HRS_NOTIFY
extern int bt_hrs_notify(uint8_t *data, uint16_t len);
#endif
extern void lsm6dsv_read_gry_data(float *gry);
extern void lsm6dsv_read_acc_data(float *acc);
extern void MMC5983_GetData(float *mag_out);
extern void MMC5983_Disable(void);
extern void mmc5983_init(void);
extern void lsm6dsv_init(void);
extern void lsm6dsv_deinit(void);

static int calibration_flag = 0;
static int mag_flag = 0;
static struct k_timer imu_timer;
static K_SEM_DEFINE(imu_sem, 0, 1);
static k_tid_t ecompass_tid = NULL;
static K_THREAD_STACK_DEFINE(ecompass_thread_stack, 8192);
static struct k_thread ecompass_thread_data;

static void imu_timer_handler(struct k_timer *timer)
{
  k_sem_give(&imu_sem);
}


static void mag_calibration_test(void *p1, void *p2, void *p3)
{
  float attitude[3] = { 0.0 };
  float gry[3] = { 0.0 };
  float acc[3] = { 0.0 };
  float mag[3]={0};

  mmc5983_init();
  lsm6dsv_init();

  k_timer_init(&imu_timer,
                        imu_timer_handler,
                        NULL);
  k_timer_start(&imu_timer,
      K_MSEC(10),
      K_MSEC(10)
      );


  mag_flag = 1;
  calibration_flag = 0;
  printf("%s: mag calibration test\n", __func__);

  param_t param;
  float params[9] = { 0.0 };

  struct fs_file_t zfp;
  memset(&zfp, 0, sizeof(zfp));
  if (fs_open(&zfp, "/SD:/x4_mag_calibration.txt", FA_READ))
  {
    printf("open config failed\n");
    param.param[0] = 0.0f;
    param.param[1] = 0.0f;
    param.param[2] = 0.0f;
    param.param[3] = 1.0f;
    param.param[4] = 1.0f;
    param.param[5] = 1.0f;
    param.param[6] = 399.0f;
    param.param[7] = 0.0f;
    param.param[8] = 0.0f;
    param.start = 1;
    param.auto_calibrate = 1;
  }
  else
  {
    char my_tmp[128] = { 0 };
    int my_tmp_ret = 0;
    my_tmp_ret = fs_read(&zfp, my_tmp, 128);
    sscanf(my_tmp, "%f %f %f %f %f %f %f %f %f\n", 
        &params[0],
        &params[1],
        &params[2],
        &params[3],
        &params[4],
        &params[5],
        &params[6],
        &params[7],
        &params[8]
        );
    param.param[0] = params[0];
    param.param[1] = params[1];
    param.param[2] = params[2];
    param.param[3] = params[3];
    param.param[4] = params[4];
    param.param[5] = params[5];
    param.param[6] = params[6];
    param.param[7] = params[7];
    param.param[8] = params[8];
    param.start = 1;
    param.auto_calibrate = 1;
    fs_close(&zfp);
  }
  int len = 0;
  char data[128] = { 0 };
  len = snprintf(data, 128, "conf: %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %d %d\n", 
    param.param[0],
    param.param[1],
    param.param[2],
    param.param[3],
    param.param[4],
    param.param[5],
    param.param[6],
    param.param[7],
    param.param[8],
    param.start,
    param.auto_calibrate
    );
  printf("%s", data);
#if HRS_NOTIFY
  bt_hrs_notify(data, len);  
#endif

  nineAxisFusion_init(&param);

  for (int i = 0; i < 2; i++)
  {
    lsm6dsv_read_gry_data(gry);
    lsm6dsv_read_acc_data(acc);
    MMC5983_GetData(mag);
  }

#if MDEBUG_2
  char file_name[64] = { 0 };
  struct rtc_time rtc_time;
  struct rtc_time *tm = &rtc_time;
  const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);
  rtc_get_time(rtc, &rtc_time);

  snprintf(file_name, 64, "/SD:/magrawdata_%04d%02d%02d_%02d%02d%02d.txt",
                        1900 + tm->tm_year, tm->tm_mon + 1, tm->tm_mday,
                        tm->tm_hour, tm->tm_min, tm->tm_sec);

  struct fs_file_t dzfp;
  memset(&dzfp, 0, sizeof(dzfp));
  if (fs_open(&dzfp, file_name, FA_READ | FA_WRITE | FS_O_CREATE))
  {
    printf("open %s failed\n", file_name);
  }
#endif

  while (mag_flag)
  {
    k_sem_take(&imu_sem, K_FOREVER);
    lsm6dsv_read_gry_data(gry);
    lsm6dsv_read_acc_data(acc);
    MMC5983_GetData(mag);

#if MDEBUG_2
    char my_tmp[128] = { 0 };
    int my_tmp_ret = 0;
    my_tmp_ret = snprintf(my_tmp, 128, "%.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f\n", 
        mag[0],
        mag[1],
        mag[2],
	gry[0],
	gry[1],
	gry[2],
	acc[0],
	acc[1],
	acc[2]
        );
    fs_write(&dzfp, my_tmp, my_tmp_ret);
#endif

    nineAxisFusion_process(gry,
        acc, 
        mag, 
        attitude);

static int count = 0;

if (count++ % 100 == 0)
{
  uint8_t to_send[128] = { 0 };
  uint16_t to_send_len = 0;
  float params[9] = { 0.0 };
  int ret = 0;
  nineAxisFusion_getCalibrationParam(params);
  ret = nineAxisFusion_getAccuracy();
  if (ret == 3)
  {
    if (calibration_flag == 0)
    {
      calibration_flag = 1;

    struct fs_file_t zfp;
    memset(&zfp, 0, sizeof(zfp));
    if (fs_open(&zfp, "/SD:/x4_mag_calibration.txt", FA_READ | FA_WRITE | FS_O_CREATE))
    {
      printf("open %s failed\n", "x4_mag_calibration");
    }
    char my_tmp[128] = { 0 };
    int my_tmp_ret = 0;
    my_tmp_ret = snprintf(my_tmp, 128, "%.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f\n", 
        params[0],
        params[1],
        params[2],
        params[3],
        params[4],
        params[5],
        params[6],
        params[7],
        params[8]
        );
    fs_write(&zfp, my_tmp, my_tmp_ret);
    fs_close(&zfp);

    }

    /*
     * save params to flash
     */
  }
  to_send_len = snprintf(to_send, 128, "%d %4.0f %4.0f %4.0f\n",
        ret,
                                attitude[0],
                                attitude[1],
                                attitude[2]
        );
#if HRS_NOTIFY
        bt_hrs_notify(to_send, to_send_len);
#endif
#if MDEBUG_2
  printf("%s\n", to_send);
  to_send_len = snprintf(to_send, 128, "%.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.0f\n",
        params[0],
        params[1],
        params[2],
        params[3],
        params[4],
        params[5],
        params[6],
        params[7],
        params[8]
        );
  /*
        bt_hrs_notify(to_send, to_send_len);
  */
  printf("%s\n", to_send);
  printf("aaa: %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f\natt: %.3f %.3f %.3f\n",
      gry[0],
      gry[1],
      gry[2],
      acc[0],
      acc[1],
      acc[2],
      mag[0],
      mag[1],
      mag[2],
      attitude[0],
      attitude[1],
      attitude[2]
      );
#endif
}
       
  }
#if MDEBUG_2
  fs_close(&dzfp);
#endif

  k_timer_stop(&imu_timer);
  MMC5983_Disable();
  lsm6dsv_deinit();
  ecompass_tid = NULL;
  nineAxisFusion_deinit();

}


static void ecomp_tt(void)
{
  if (ecompass_tid == NULL)
  {
    ecompass_tid = k_thread_create(&ecompass_thread_data, ecompass_thread_stack,
                                K_THREAD_STACK_SIZEOF(ecompass_thread_stack),
                                mag_calibration_test, NULL, NULL, NULL,
                                14, 0, K_NO_WAIT);
    k_thread_name_set(ecompass_tid, "ecompass");
  }

}

void ecomp_exit(void)
{
  mag_flag = 0;
}

int ecomp(int argc, char *argv[])
{
  for (int i = 0; i < argc; i++)
  {
    printf("%d %s\n", i, argv[i]);
  }

  ecomp_tt();

  return 0;
}

