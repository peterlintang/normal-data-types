/****************************包含头文件******************************/

#include "mag_calibration.h"
/************************宏定义**********************************/
#define MY_PI                             (3.14159265358979f)
#define CALIBRATION_SUCCESS            (1) //校准成功
#define CALIBRATION_FAILURE            (0) //校准失败
#define UNDER_CALIBRATION              (2) //正在校准
/**************************函数声明********************************/
#include <ui_manager.h>
#include <drivers/rtc.h> // for rtc
#include "magcal.h"
/*
#define LOG_MODULE_CUSTOMER
#include <logging/log.h>
LOG_MODULE_REGISTER(mag, LOG_LEVEL_INF);
*/
#define MDEBUG_1 0
#define HRS_NOTIFY 0

static int count = 0;
static int len = 0;
static char print_str[512];
typedef int (*notify_t)(uint8_t *data, uint16_t len);
#if HRS_NOTIFY 
extern int bt_hrs_notify(uint8_t *data, uint16_t len);	
notify_t notify_p = bt_hrs_notify;
#else
int hrs_notify_none(uint8_t *data, uint16_t len)
{
	return len;
}
notify_t notify_p = hrs_notify_none;
#endif
#if BEBUG_FLAG
	#define BEBUG_LOG(...)  	do {  \
				len = snprintf(print_str, 512, __VA_ARGS__); \
				printf("%s", print_str);	\
		if (count++ % 200 == 0)	{	\
			notify_p(print_str, len);}	\
			} while (0)
#else
	#define BEBUG_LOG(...)  	do {  \
				len = snprintf(print_str, 512, __VA_ARGS__); \
		if (count++ % 200 == 0)		\
			notify_p(print_str, len);	\
			} while (0)
//	#define BEBUG_LOG(...)  ((void)0);
#endif

float mag_senser_data_buff[MAG_DATA_SAVE_MAX_VALUE][3]={0};
float get_PP (float *dMod, int size, int count);
float get_PP_InWindow(int size, int count);
void Algo_Update_Mag(float MagX, float MagY, float MagZ);
void MAG_Calculate(void);
float calculateMagnitude(float x, float y, float z);
void get_calibration_parameter(float *para);
void axis_interchange(float *data);
uint8_t calibration_init = 0;
uint8_t instantly_calculate_flg = 0;
/****************************变量定义******************************/

float mx_offset = 0.0,my_offset=0.0,mz_offset=0.0,mx_k=1.0,my_k=1.0,mz_k=1.0,mx_k_ratio=1.0,my_k_ratio=1.0,mz_k_ratio=1.0;
float mx=0.0f,my=0.0f,mz=0.0f;
float M_L=-1.0f;
float M_L_DIFF=0.0f;
char Mag_Clf=0;
uint8_t calibration_result = UNDER_CALIBRATION;  

static float	RAW_X[MAG_RAW_BUF_LEN]	= {0};
static float	RAW_Y[MAG_RAW_BUF_LEN]	= {0};
static float	RAW_Z[MAG_RAW_BUF_LEN]	= {0};

typedef enum 
{
   Mfree=0,
   start_calculate,
   data_process,
   calc_offset_k_value,
   get_result,
   stop_calculate
}work_step_enum;

/******************************函数体*************************************/

float get_PP (float *dMod, int size, int count)
{
    int i;
    float max, min;
    max = min = dMod[size - count];
    for (i = 0; i < count; i++)
    {
        max = (dMod[size - count + i] > max) ? dMod[size - count + i] : max;
        min = (dMod[size - count + i] < min) ? dMod[size - count + i] : min;
    }
    return (max - min);
}

float get_PP_InWindow(int size, int count)
{
    float PPV_X, PPV_Y, PPV_Z, PPV_InWindow;
    PPV_X = get_PP (RAW_X, size, count);
    PPV_Y = get_PP (RAW_Y, size, count);
    PPV_Z = get_PP (RAW_Z, size, count);
    PPV_InWindow = (PPV_X >= PPV_Y ? PPV_X >= PPV_Z ? PPV_X : PPV_Z : PPV_Y >= PPV_Z ? PPV_Y : PPV_Z);
    return PPV_InWindow;
}

void Algo_Update_Mag(float MagX, float MagY, float MagZ)
{
    int i	= 0;
    for(i = 0; i < MAG_RAW_BUF_LEN - 1; i++)
    {
        RAW_X[i] = RAW_X[i + 1];
        RAW_Y[i] = RAW_Y[i + 1];
        RAW_Z[i] = RAW_Z[i + 1];
    }
    RAW_X[MAG_RAW_BUF_LEN - 1] = MagX;
    RAW_Y[MAG_RAW_BUF_LEN - 1] = MagY;
    RAW_Z[MAG_RAW_BUF_LEN - 1] = MagZ;
}

//模值计算
float calculateMagnitude(float x, float y, float z) 
  {
      float magnitude;
      magnitude = sqrt(x*x + y*y + z*z);
      return magnitude;
  }
  
void mag_calibration_init(void)
{
   calibration_init = 1;
}
void mag_res_instantly_calculate(void)
{
  instantly_calculate_flg = 1;
}
void norm_sort(float *out,uint16_t n)
{
	uint16_t i,j;
	float temp = 0;
	for(i=0;i<n;i++)
	{
	  for(j=i+1;j<n;j++)
	  {
		if(out[i]<out[j])
		{
		  temp = out[i];
		  out[i] = out[j];
		  out[j] = temp;				
		}			
	 }		
	}
	
}
#include <stdio.h>
#include <stdlib.h>
#include <fs_manager.h>
#include <fs/fs.h>
#include <fs/fs.h>
#include <fs/fs_sys.h>
  static uint16_t  mag_senser_save_cnt = 0;
uint8_t mag_calculate(float *mag_data)
{
  static work_step_enum task_step = Mfree;
  float norm_buff[MAG_DATA_SAVE_MAX_VALUE]={0};
  float max_value = FLOAT_MIN; // 初始化最大值为float的最小值
  float min_value = FLOAT_MAX; // 初始化最小值为float的最大值
  float norm = 0.0,norm_after = 0.0;    //存储模值
  float mag_cal[3] = {0}; 
#if XY_AXIS_INTERCHANGE
    axis_interchange(mag_data);
#endif 
  if(calibration_init)  //进行了初始化，跳转到初始化任务
  {
    Mag_Clf = 0;   
    mx = mag_data[0];
    my = mag_data[1];
    mz = mag_data[2];    
    MAG_Calculate();
    task_step = Mfree;
    for(uint8_t i = 0; i < MAG_RAW_BUF_LEN; i++)
    {
        RAW_X[i] = mag_data[0];
        RAW_Y[i] = mag_data[1];
        RAW_Z[i] = mag_data[2];
    }
  }
  if(instantly_calculate_flg)  //如果需要立即计算，跳转到计算步骤
  {
    if(calibration_result == UNDER_CALIBRATION) //校准中
    {
      task_step = calc_offset_k_value;
    }
    instantly_calculate_flg  = 0;   
  }  
  Algo_Update_Mag(mag_data[0],mag_data[1],mag_data[2]); 
  /**/
#if 0
  	char calibration_text[64 * 2] = { 0 };
	char *start = NULL;
	char *position = NULL;
	struct fs_file_t zfp;
	memset(&zfp, 0, sizeof(zfp));

	if (fs_open(&zfp, "/SD:/calibration.txt", FA_READ))
	{
		printf("open calibration.txt failed\n");
	}
	else
	{
	fs_read(&zfp, calibration_text, 128);
	//strcpy(calibration_text , "5.35,-46.83,-17.39,1.00,1.02,1.01");
	fs_close(&zfp);
	printf("calibration: %s\n", calibration_text);
        start = calibration_text;
        position = strchr(start, ',');
	*position = '\0';
        mx_offset = strtof(start, NULL);
	char my_tmp[20] = { 0 };
	snprintf(my_tmp, 20, "%f", mx_offset);
        printf("mx_offset: %f, %s, %s\n", mx_offset, start, my_tmp);

        start = position + 1;
        position = strchr(start, ',');
	*position = '\0';
        my_offset = strtof(start, NULL);
        printf("my_offset: %f, %s\n", my_offset, start);

        start = position + 1;
        position = strchr(start, ',');
	*position = '\0';
        mz_offset = strtof(start, NULL);
        printf("mz_offset: %f, %s\n", mz_offset, start);

        start = position + 1;
        position = strchr(start, ',');
	*position = '\0';
        mx_k_ratio = strtof(start, NULL);
        printf("mx_k_ratio: %f, %s\n", mx_k_ratio, start);

        start = position + 1;
        position = strchr(start, ',');
	*position = '\0';
        my_k_ratio = strtof(start, NULL);
        printf("my_k_ratio: %f, %s\n", my_k_ratio, start);

        start = position + 1;
        position = strchr(start, ',');
        mz_k_ratio = strtof(start, NULL);
        printf("mz_k_ratio: %f, %s\n", mz_k_ratio, start);

	/*
	mx_offset = 5.35;
	my_offset = -46.83;
	mz_offset = -17.39;
	mx_k_ratio = 1.00;
	my_k_ratio = 1.02;
	mz_k_ratio = 1.01;
	*/
	  calibration_result = CALIBRATION_SUCCESS;
          task_step = stop_calculate;       
         return calibration_result;				
	}
#endif	

	

  /**/
  switch (task_step)
  {
    case Mfree:   //空闲状态进行判断
      calibration_result = UNDER_CALIBRATION;
//	  norm = calculateMagnitude(mag_data[0],mag_data[1],mag_data[2]);  //三轴磁力计模值计算
//	  BEBUG_LOG("free norm=%f\r\n",norm);
	  BEBUG_LOG("free PP=%f\r\n",get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN));
      if (get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN) > THRESH_START_VALUES)  //启动计算（1、阈值大于50）
      {
        task_step = start_calculate;
        mag_senser_save_cnt = 0;
        Mag_Clf = 0;   //进行数据存储
        BEBUG_LOG("start calc\r\n");
	int len = 0;
	char data[128] = { 0 };
	len = snprintf(data, 128, "start: %f %f\n", get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN), THRESH_START_VALUES);
#if HRS_NOTIFY 
	bt_hrs_notify(data, len);	
#endif
      }
    break;
    
    case start_calculate:  //满足条件开始计算 
//      norm = calculateMagnitude(mag_data[0],mag_data[1],mag_data[2]);  //三轴磁力计模值计算
//	  BEBUG_LOG("start norm=%f\r\n",norm); 
      BEBUG_LOG("start PP=%f %f\n",get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN), THRESH_START_VALUES);   
      if(get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN) < THRESH_STOP_VALUES && mag_senser_save_cnt > 66) //停止计算(1、阈值小于5；2、采集数据大于500条)
      {
//        task_step = calc_offset_k_value;
        task_step = data_process;
		if(mag_senser_save_cnt>FILTER_DEPTH)
		{
			mag_senser_save_cnt = mag_senser_save_cnt-FILTER_DEPTH;
		}
        BEBUG_LOG("stop calc-pp\r\n");
	int len = 0;
	char data[128] = { 0 };
	len = snprintf(data, 128, "stop: %f %f, cnt: %d\n", get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN), THRESH_STOP_VALUES, mag_senser_save_cnt );
#if HRS_NOTIFY 
	bt_hrs_notify(data, len);	
#endif
      }
      if(mag_senser_save_cnt == MAG_DATA_SAVE_MAX_VALUE)  //如果超过500条也进行计算
      {
//        task_step = calc_offset_k_value;
		task_step = data_process;
		if(mag_senser_save_cnt>FILTER_DEPTH)
		{
			mag_senser_save_cnt = mag_senser_save_cnt-FILTER_DEPTH;
		}
        BEBUG_LOG("stop calc-cnt\r\n");
      }
      if(mag_senser_save_cnt<MAG_DATA_SAVE_MAX_VALUE)
      {
	      int flag = 0;
	      for (int i = 0; i < mag_senser_save_cnt; i++)
	      {
		      float absx,absy,absz;
		      float ax,ay,az;
		      float m_l = 0.0;
		      absx = fabsf(mag_senser_data_buff[i][0] - mag_data[0]);
		      absy = fabsf(mag_senser_data_buff[i][1] - mag_data[1]);
		      absz = fabsf(mag_senser_data_buff[i][2] - mag_data[2]);

		      m_l = sqrtf(absx * absx + absy * absy + absz * absz);
		      if (m_l < 20.0f)
		      {
			      flag = 1;
			      break;
		      }

		      ax = fabsf(0.1 * mag_senser_data_buff[i][0]);
		      ay = fabsf(0.1 * mag_senser_data_buff[i][1]);
		      az = fabsf(0.1 * mag_senser_data_buff[i][2]);
		      /*
		      if (absx < ax && absy < ay && absz < az)
		      {
			      flag = 1;
			      break;
		      }
		      */
	      }
	      if (flag == 0)
	      {
        mag_senser_data_buff[mag_senser_save_cnt][0] = mag_data[0];
        mag_senser_data_buff[mag_senser_save_cnt][1] = mag_data[1];
        mag_senser_data_buff[mag_senser_save_cnt][2] = mag_data[2];		
        mag_senser_save_cnt++;
	      }
	  }
//      mx = mag_data[0];
//      my = mag_data[1];
//      mz = mag_data[2];    
//      MAG_Calculate();
//      BEBUG_LOG("stop=%3.4f\r\n",get_PP_InWindow(MAG_RAW_BUF_LEN, PP_BUF_LEN));          
    break;
	case  data_process:
	  Mag_Clf = 0;   //进行数据存储
	  for (uint16_t i = 0; i < mag_senser_save_cnt; i++) 
      {
		mx = mag_senser_data_buff[i][0];
		my = mag_senser_data_buff[i][1];
		mz = mag_senser_data_buff[i][2];    
		MAG_Calculate();
//		k_msleep(5);
        BEBUG_LOG("org_data=%f,%f,%f,%d\r\n",mag_senser_data_buff[i][0],mag_senser_data_buff[i][1],mag_senser_data_buff[i][2],i);		
	  }
	  task_step = calc_offset_k_value;
	break;
	
	
    case calc_offset_k_value:
      Mag_Clf = 1;
      MAG_Calculate(); 
      task_step = get_result;    
    break;
      
    case get_result: //满足条件开始计算  
	if ((isnan(mx_offset)) 
		|| (isnan(my_offset)) 
		|| (isnan(mz_offset)) 
		|| (isnan(mx_k_ratio)) 
		|| (isnan(my_k_ratio)) 
		|| (isnan(mz_k_ratio)) 
		)
	{
		mx_offset=0.0f;             //拟合出的x轴中心坐标
		my_offset=0.0f;    //拟合出的y轴中心坐标
		mz_offset=0.0f;    //拟合出的z轴中心坐标
		mx_k= 1.1f;   //拟合出的x方向上的轴半径
		my_k= 1.1f;                                                                              //拟合出的y方向上的轴半径
		mz_k= 1.1f;                                                                              //拟合出的z方向上的轴半径
		mx_k_ratio = 1.0f;
		my_k_ratio = 1.0f;
		mz_k_ratio = 1.0f;
        	calibration_result = CALIBRATION_FAILURE;
        	task_step = stop_calculate;       
        	return calibration_result;
	}
	if (M_L < 0.0)
	{
        	calibration_result = CALIBRATION_FAILURE;
        	task_step = stop_calculate;       
        	return calibration_result;
	}


      for (uint16_t i = 0; i < mag_senser_save_cnt; i++) 
      {
        mag_cal[0] = (mag_senser_data_buff[i][0]-mx_offset)*mx_k_ratio;
        mag_cal[1] = (mag_senser_data_buff[i][1]-my_offset)*my_k_ratio;
        mag_cal[2] = (mag_senser_data_buff[i][2]-mz_offset)*mz_k_ratio; 
        norm_after = calculateMagnitude(mag_senser_data_buff[i][0],mag_senser_data_buff[i][1],mag_senser_data_buff[i][2]);  //三轴磁力计模值计算		
        norm = calculateMagnitude(mag_cal[0],mag_cal[1],mag_cal[2]);  //三轴磁力计模值计算
        norm_buff[i] = norm;		
        if (norm > max_value) 
        {
          max_value = norm;
        }
		
        if (norm < min_value) 
        {
          min_value = norm;
        }
//		k_msleep(5);
//		BEBUG_LOG("org_data=%f,%f,%f,%d\r\n",mag_senser_data_buff[i][0],mag_senser_data_buff[i][1],mag_senser_data_buff[i][2],i);
//		k_msleep(5);
	    //BEBUG_LOG("mag_data=%f,%f,%f,%d\r\n",mag_cal[0],mag_cal[1],mag_cal[2],i);
        BEBUG_LOG("norm=%f,%f,%f,%f\r\n",norm_after,norm,max_value,min_value);
     }
      {
	int len = 0;
	char data[32] = { 0 };
	len = snprintf(data, 32, "norm: %f %f\n", max_value, min_value);
#if HRS_NOTIFY 
	bt_hrs_notify(data, len);	
#endif
      }
	 norm_sort(norm_buff,mag_senser_save_cnt);
	 for (uint16_t i = 0; i < mag_senser_save_cnt; i++)
	 {
//		 k_msleep(5);
		// BEBUG_LOG("norm_buff[%d]=%f\r\n",i,norm_buff[i]);		 
	 }		 
      
	  /*
      if((max_value-min_value)>THRESH_CALC_SUCCESSFUL_VALUES)
      { 
        calibration_result = CALIBRATION_FAILURE;
        task_step = stop_calculate;       
        BEBUG_LOG("Magnetometer calibration failed\r\n");
        BEBUG_LOG("Peak-valley value = %f\r\n",max_value-min_value);
        return calibration_result;
      }
      else
      {
        calibration_result = CALIBRATION_SUCCESS;
        task_step = stop_calculate;       
        BEBUG_LOG("Magnetometer calibration successful\r\n");
        BEBUG_LOG("Peak-valley value = %f\r\n",max_value-min_value);
        return calibration_result;
      }
	  */
	  uint16_t temp = 0;
	  if(mag_senser_save_cnt>100)
	  {
		temp =  mag_senser_save_cnt/100*5;
	  }
	  else
	  {
		temp = 2;  
	  }
	  if( ((norm_buff[temp]-norm_buff[mag_senser_save_cnt-temp-1])>THRESH_CALC_SUCCESSFUL_VALUES) || (mag_senser_save_cnt <=50))
      { 
        calibration_result = CALIBRATION_FAILURE;
//		  calibration_result = CALIBRATION_SUCCESS;
        task_step = stop_calculate;       
	/*
        BEBUG_LOG("Magnetometer calibration failed - cnt_err or norm_err \r\n");
        BEBUG_LOG("Peak-valley value = %f\r\n",max_value-min_value);
		BEBUG_LOG("value2 = %f\r\n",norm_buff[temp]-norm_buff[mag_senser_save_cnt-temp-1]);
		BEBUG_LOG("mag_senser_save_cnt = %d,%d\r\n",mag_senser_save_cnt,temp);
		*/
	int len = 0;
	char data[128] = { 0 };
	len = snprintf(data, 128, "aaa %f %f %d\n", norm_buff[temp]-norm_buff[mag_senser_save_cnt-temp-1], THRESH_CALC_SUCCESSFUL_VALUES, mag_senser_save_cnt );
#if HRS_NOTIFY 
	bt_hrs_notify(data, len);	
#endif
        len = snprintf(data, 128, "Peak-valley value = %f\r\n",max_value-min_value);
#if HRS_NOTIFY 
	bt_hrs_notify(data, len);	
#endif
        printf("Peak-valley value = %f\r\n",max_value-min_value);
        return calibration_result;
      }
      else
      {
#if 1
{
        float x,y,z;
        float r_sum = 0.0f;
        float r2_sum = 0.0f;
        float r3_sum = 0.0f;
        float diff_r = 0.0f;
        float diff_r2 = 0.0f;
#if MDEBUG_1
	char file_name[64] = { 0 };
        struct rtc_time rtc_time;
        struct rtc_time *tm = &rtc_time;
        const struct device *rtc = device_get_binding(CONFIG_RTC_0_NAME);
        rtc_get_time(rtc, &rtc_time);

        snprintf(file_name, 64, "/SD:/magdata_%04d%02d%02d_%02d%02d%02d.txt",
                        1900 + tm->tm_year, tm->tm_mon + 1, tm->tm_mday,
                        tm->tm_hour, tm->tm_min, tm->tm_sec);

	struct fs_file_t zfp;
	memset(&zfp, 0, sizeof(zfp));
	if (fs_open(&zfp, file_name, FA_READ | FA_WRITE | FS_O_CREATE))
	{
		printf("open %s failed\n", file_name);
	}
#endif
      for (uint16_t i = 0; i < mag_senser_save_cnt; i++)
      {
        x = (mag_senser_data_buff[i][0]-mx_offset);
        y = (mag_senser_data_buff[i][1]-my_offset);
        z = (mag_senser_data_buff[i][2]-mz_offset);
        diff_r = (x*x+y*y+z*z) - M_L * M_L;
        diff_r2 = sqrtf(x*x+y*y+z*z) - M_L;
        r_sum = r_sum + diff_r;
        r2_sum = diff_r*diff_r + r2_sum;
	r3_sum = diff_r2 * diff_r2 + r3_sum;
#if MDEBUG_1
		char my_tmp[128] = { 0 };
		int my_tmp_ret = 0;
		my_tmp_ret = snprintf(my_tmp, 128, "%.8f %.8f %.8f\n", 
				mag_senser_data_buff[i][0],
				mag_senser_data_buff[i][1],
				mag_senser_data_buff[i][2]
				);
		fs_write(&zfp, my_tmp, my_tmp_ret);
#endif
      }

//	M_L_DIFF = sqrtf(r2_sum / mag_senser_save_cnt) / (2 * M_L * M_L);
	M_L_DIFF = sqrtf(r3_sum / mag_senser_save_cnt);
#if MDEBUG_1
		char my_tmp[128] = { 0 };
		int my_tmp_ret = 0;
		my_tmp_ret = snprintf(my_tmp, 128, "%.8f %.8f %.8f %.2f %.8f %.8f\n", 
				mx_offset,
				my_offset,
				mz_offset,
				M_L,
				M_L_DIFF,
				sqrtf(r3_sum / mag_senser_save_cnt) / M_L
				);
		fs_write(&zfp, my_tmp, my_tmp_ret);
	fs_close(&zfp);
#endif

#if 1
	int len = 0;
	char data[128] = { 0 };
      printf("average diff_r: %.8f %.8f %.8f %.8f %.8f %.8f\n", 
		      r_sum / mag_senser_save_cnt, 
		      sqrtf(r2_sum / mag_senser_save_cnt), sqrtf(r3_sum / mag_senser_save_cnt),
			M_L, M_L_DIFF, 
			sqrtf(r2_sum / mag_senser_save_cnt) / (2 * M_L * M_L)
		      );
	len = snprintf(data, 128, "F: %f %f %f %f %f %f %f %f %f\n", 
			mx_offset,my_offset,mz_offset,
			M_L, M_L_DIFF, 
			sqrtf(r2_sum / mag_senser_save_cnt) / (2 * M_L * M_L),
			sqrtf(r3_sum / mag_senser_save_cnt) / M_L,
		      sqrtf(r2_sum / mag_senser_save_cnt), sqrtf(r3_sum / mag_senser_save_cnt)
		);
#if HRS_NOTIFY 
	bt_hrs_notify(data, len);	
#endif
#endif
}
#endif
		if((mx_k_ratio>=0.96)&&(mx_k_ratio<=1.04)&&(my_k_ratio>=0.96)&&(my_k_ratio<=1.04)&&(mz_k_ratio>=0.96)&&(mz_k_ratio<=1.04)) 
		{
		  calibration_result = CALIBRATION_SUCCESS;
          task_step = stop_calculate;       
	  /*
          BEBUG_LOG("Magnetometer calibration successful\r\n");
         BEBUG_LOG("Peak-valley value = %f\r\n",max_value-min_value);
		 BEBUG_LOG("value2 = %f,%d\r\n",norm_buff[temp]-norm_buff[mag_senser_save_cnt-temp-1],temp);
		 BEBUG_LOG("mag_senser_save_cnt = %d\r\n",mag_senser_save_cnt);
		 */
	  /*
	struct fs_file_t zfp;
	memset(&zfp, 0, sizeof(zfp));
	if (fs_open(&zfp, "/SD:/calibration.txt", FA_READ | FA_WRITE | FS_O_CREATE))
	{
		printf("open calibration.txt failed\n");
	}
	else
	{
		char my_tmp[128] = { 0 };
		int my_tmp_ret = 0;
		my_tmp_ret = snprintf(my_tmp, 128, "%f,%f,%f,%f,%f,%f", 
				mx_offset,
				my_offset,
				mz_offset,
				mx_k_ratio,
				my_k_ratio,
				mz_k_ratio);
		fs_write(&zfp, my_tmp, my_tmp_ret);
		fs_close(&zfp);
	}
	*/
         return calibration_result;				
		}
		else
		{
		  calibration_result = CALIBRATION_FAILURE;
		  calibration_result = CALIBRATION_SUCCESS;
		  task_step = stop_calculate;       
		  /*
		  BEBUG_LOG("Magnetometer calibration failed - k_err\r\n");
		  BEBUG_LOG("k_err=%f,%f,%f\r\n",mx_k_ratio,my_k_ratio,mz_k_ratio);
		  */
		  return calibration_result;			
		}

      }
      mag_senser_save_cnt =0;
    break;  
    
    case stop_calculate:
    break;
    
    default:
    break;
  }
  return calibration_result;   
}

void axis_interchange(float *data)
{
  float mag_x,mag_y,mag_z;
  mag_x = data[0];
  mag_y = data[1];
  mag_z = data[2];
  data[0] = mag_y * -1.0f; 
  data[1] = mag_x * -1.0f; 
  data[2] = mag_z * -1.0f; ;
}


void get_calibration_parameter(float *param)
{
  if(calibration_result == CALIBRATION_SUCCESS)
  {
    param[0] = mx_offset;
    param[1] = my_offset;
    param[2] = mz_offset;
    param[3] = mx_k_ratio;
    param[4] = my_k_ratio;
    param[5] = mz_k_ratio;
  }
  else
  {
    param[0] = 0.0f;
    param[1] = 0.0f;
    param[2] = 0.0f;
    param[3] = 0.0f;
    param[4] = 0.0f;
    param[5] = 0.0f;
  }

}

void MAG_Calculate(void)
{
    static float n=0.0f;
	//椭球校准
	static float  
	//一次项
	x_sum=0.0f,			  
	y_sum=0.0f,			  
	z_sum=0.0f,			  
	//二次项			  	 
	xx_sum=0.0f,				  	 
	yy_sum=0.0f,				  	 					  
	zz_sum=0.0f,				       
	xy_sum=0.0f,   			       
	xz_sum=0.0f,   			      
	yz_sum=0.0f,   			  
	//三次项  			  
	xxx_sum=0.0f,			  
	xxy_sum=0.0f,			  
	xxz_sum=0.0f,			  
	xyy_sum=0.0f, 			  
	xzz_sum=0.0f, 			  			  
	yyy_sum=0.0f,				  
	yyz_sum=0.0f,				                           
	yzz_sum=0.0f,	 			                           
	zzz_sum=0.0f,	 			  
	//四次项				  	
	yyyy_sum=0.0f,			  	
	zzzz_sum=0.0f,			  	
	xxyy_sum=0.0f,			  	
	xxzz_sum=0.0f,			  
	yyzz_sum=0.0f;
 
	static float  
	//一次项
	x_avr=0.0f,			  
	y_avr=0.0f,			  
	z_avr=0.0f,			  
	//二次项			  	 
	xx_avr=0.0f,				  	 
	yy_avr=0.0f,				  	 					  
	zz_avr=0.0f,				       
	xy_avr=0.0f,   			       
	xz_avr=0.0f,   			      
	yz_avr=0.0f,   			  
	//三次项  			  
	xxx_avr=0.0f,			  
	xxy_avr=0.0f,			  
	xxz_avr=0.0f,			  
	xyy_avr=0.0f, 			  
	xzz_avr=0.0f, 			  			  
	yyy_avr=0.0f,				  
	yyz_avr=0.0f,				                           
	yzz_avr=0.0f,	 			                           
	zzz_avr=0.0f,	 			  
	//四次项				  	
	yyyy_avr=0.0f,			  	
	zzzz_avr=0.0f,			  	
	xxyy_avr=0.0f,			  	
	xxzz_avr=0.0f,			  
	yyzz_avr=0.0f;
  if(calibration_init)
  {
    calibration_init = 0;
    n=0.0f;
    //椭球校准
    //一次项
    x_sum=0.0f,			  
    y_sum=0.0f,			  
    z_sum=0.0f,			  
    //二次项			  	 
    xx_sum=0.0f,				  	 
    yy_sum=0.0f,				  	 					  
    zz_sum=0.0f,				       
    xy_sum=0.0f,   			       
    xz_sum=0.0f,   			      
    yz_sum=0.0f,   			  
    //三次项  			  
    xxx_sum=0.0f,			  
    xxy_sum=0.0f,			  
    xxz_sum=0.0f,			  
    xyy_sum=0.0f, 			  
    xzz_sum=0.0f, 			  			  
    yyy_sum=0.0f,				  
    yyz_sum=0.0f,				                           
    yzz_sum=0.0f,	 			                           
    zzz_sum=0.0f,	 			  
    //四次项				  	
    yyyy_sum=0.0f,			  	
    zzzz_sum=0.0f,			  	
    xxyy_sum=0.0f,			  	
    xxzz_sum=0.0f,			  
    yyzz_sum=0.0f;
  
    //一次项
    x_avr=0.0f,			  
    y_avr=0.0f,			  
    z_avr=0.0f,			  
    //二次项			  	 
    xx_avr=0.0f,				  	 
    yy_avr=0.0f,				  	 					  
    zz_avr=0.0f,				       
    xy_avr=0.0f,   			       
    xz_avr=0.0f,   			      
    yz_avr=0.0f,   			  
    //三次项  			  
    xxx_avr=0.0f,			  
    xxy_avr=0.0f,			  
    xxz_avr=0.0f,			  
    xyy_avr=0.0f, 			  
    xzz_avr=0.0f, 			  			  
    yyy_avr=0.0f,				  
    yyz_avr=0.0f,				                           
    yzz_avr=0.0f,	 			                           
    zzz_avr=0.0f,	 			  
    //四次项				  	
    yyyy_avr=0.0f,			  	
    zzzz_avr=0.0f,			  	
    xxyy_avr=0.0f,			  	
    xxzz_avr=0.0f,			  
    yyzz_avr=0.0f;
  }

	//矩阵定义
	static float                   A[16]   ,      A_inv [16];  //系数矩阵
	static matrix_instance_f32 A_matrix,      A_inv_matrix;	
	static float                   B[4];                       //非齐次项
	static matrix_instance_f32 B_matrix;
	static float                   Par[4];                     //需要拟合的参数
	static matrix_instance_f32 Par_matrix;
	
	switch(Mag_Clf)
	{
		case 0:
		{
			x_sum   =x_sum   +(mx); 
			y_sum   =y_sum   +(my); 
			z_sum   =z_sum   +(mz); 
			xx_sum  =xx_sum  +(mx*mx); 	   
			yy_sum  =yy_sum  +(my*my); 
			zz_sum  =zz_sum  +(mz*mz); 
			xy_sum  =xy_sum  +(mx*my); 
			xz_sum  =xz_sum  +(mx*mz); 
			yz_sum  =yz_sum  +(my*mz); 
			xxx_sum =xxx_sum +(mx*mx*mx); 					
			xxy_sum =xxy_sum +(mx*mx*my); 				
			xxz_sum =xxz_sum +(mx*mx*mz); 				
			xyy_sum =xyy_sum +(mx*my*my); 
			xzz_sum =xzz_sum +(mx*mz*mz); 
			yyy_sum =yyy_sum +(my*my*my);
			yyz_sum =yyz_sum +(my*my*mz);
			yzz_sum =yzz_sum +(my*mz*mz);
			zzz_sum =zzz_sum +(mz*mz*mz);
			yyyy_sum=yyyy_sum+(my*my*my*my);
			zzzz_sum=zzzz_sum+(mz*mz*mz*mz);
			xxyy_sum=xxyy_sum+(mx*mx*my*my);		   
			xxzz_sum=xxzz_sum+(mx*mx*mz*mz);		   
			yyzz_sum=yyzz_sum+(my*my*mz*mz);		   
			n=n+1.0f;
			break;
		}
		case 1://各次累加和统计
		{
			//矩阵初始化	
			A_matrix.numRows=4;   A_inv_matrix.numRows=4;     B_matrix.numRows=4;   Par_matrix.numRows=4;
			A_matrix.numCols=4;   A_inv_matrix.numCols=4;     B_matrix.numCols=1;   Par_matrix.numCols=1;
			A_matrix.pData  =A;   A_inv_matrix.pData  =A_inv; B_matrix.pData  =B;   Par_matrix.pData  =Par;
		
			//各次均值统计
			x_avr   =x_sum/n; 
			y_avr   =y_sum/n; 
			z_avr   =z_sum/n; 
			xx_avr  =xx_sum/n; 
			yy_avr  =yy_sum/n; 			
			zz_avr  =zz_sum/n; 			
			xy_avr  =xy_sum/n; 			
			xz_avr  =xz_sum/n; 			
			yz_avr  =yz_sum/n; 					
			xxx_avr =xxx_sum/n; 		
			xxy_avr =xxy_sum/n; 
			xxz_avr =xxz_sum/n; 
			xyy_avr =xyy_sum/n; 
			xzz_avr =xzz_sum/n; 
			yyy_avr =yyy_sum/n;			
			yyz_avr =yyz_sum/n;						
			yzz_avr =yzz_sum/n;										 	
			zzz_avr =zzz_sum/n;	
			yyyy_avr=yyyy_sum/n;
			zzzz_avr=zzzz_sum/n;
			xxyy_avr=xxyy_sum/n;
			xxzz_avr=xxzz_sum/n;
			yyzz_avr=yyzz_sum/n;							
																			
                        //系数矩阵计算
                        A[0 ]=       1;A[1 ]=   z_avr;A[2 ]=  y_avr;A[3 ]=  x_avr;
                        A[4 ]=   x_avr;A[5 ]=  xz_avr;A[6 ]= xy_avr;A[7 ]= xx_avr;
                        A[8 ]=  y_avr ;A[9 ]= yz_avr ;A[10]=yy_avr ;A[11]=xy_avr ;
                        A[12]=  z_avr ;A[13]= zz_avr ;A[14]=yz_avr ;A[15]=xz_avr ;

                        /*
                        for (int i = 0; i < 36; i++)
                                printf("A[%d]: %.8f\n", i, A[i]);
                                */

                        //非齐次列向量赋值
                        B[0]=xx_avr + yy_avr + zz_avr;
                        B[1]=xxx_avr + xyy_avr + xzz_avr;
                        B[2]=xxy_avr + yyy_avr + yzz_avr;
                        B[3]=xxz_avr + yyz_avr + zzz_avr;


			int ret = ARM_MATH_SUCCESS;
			//系数矩阵求逆
			ret = mat_inverse_float(&A_matrix,&A_inv_matrix);
			if (ret != ARM_MATH_SUCCESS)
			{
			mx_offset=0.0f;             //拟合出的x轴中心坐标
			my_offset=0.0f;    //拟合出的y轴中心坐标
			mz_offset=0.0f;    //拟合出的z轴中心坐标
			mx_k= 1.1f;   //拟合出的x方向上的轴半径
			my_k= 1.1f;                                                                              //拟合出的y方向上的轴半径
			mz_k= 1.1f;                                                                              //拟合出的z方向上的轴半径
			mx_k_ratio = 1.0f;
			my_k_ratio = 1.0f;
			mz_k_ratio = 1.0f;
        		BEBUG_LOG("inverse failed\r\n");
			return ;
			}
			else
			{
        		BEBUG_LOG("inverse %d\r\n", ret);
				for (int i = 0; i < A_inv_matrix.numRows; i++)
				{
					for (int j = 0; j < A_inv_matrix.numCols; j++)
					{
						if (isnan(A_inv_matrix.pData[i * A_inv_matrix.numRows + j])) 
						{
							return;
						}
					}
				}	
			}
			
			//解方程组得出拟合参数
			ret = mat_mult_float(&A_inv_matrix,&B_matrix,&Par_matrix);
			if (ret != ARM_MATH_SUCCESS)
			{
			mx_offset=0.0f;             //拟合出的x轴中心坐标
			my_offset=0.0f;    //拟合出的y轴中心坐标
			mz_offset=0.0f;    //拟合出的z轴中心坐标
			mx_k= 1.1f;   //拟合出的x方向上的轴半径
			my_k= 1.1f;                                                                              //拟合出的y方向上的轴半径
			mz_k= 1.1f;                                                                              //拟合出的z方向上的轴半径
			mx_k_ratio = 1.0f;
			my_k_ratio = 1.0f;
			mz_k_ratio = 1.0f;
        		BEBUG_LOG("mult failed\r\n");
			return ;
			}
			else
			{
        		BEBUG_LOG("mult %d\r\n", ret);
				for (int i = 0; i < Par_matrix.numRows; i++)
				{
					for (int j = 0; j < Par_matrix.numCols; j++)
					{
						if (isnan(Par_matrix.pData[i * Par_matrix.numRows + j])) 
						{
							return;
						}
					}
				}	
			}
			
			                        //计算椭球参数
                        mx_offset=(Par[3]/2.0f);             //拟合出的x轴中心坐标
                        my_offset=(Par[2]/2.0f);    //拟合出的y轴中心坐标
                        mz_offset=(Par[1]/2.0f);    //拟合出的z轴中心坐标
                        if (Par[0] + mx_offset * mx_offset + my_offset * my_offset + mz_offset * mz_offset > 0)
                        	M_L = sqrtf(Par[0] + mx_offset * mx_offset + my_offset * my_offset + mz_offset * mz_offset);
			else
                        	M_L = -1;
                        BEBUG_LOG(" x0=%f y0=%f z0=%f B=%f\n",
                                        mx_offset,my_offset,mz_offset,
                                        M_L
                                        );

			int len = 0;
			char data[128] = { 0 };

extern void MAG_Calculate2(const emxArray_real32_T *x, const emxArray_real32_T *y,
                     const emxArray_real32_T *z, creal32_T Ainv[9], float b[3],
                     float *r);
extern void argInit_Unboundedx1_real32_T(emxArray_real32_T **px, emxArray_real32_T **py, emxArray_real32_T **pz, float a[][3], int nlines);
	emxArray_real32_T *px = NULL;
	emxArray_real32_T *py = NULL;
	emxArray_real32_T *pz = NULL;
	argInit_Unboundedx1_real32_T(&px, &py, &pz, mag_senser_data_buff, mag_senser_save_cnt);
	creal32_T ainv[9];
	float b[3];
	MAG_Calculate2(px, py, pz, ainv, b, &M_L);
	mx_offset=b[0];
	my_offset=b[1]; 
	mz_offset=b[2];  
	emxDestroyArray_real32_T(pz);
	emxDestroyArray_real32_T(py);
	emxDestroyArray_real32_T(px);
	pz = NULL;
	py = NULL;
	px = NULL;

//       HAL_Delay(20); 
			BEBUG_LOG(" x0=%f y0=%f z0=%f A=%f B=%f C=%f AK=%f BK=%f CK=%f\n",mx_offset,my_offset,mz_offset,mx_k,my_k,mz_k,mx_k_ratio,my_k_ratio,mz_k_ratio);
			len = snprintf(data, 128, "x0=%f\n y0=%f\n z0=%f\n B=%f AK=%f BK=%f CK=%f\n",mx_offset,my_offset,mz_offset, M_L, mx_k_ratio, my_k_ratio, mz_k_ratio);
#if HRS_NOTIFY 
			bt_hrs_notify(data, len);	
#endif
			len = snprintf(data, 128, "B: %f %f %f %f \n", 
                                        mx_offset,my_offset,mz_offset,
                                        M_L
					);
#if HRS_NOTIFY 
			bt_hrs_notify(data, len);	
#endif
//			 HAL_Delay(20); 
       Mag_Clf = 0;
			break;
		}
		default :break;
	}
}

void get_calibrat_mag_data(float *mag_data)
{
  
#if XY_AXIS_INTERCHANGE
    axis_interchange(mag_data);
#endif 
  
  mag_data[0] = (mag_data[0]-mx_offset)*mx_k_ratio;
  mag_data[1] = (mag_data[1]-my_offset)*my_k_ratio;
  mag_data[2] = (mag_data[2]-mz_offset)*mz_k_ratio;
}

float get_angle(float *mag_data)
{
  float yaw = 0.0f;
  yaw = atan2(mag_data[1],mag_data[0])* 180.0/MY_PI;
  return yaw;
}
