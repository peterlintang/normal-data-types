
#ifndef NINEAXISFUSION_H
#define NINEAXISFUSION_H

#include "mag_calibration.h"

typedef struct _param_t {
  float param[9];
  int start;    // 0 not need start calibrate, 1 immediate calibrate
  int auto_calibrate;  // 0 not auto calibrate, 1 while check *** auto start calibrate
} param_t;

/*
 * 初始化电子罗盘模块
 * param: 设置参数
 */
int nineAxisFusion_init(param_t *param);

/*
 * 电子罗盘融合处理函数
 * gry: 角速度
 * acc:加速度
 * mag:地磁
 * attitude:返回3个姿态角
 */
int nineAxisFusion_process(float gry[3],
    float acc[3], 
    float mag[3], 
    float attitude[3]);

/*
 * 获取电子罗盘校准精度
 * 返回精度等级0 1 2 3
 */
int nineAxisFusion_getAccuracy(void);

/*
 * 获取电子罗盘校准参数
 */
int nineAxisFusion_getCalibrationParam(float param[9]);

/*
 * 退出模块时调用
 */
int nineAxisFusion_deinit(void);

#endif // end of NINEAXISFUSION_H


